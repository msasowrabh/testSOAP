var finesse = finesse || {};
finesse.modules = finesse.modules || {};

finesse.modules.Gadget = (function ($) {

    var user, media, mrdID = "5016", mediaDialogs, clientLogs;

    /* ==============================
       DIALOG HANDLERS
    ============================== */

    function handleDialogAdd(dialog) {
        if (dialog._data.mediaProperties.mediaId !== mrdID) {
            return;
        }

        clientLogs.log("Chat arrived!");

        var callVars = dialog._data.mediaProperties;

        var customerName = callVars["callVariable1"] || "Unknown";
        var customerNumber = callVars["callVariable2"] || "Unknown";

        clientLogs.log("Call Vars: " + JSON.stringify(callVars));

        renderDialog({
            id: dialog.getId(),
            name: customerName,
            number: customerNumber
        });
    }

    function handleDialogDelete(dialog) {
        clientLogs.log("Chat ended");

        $("#chatContainer").empty();
    }

    function handleDialogsLoad() {
        clientLogs.log("Dialogs loaded");

        var dialogs = mediaDialogs.getCollection();

        for (var id in dialogs) {
            handleDialogAdd(dialogs[id]);
        }
    }

    function loadDialogs() {
        clientLogs.log("Loading dialogs...");

        mediaDialogs = media.getMediaDialogs({
            onCollectionAdd: handleDialogAdd,
            onCollectionDelete: handleDialogDelete,
            onLoad: handleDialogsLoad
        });
    }

    /* ==============================
       MEDIA HANDLERS
    ============================== */

    function handleMediaLoad(_media) {
        clientLogs.log("Media loaded");

        media = _media;
        loadDialogs();
    }

    function handleMediaChange(_media) {
        if (_media._data.id === mrdID) {
            clientLogs.log("Media state changed: " + _media.getState());
        }
    }

    function handleMediaError(err) {
        clientLogs.log("Media error: " + JSON.stringify(err));
    }

    /* ==============================
       USER HANDLERS
    ============================== */

    function handleUserLoad() {
        clientLogs.log("User loaded");

        user.getMediaList({
            onLoad: function (mediaList) {

                clientLogs.log("MediaList loaded");

                mediaList.getMedia({
                    id: mrdID,
                    onLoad: handleMediaLoad,
                    onChange: handleMediaChange,
                    onError: handleMediaError
                });

            }
        });
    }

    function handleUserChange() {
        clientLogs.log("User state changed: " + user.getState());
    }

    /* ==============================
       UI
    ============================== */

    function renderDialog(data) {
        clientLogs.log("Rendering dialog for: " + data.name);

        $("#chatContainer").html(
            "<div>" +
                "<h3>Incoming Chat</h3>" +
                "<p><b>Name:</b> " + data.name + "</p>" +
                "<p><b>Number:</b> " + data.number + "</p>" +
            "</div>"
        );
    }

    /* ==============================
       INIT
    ============================== */

    return {
        init: function () {

            finesse.clientservices.ClientServices.init(finesse.gadget.Config);

            // ✅ Initialize logger FIRST
            clientLogs = finesse.cslogger.ClientLogger;
            clientLogs.init(gadgets.Hub, "MinChatGadget");

            clientLogs.log("Gadget initializing...");

            user = new finesse.restservices.User({
                id: finesse.gadget.Config.id,
                onLoad: handleUserLoad,
                onChange: handleUserChange
            });

            $("body").html('<div id="chatContainer"></div>');
        }
    };

}(jQuery));