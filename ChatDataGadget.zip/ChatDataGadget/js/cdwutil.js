var cdw_util_version = "2/26/2021 12:32 PM";


    function getParameterByName(name) {
        var url = $('script[src*=cdwutil]').attr('src');
        var retval = "";   
        try {
            url = decodeURIComponent(url);
//          console.log( "CDW util url: " + url );
            if (url.indexOf(name) > -1) {
                url = url.replace(/\?/g,"&");
                var parmArray = url.split("&");
                for (var i=0;i<parmArray.length;i++){
//                	console.log("CDW util Array-"+ i + ": " + parmArray[i]);
                    if (parmArray[i].indexOf(name) > -1) {
                        var keyValuePair = parmArray[i].split("=");
                        retval = keyValuePair[1];
                        break;
                    }
                }
            }
            if(retval.indexOf('=') > -1){
                var parmArray = retval.split('=');
                retval = parmArray[1];
            }
        } catch(err){
            console.log("CDW util Error: " + err.message);
        }
        return retval;
    }
    
    
    
    
    function getServletPath() {
        var path = "";
     
        var jsFileLocation = $('script[src*=cdwutil]').attr('src');  
        clientLogs.log( "jsFileLocation: " + jsFileLocation );
        
        var arr = jsFileLocation.split('=');
        var arr2 = arr[2].split('&');
        var fullPath = decodeURIComponent(arr2[0]); 
        clientLogs.log( "fullPath: " + fullPath ); 
          
        path = fullPath.substring(0, fullPath.lastIndexOf("/") + 1);       
        clientLogs.log( "path: " + path );
        
//        var res = path.split("8082");
//        var urlStr = window.location.protocol + "//" + window.location.hostname + ":" + window.location.port + res[1];
//        path = urlStr;
//        clientLogs.log( "path: " + path );
   
        return path;
     }
    
    
    
    
    function makeToast(title, message) {  
	    var FinesseToaster = finesse.containerservices.FinesseToaster, toasterTitle, toasterBody;
	    toasterBody = 'This is an important Message!';
	
	    FinesseToaster.showToaster(title, {
	          body : message,
	          icon : FinesseToaster.TOASTER_DEFAULT_ICONS.INCOMING_CALL_ICON, //icon url
	          showWhenVisible: true,   			//do you want to see the notification if finesse desktop is active
	          tag: 'IncomingCall',     			//any unique name
	          onclick:toasterOnClickHandler   	// callback method on click of toaster
	    });
    
    }
    
    
    function toasterOnClickHandler() {  
    	clientLogs.log( "toasterOnClickHandler...." );
    }
    
    
    
    function getTS(){
 	   return "&ts=" + $.now();
    }
    
    
    String.prototype.includes = function (str) {
	  var returnValue = false;

	  if (this.indexOf(str) !== -1) {
	    returnValue = true;
	  }
      return returnValue;
    }
    
    
    


