var code_version = "2/27/2026 9:17 PM";
var clientLogs;
var config;
var agentId;
	
		
var finesse = finesse || {};

/** @namespace */
finesse.modules = finesse.modules || {};
finesse.modules.Gadget = (function ($) {
	clientLogs = finesse.cslogger.ClientLogger;
	
    var user, media, utils, mediaDialogs, maxDialogs, mediaList,
        interruptAction, dialogLogoutAction, mrdID, mrdName,
        states = finesse.restservices.Media.States,
        prefs = new gadgets.Prefs(),
		
		
        /**
         * Prefix for call variables in dialog.mediaProperties
         */
        CALL_VARIABLE_PREFIX = "callVariable",
        /**
         * Store the maxDialogLimit, interruptAction, and dialogLogoutAction options to be used with this gadget's
         * media object.
         */
        mediaOptions,
        /**
         * Stores whether or not the application is connected to the Finesse server.
         */
        connected = true,
        /**
         * Track whether the media associated with this gadget has been interrupted.
         */
        interrupted = false,


    /**
     *	Callback used upon the load of a media object. This should be used for anything that only needs to be
     *  executed once during initialization.
     */
    handleMediaLoad = function(_media) {
		clientLogs.log("in handleMediaLoad...");

        loadMediaDialogs(_media);
        //if user signed out of this media or state is unknown, show the sign in button
        if (_media.getState() === states.LOGOUT) {
			clientLogs.log("user logged out.");
		} else if (_media.getState() === undefined ) {
            clientLogs.log("user in undefined state.");
        } else {
           clientLogs.log("in handleMediaLoad else...");
        }
    },
	
	
	handleMediaSuccess = function(obj){
	    //clear any previous error message
		clientLogs.log("in handleMediaSuccess...");
	},

	/**
	 *	Handler called upon a failed action on the media.
	 */
	handleMediaError = function(rsp) {
	    var errorMessage = rsp.object.ApiErrors.ApiError.ErrorMessage;
	    var msg = prefs.getMsg(errorMessage) || errorMessage;

	    if(errorMessage == "E_ARM_STAT_AGENT_ALREADY_LOGGED_IN") {
	            loadMediaDialogs(media);
	            return;
	    }

	    showError("Operation Failed: " + msg);
	},

	
    /**
     *  Callback used when a media is changed. This is misleading because it will be triggered when any
     *  media changes, not just the one associated with this instance of the gadget.
     */
    handleMediaChange = function(_media) {
        //only update if the notification is for this gadgets's specific media
        //since there could be multiple media gadgets corresponding to a different media id
        
        if(mrdID === _media._data.id) {
			
			var xState = _media._data.state;
            clientLogs.log("in handleMediaChange, this is our Chat mrdID: " + mrdID);
			clientLogs.log("Chat State: " + xState);
			setIndicator(xState);
			gadgets.window.adjustHeight();
        }
    },
	
	
	setIndicator = function (state) {
		var $indicator = window.parent.jQuery("#chatStatus");
		window.parent.jQuery("#chatStatusText").text("Chat: " + state);
	    $indicator.removeClass("status-ready status-notready status-logout");
	    if (state === "READY") {
	        $indicator.addClass("status-ready");
	    }
	    else if (state === "NOT_READY") {
	        $indicator.addClass("status-notready");
	    }
	    else {
	        $indicator.addClass("status-logout");
	    }
	},

	
	setVoiceIndicator = function (state) {
		var $indicator = window.parent.jQuery("#voiceStatus");
		window.parent.jQuery("#voiceStatusText").text("Voice: " + state);
	    $indicator.removeClass("status-ready status-notready status-logout");
	    if (state === "READY") {
	        $indicator.addClass("status-ready");
	    }
	    else if (state === "NOT_READY") {
	        $indicator.addClass("status-notready");
	    }
	    else {
	        $indicator.addClass("status-logout");
	    }
	},

    /**
     * Load the current user's dialogs.
     * @return {undefined}
     */
    loadMediaDialogs = function (_media) {
        mediaDialogs = _media.getMediaDialogs({
            onCollectionAdd : handleMediaDialogsAdd,
            onCollectionDelete : handleMediaDialogsDelete,
            onLoad: handleMediaDialogsLoad
        });
    },

	
    handleMediaDialogsLoad = function() {
  
        var dialogCollection = mediaDialogs.getCollection(), id;

        for (id in dialogCollection) {
            var dialog = dialogCollection[id];
            handleMediaDialogsAdd(dialog);
        }
    },
	
	
	hideComponents = function () {

		    window.parent.jQuery('#agent-voice-state').hide();
		    window.parent.jQuery('#nonvoice-state-menu').hide();

			if (!window.parent.jQuery('#chatStatusStyles').length) {
			    window.parent.jQuery('head').append(
			        '<style id="chatStatusStyles">' +

						/* Container (keeps everything left, spaced, aligned) */
						'#chatStatusContainer{' +
							'display:flex;' +
							'align-items:center;' +
							'gap:10px;' +
							'margin-right:10px;' +
						'}' +

						/* Pill base */
						'.statusPill{' +
							'display:inline-flex;' +
							'align-items:center;' +
							'justify-content:center;' +
							'height:28px;' +
							'min-width:180px;' +
							'padding:0 10px;' +
							'border-radius:14px;' +
							'font-size:12px;' +
							'font-weight:700;' +
							'color:#ffffff;' +
							'line-height:28px;' +
							'box-shadow:0 1px 2px rgba(0,0,0,0.12);' +
							'border:1px solid rgba(0,0,0,0.12);' +
							'white-space:nowrap;' +
						'}' +

			            '.status-ready{ background-color:#16a34a; }' +      /* Green */
			            '.status-notready{ background-color:#dc2626; }' +   /* Red */
			            '.status-logout{ background-color:#60a5fa; }' +     /* Light Blue */

						/* Select styling (closer to Finesse look) */
						'#stateSelect{' +
							'height:28px;' +
							'min-width:220px;' +
							'max-width:300px;' +
							'padding:0 10px;' +
							'border-radius:4px;' +
							'border:1px solid #c9ced6;' +
							'background:#ffffff;' +
							'color:#2f3b4a;' +
							'font-size:12px;' +
							'font-weight:600;' +
							'outline:none;' +
						'}' +
						'#stateSelect:hover{' +
							'border-color:#9aa4b2;' +
						'}' +
						'#stateSelect:focus{' +
							'border-color:#2b6cb0;' +
							'box-shadow:0 0 0 2px rgba(43,108,176,0.18);' +
						'}' +

			        '</style>'
			    );
			}

			/* Remove any previous injection so you don't get duplicates */
			window.parent.jQuery('#chatStatusContainer').remove();

		    window.parent.jQuery('.header-right-container').prepend(
		        '<div id="chatStatusContainer">' +
					
					'<div id="chatStatus" class="statusPill status-logout"><span id="chatStatusText">Chat: Logged Out</span></div>' +
					'<div id="voiceStatus" class="statusPill status-logout"><span id="voiceStatusText">Voice: Logged Out</span></div>' +
					
					'<select id="stateSelect" name="stateSelect">' +
						'<option value="CHAT_READY">Chat Ready</option>' +
						'<option value="CHAT_NOT_READY">Chat Not Ready</option>' +
						'<option value="VOICE_READY">Voice Ready</option>' +
						'<option value="VOICE_NOT_READY">Voice Not Ready</option>' +
						'<option value="ALL_READY">All Ready</option>' +
						'<option value="ALL_NOT_READY">All Not Ready</option>' +
					'</select>' +
				'</div>'
		    );

		    // IMPORTANT: bind to the PARENT document (or bind directly to #stateSelect in parent)
		    window.parent.jQuery(window.parent.document)
		        .off("change", "#stateSelect")
		        .on("change", "#stateSelect", function () {
		            var selectedValue = window.parent.jQuery(this).val();

					clientLogs.log("State selectedValue: " + selectedValue);

					if (selectedValue == 'CHAT_READY') {
					    finesse.modules.Gadget.changeToReady();
					}

					if (selectedValue == 'CHAT_NOT_READY') {
					    finesse.modules.Gadget.changeToNotReady();
					}

		            if (selectedValue == "ALL_READY") {
		                finesse.modules.Gadget.changeToReady();
						setVoiceReady();
		            }

					if (selectedValue == "ALL_NOT_READY") {
					    finesse.modules.Gadget.changeToNotReady();
						setVoiceNotReady();
					}

					if (selectedValue == 'VOICE_READY') {
						setVoiceReady();
					}

		            if (selectedValue == 'VOICE_NOT_READY') {
						setVoiceNotReady();
		            }

		            // finesse.modules.Gadget.logoutFromMrd();
		        });

		},
		
	

	
	setVoiceReady = function () {
		try {
		    user.setState("READY", "", {
		        success: function () {
		            clientLogs.log("Voice set to READY");
		        },
		        error: function (err) {
		            clientLogs.log("Ready error: " + err);
		        }
		    });
		} catch (err) {
		    clientLogs.log(err);
		}
	},
	
	
	setVoiceNotReady = function(){
		try {
			var reasonCode = {id:1};
			user.setState("NOT_READY", reasonCode, {
			    success: function () {
			        clientLogs.log("Voice set to READY");
			    },
			    error: function (err) {
			        clientLogs.log("Ready error: " + err);
			    }
			});
		} catch (err) {
		    clientLogs.log(err);
		}
	},
	
	
	
	
	
	
	
	
	

	
    /**
     * Handler that is called anytime a dialog is added for the user on all media.
     */
    handleMediaDialogsAdd = function (dialog) {
		
		
        //this gets called whenever there's a dialog change for all media
        //only update if the notification is for this gadgets's specific media
        //since there could be multiple media gadgets corresponding to a different media id
        if(mrdID === dialog._data.mediaProperties.mediaId) {

			clientLogs.log("in handleMediaDialogsAdd...");
         //   dialog.addHandler("change",displayDialog);
            
        }
    },

	
    /**
     * Handler called anytime a dialog is ended
     */
    handleMediaDialogsDelete = function (dialog) {
		clientLogs.log("in handleMediaDialogsDelete...");
		
        if(mrdID === dialog._data.mediaProperties.mediaId) {
           // displayDialog(dialog);
           // removeCurrentTab(dialog.getId());
            adjustGadgetHeight();
        }
    },

	
    /**
     * Handler for the onLoad of a User object.  This occurs when the User object is initially read
     * from the Finesse server.  Any once only initialization should be done within this function.
     */
    handleUserLoad = function (_user) {
		clientLogs.log("in handleUserLoad...");
		
		setTimeout(function() {
			try {
				clientLogs.log("ChatHelperGadget.js version: " + code_version);
			} catch (err){
				clientLogs.log("Show version info error: " + err);
			}
			
			//media.refresh();
			var state = media.getState();
			setIndicator(state);
			
			var currentState = user.getState();
			setVoiceIndicator(currentState);
			
		}, 3000);
		
        mediaList = user.getMediaList( {
            onLoad: handleMediaListLoad
        });
    },
    
    
    handleUserChange = function(userevent) {
		var currentState = user.getState();
		setVoiceIndicator(currentState);
		clientLogs.log("CurrentState: " + currentState);
	},
	
	
	checkGadgetQueryParams = function() {
		clientLogs.log("in checkGadgetQueryParams...");
		clientLogs.log("These values stored in Finesse admin desktop layout.");
		
	    //First get just the URI for this gadget out of the full finesse URI and decode it.
	    var gadgetURI = decodeURIComponent(getUrlVars(location.search)["url"]);

	    //Now get the individual query params from the gadget URI
	    var decodedGadgetURI = getUrlVars(gadgetURI);
	    mrdID = "5016";
	    mrdName = "Test";
	    maxDialogs = "1";
	    interruptAction = finesse.restservices.InterruptActions.ACCEPT;
	    dialogLogoutAction = finesse.restservices.DialogLogoutActions.CLOSE;
	    
	    
	    clientLogs.log("mrdID: " + mrdID);
	    clientLogs.log("mrdName: " + mrdName);
	    clientLogs.log("maxDialogs: " + maxDialogs);

	    //If no MRD ID is configured or it's not a number we want to throw an error during init.
	    if (!mrdID || isNaN(mrdID)) {
	        return false;
	    }

	    //If there's no max dialogs configured or the value is not a number then default it to 5.
	    if (!maxDialogs || isNaN(maxDialogs)) {
	        maxDialogs = "1";
	    }

	    //If there's no interruptAction configured or the value is not valid, default to "ACCEPT".
	    if (!finesse.restservices.InterruptActions.isValidAction(interruptAction)) {
	        interruptAction = finesse.restservices.InterruptActions.ACCEPT;
	    }

	    if (!finesse.restservices.DialogLogoutActions.isValidAction(dialogLogoutAction)) {
	        dialogLogoutAction = finesse.restservices.DialogLogoutActions.CLOSE;
	    }

	    //If there's no dialogLogoutAction configured or the value is not valid, default to "CLOSE".
	    if (!dialogLogoutAction || dialogLogoutAction.toUpperCase()!=="CLOSE" && dialogLogoutAction.toUpperCase()!=="TRANSFER") {
	        dialogLogoutAction = "CLOSE";
	    }

	   
	},
	
	showError = function (errText) {
		clientLogs.log(errText)
	},
	
	

    /**
     * Handler for the onLoad of a MediaList object.  This occurs when the MediaList object is initially read
     * from the Finesse server.
     */
    handleMediaListLoad = function (_mediaList) {
		clientLogs.log("in handleMediaListLoad...");

		try {
			if (_mediaList == null || _mediaList.length < 1){
				clientLogs.log("_mediaList is null!");
			}
		} catch(err){
			clientLogs.log("err1xa: " + err);
		}
		
        try {
            //get the media with the specified id
            media = _mediaList.getMedia({
                id: mrdID,
                onLoad: handleMediaLoad,
                onError: handleMediaError,
                onChange: handleMediaChange,
                mediaOptions: mediaOptions
            });
        } catch ( error ) {
			clientLogs.log("error 2xb: " + error);
            showError(mrdID + " Media Channel Not Found.");
        }
    },


	watchForChatEnd = function () {
		var parentDoc = window.parent.document;

		function attachObserver(iframeDoc) {
			var observer = new MutationObserver(function (mutations) {
				for (var i = 0; i < mutations.length; i++) {
					var mutation = mutations[i];

					// #liveRegion text updated
					if (mutation.type === 'characterData' || mutation.type === 'childList') {
						var t = mutation.target;
						var liveNode = (t.id === 'liveRegion') ? t :
						               (t.parentNode && t.parentNode.id === 'liveRegion') ? t.parentNode : null;
						if (liveNode && (liveNode.textContent || '').indexOf('Customer ended the conversation') > -1) {
							clientLogs.log('Customer ended the chat!');
							continue;
						}
					}

					// announcement div added to message list
					if (mutation.addedNodes) {
						for (var j = 0; j < mutation.addedNodes.length; j++) {
							var node = mutation.addedNodes[j];
							if (node.nodeType === 1 &&
							    node.getAttribute && node.getAttribute('data-testid') === 'announcement' &&
							    (node.textContent || '').indexOf('Customer ended the conversation') > -1) {
								clientLogs.log('Customer ended the chat!');
							}
						}
					}
				}
			});

			observer.observe(iframeDoc.body, { childList: true, subtree: true, characterData: true });
			clientLogs.log('Chat end observer attached to Webex Engage iframe.');
		}

		function findEngageIframe() {
			var iframes = parentDoc.querySelectorAll('iframe');
			for (var i = 0; i < iframes.length; i++) {
				try {
					var iframeDoc = iframes[i].contentDocument || iframes[i].contentWindow.document;
					if (iframeDoc && iframeDoc.querySelector('.webex-engage, #liveRegion, [data-testid="announcement"]')) {
						attachObserver(iframeDoc);
						return true;
					}
				} catch (e) {
					// cross-origin iframe, skip
				}
			}
			return false;
		}

		if (!findEngageIframe()) {
			clientLogs.log('Webex Engage iframe not ready yet, will retry...');
			var retryCount = 0;
			var retryInterval = setInterval(function () {
				retryCount++;
				if (findEngageIframe() || retryCount >= 30) {
					clearInterval(retryInterval);
					if (retryCount >= 30) {
						clientLogs.log('Chat end observer: gave up after 30 retries.');
					}
				}
			}, 2000);
		}
	}


    /** @scope finesse.modules.Gadget */
    return {
		
		changeToNotReady : function () {
			var reasonCode = {id:1};
			media.setState(states.NOT_READY, reasonCode);
		},
		
		
		changeToReady : function () {
		    media.setState(states.READY);
		},
		
		
        /**
         * Sets the user state on the media that this gadget is configured for.
         */
        setUserStateOnMedia : function (state) {
            //clear any previous error message
            //uiMsg.hideBanner();

            //state change will trigger media change notification, which will call handleMediaChange and then re-render
            if (state === 'READY') {
                media.setState(states.READY);
            } else if (state === 'NOT_READY') {
                //hardcoding for now until we do UX for how to do this
                var reasonCode = null;//{id:2};
                media.setState(states.NOT_READY, reasonCode);
            }
        },
		
		
		logoutA : function(){
			clientLogs.log("send logout request...");
			var params = {
			    handlers: {
					error: function (err) {
					    clientLogs.log("Logout error:" + err);
					}
			    }
			};

			try{
			//hardcoding for now until we do UX for how to do this
			var reasonCode = null;//{id:1};
			media.logout(reasonCode, params);
			} catch (err){
				clientLogs.log("Logout error2:" + err);
			}
			clientLogs.log("Logging out complete!");
		},



        /**
         * Logs out the agent out of the MRD that this gadget is configured for.
         */
        logoutFromMrd : function() {
			clientLogs.log("Logging out of Chat...");
			
			
			clientLogs.log("setRoutability to false...");
			try{
				var params = {
				    routable: false,
				    handlers: {
						success: function () {
						    clientLogs.log("setRoutable success");
							
							clientLogs.log("send logout request...");
							var params = {
							    handlers: {
									error: function (err) {
									    clientLogs.log("Logout error:" + err);
									}
							    }
							};

							try {
								var reasonCode = null;//{id:1}; //hardcoding for now until we do UX for how to do this
								media.logout(reasonCode, params);
							} catch (err){
								clientLogs.log("Logout error2:" + err);
							}
							clientLogs.log("Logging out complete!");
						},
						error: function (err) {
						    clientLogs.log("setRoutability error:" + JSON.stringify(err));
						}
				    }
				};
				media.setRoutable(params);
			} catch(err){
				clientLogs.log("Logout setRoutable error: " + err);
			}
			
        },
		

        /**
         * Login an agent to the MRD that this gadget is configured for.
         * If the agent is successfully logged in to the media it will load
         * the dialogs for the agent on that media, otherwise an error will be thrown.
         */
        loginToMrd : function() {
            var params = {
                maxDialogLimit: mediaOptions.maxDialogLimit,
                interruptAction: mediaOptions.interruptAction,
                dialogLogoutAction: mediaOptions.dialogLogoutAction,
                handlers: {
                    error: handleMediaError
                }
            };
            media.login(params);
        },

		
        /**
         * Set agent to routable or not routable based on checkbox.
         *
         * Call media API whenever checkbox is checked or unchecked (called from onClick handler in TaskManagementGadget.xml).
         */
        setRoutability : function(isRoutable) {

            var params = {
                routable: isRoutable,
                handlers: {
                    error: handleMediaError
                }
            };

            media.setRoutable(params);
        },

        /**
         * Performs all initialization for this gadget
         */
        init : function () {
			console.log("ChatHelper inside of init...");
			
			hideComponents();
			
            config = finesse.gadget.Config;

            clientLogs = finesse.cslogger.ClientLogger;   // declare clientLogs

            /** Initialize private references */
            utils = finesse.utilities.Utilities;
			
			
			
		//	checkGadgetQueryParams();
			
			console.log("ChatHelper media options next...");
			
			mrdID = "5016";
		
            mediaOptions = {
                maxDialogLimit: "1",
                interruptAction: finesse.restservices.InterruptActions.IGNORE,
                dialogLogoutAction: finesse.restservices.DialogLogoutActions.CLOSE
            };
			
			console.log("ChatHelper After media options...");


            // Initiate the ClientServices and load the user object.  ClientServices are
            // initialized with a reference to the current configuration.
            finesse.clientservices.ClientServices.init(config);
			
			console.log("ChatHelper After ClientServices.init");

            clientLogs.init(gadgets.Hub, "ChatHelper"); //this gadget id will be logged as a part of the message
			watchForChatEnd();
            user = new finesse.restservices.User({
                id: config.id,
                onLoad : handleUserLoad,
                onChange : handleUserChange
            });
			
			console.log("ChatHelper Pre agentId");
            
            agentId = config.id;
			clientLogs.log("Logger Initialized!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
			
            clientLogs.log("config.id: " + config.id);  

            // Initiate the ContainerServices and add a handler for when the tab is visible
            // to adjust the height of this gadget in case the tab was not visible
            // when the html was rendered (adjustHeight only works when tab is visible)

            containerServices = finesse.containerservices.ContainerServices.init();
            containerServices.addHandler(finesse.containerservices.ContainerServices.Topics.ACTIVE_TAB, function(){
				gadgets.window.adjustHeight();
                clientLogs.log("Chat Helper Gadget is now visible");  // log to Finesse logger
            });
            containerServices.makeActiveTabReq();
			
			gadgets.window.adjustHeight();
			console.log("ChatHelper Init complete!!");
        }
    };
}(jQuery));
