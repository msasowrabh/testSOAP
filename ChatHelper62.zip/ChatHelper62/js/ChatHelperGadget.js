var code_version = "2/27/2026 9:17 PM";
var clientLogs;
var config;
var agentId;
	
		
var finesse = finesse || {};

/** @namespace */
finesse.modules = finesse.modules || {};
finesse.modules.Gadget = (function ($) {
	clientLogs = finesse.cslogger.ClientLogger;
	
    var user, media, utils, mediaDialogs, maxDialogs, mediaList,
        activeDialog,
        interruptAction, dialogLogoutAction, mrdID, mrdName,
        states = finesse.restservices.Media.States,
        prefs = new gadgets.Prefs(),
		
		
        /**
         * Prefix for call variables in dialog.mediaProperties
         */
        CALL_VARIABLE_PREFIX = "callVariable",
        /**
         * Store the maxDialogLimit, interruptAction, and dialogLogoutAction options to be used with this gadget's
         * media object.
         */
        mediaOptions,
        /**
         * Stores whether or not the application is connected to the Finesse server.
         */
        connected = true,
        /**
         * Track whether the media associated with this gadget has been interrupted.
         */
        interrupted = false,
        /**
         * Alert sound state. audioCtx stays null until the browser lets us create it.
         */
        soundEnabled = true,
        audioCtx = null,
        /**
         * Last time we played the new-message tone, used to collapse bursts.
         */
        lastMessageSoundTs = 0,
        /**
         * Suppresses the new-chat tone while we replay dialogs that already existed at load.
         */
        suppressNewChatSound = false,


    /**
     *	Callback used upon the load of a media object. This should be used for anything that only needs to be
     *  executed once during initialization.
     */
    handleMediaLoad = function(_media) {
		clientLogs.log("in handleMediaLoad...");

        loadMediaDialogs(_media);
        //if user signed out of this media or state is unknown, show the sign in button
        if (_media.getState() === states.LOGOUT) {
			clientLogs.log("user logged out.");
		} else if (_media.getState() === undefined ) {
            clientLogs.log("user in undefined state.");
        } else {
           clientLogs.log("in handleMediaLoad else...");
        }
    },
	
	
	handleMediaSuccess = function(obj){
	    //clear any previous error message
		clientLogs.log("in handleMediaSuccess...");
	},

	/**
	 *	Handler called upon a failed action on the media.
	 */
	handleMediaError = function(rsp) {
	    var errorMessage = rsp.object.ApiErrors.ApiError.ErrorMessage;
	    var msg = prefs.getMsg(errorMessage) || errorMessage;

	    if(errorMessage == "E_ARM_STAT_AGENT_ALREADY_LOGGED_IN") {
	            loadMediaDialogs(media);
	            return;
	    }

	    showError("Operation Failed: " + msg);
	},

	
    /**
     *  Callback used when a media is changed. This is misleading because it will be triggered when any
     *  media changes, not just the one associated with this instance of the gadget.
     */
    handleMediaChange = function(_media) {
        //only update if the notification is for this gadgets's specific media
        //since there could be multiple media gadgets corresponding to a different media id
        
        if(mrdID === _media._data.id) {
			
			var xState = _media._data.state;
            clientLogs.log("in handleMediaChange, this is our Chat mrdID: " + mrdID);
			clientLogs.log("Chat State: " + xState);
			setIndicator(xState);
			gadgets.window.adjustHeight();
        }
    },
	
	
	setIndicator = function (state) {
		var $indicator = window.parent.jQuery("#chatStatus");
		window.parent.jQuery("#chatStatusText").text("Chat: " + state);
	    $indicator.removeClass("status-ready status-notready status-logout");
	    if (state === "READY") {
	        $indicator.addClass("status-ready");
	    }
	    else if (state === "NOT_READY") {
	        $indicator.addClass("status-notready");
	    }
	    else {
	        $indicator.addClass("status-logout");
	    }
	},

	
	setVoiceIndicator = function (state) {
		var $indicator = window.parent.jQuery("#voiceStatus");
		window.parent.jQuery("#voiceStatusText").text("Voice: " + state);
	    $indicator.removeClass("status-ready status-notready status-logout");
	    if (state === "READY") {
	        $indicator.addClass("status-ready");
	    }
	    else if (state === "NOT_READY") {
	        $indicator.addClass("status-notready");
	    }
	    else {
	        $indicator.addClass("status-logout");
	    }
	},

    /**
     * Load the current user's dialogs.
     * @return {undefined}
     */
    loadMediaDialogs = function (_media) {
        mediaDialogs = _media.getMediaDialogs({
            onCollectionAdd : handleMediaDialogsAdd,
            onCollectionDelete : handleMediaDialogsDelete,
            onLoad: handleMediaDialogsLoad
        });
    },

	
    handleMediaDialogsLoad = function() {
  
        var dialogCollection = mediaDialogs.getCollection(), id;

        // These dialogs already existed before the gadget loaded, so don't alert on them.
        suppressNewChatSound = true;
        for (id in dialogCollection) {
            var dialog = dialogCollection[id];
            handleMediaDialogsAdd(dialog);
        }
        suppressNewChatSound = false;
    },
	
	
	hideComponents = function () {

		    window.parent.jQuery('#agent-voice-state').hide();
		    window.parent.jQuery('#nonvoice-state-menu').hide();

			if (!window.parent.jQuery('#chatStatusStyles').length) {
			    window.parent.jQuery('head').append(
			        '<style id="chatStatusStyles">' +

						/* Container (keeps everything left, spaced, aligned) */
						'#chatStatusContainer{' +
							'display:flex;' +
							'align-items:center;' +
							'gap:10px;' +
							'margin-right:10px;' +
						'}' +

						/* Pill base */
						'.statusPill{' +
							'display:inline-flex;' +
							'align-items:center;' +
							'justify-content:center;' +
							'height:28px;' +
							'min-width:180px;' +
							'padding:0 10px;' +
							'border-radius:14px;' +
							'font-size:12px;' +
							'font-weight:700;' +
							'color:#ffffff;' +
							'line-height:28px;' +
							'box-shadow:0 1px 2px rgba(0,0,0,0.12);' +
							'border:1px solid rgba(0,0,0,0.12);' +
							'white-space:nowrap;' +
						'}' +

			            '.status-ready{ background-color:#16a34a; }' +      /* Green */
			            '.status-notready{ background-color:#dc2626; }' +   /* Red */
			            '.status-logout{ background-color:#60a5fa; }' +     /* Light Blue */

						/* Select styling (closer to Finesse look) */
						'#stateSelect{' +
							'height:28px;' +
							'min-width:220px;' +
							'max-width:300px;' +
							'padding:0 10px;' +
							'border-radius:4px;' +
							'border:1px solid #c9ced6;' +
							'background:#ffffff;' +
							'color:#2f3b4a;' +
							'font-size:12px;' +
							'font-weight:600;' +
							'outline:none;' +
						'}' +
						'#stateSelect:hover{' +
							'border-color:#9aa4b2;' +
						'}' +
						'#stateSelect:focus{' +
							'border-color:#2b6cb0;' +
							'box-shadow:0 0 0 2px rgba(43,108,176,0.18);' +
						'}' +

			        '</style>'
			    );
			}

			/* Remove any previous injection so you don't get duplicates */
			window.parent.jQuery('#chatStatusContainer').remove();

		    window.parent.jQuery('.header-right-container').prepend(
		        '<div id="chatStatusContainer">' +
					
					'<div id="chatStatus" class="statusPill status-logout"><span id="chatStatusText">Chat: Logged Out</span></div>' +
					'<div id="voiceStatus" class="statusPill status-logout"><span id="voiceStatusText">Voice: Logged Out</span></div>' +
					
					'<select id="stateSelect" name="stateSelect">' +
						'<option value="CHAT_READY">Chat Ready</option>' +
						'<option value="CHAT_NOT_READY">Chat Not Ready</option>' +
						'<option value="VOICE_READY">Voice Ready</option>' +
						'<option value="VOICE_NOT_READY">Voice Not Ready</option>' +
						'<option value="ALL_READY">All Ready</option>' +
						'<option value="ALL_NOT_READY">All Not Ready</option>' +
					'</select>' +
				'</div>'
		    );

		    // IMPORTANT: bind to the PARENT document (or bind directly to #stateSelect in parent)
		    window.parent.jQuery(window.parent.document)
		        .off("change", "#stateSelect")
		        .on("change", "#stateSelect", function () {
		            var selectedValue = window.parent.jQuery(this).val();

					clientLogs.log("State selectedValue: " + selectedValue);

					if (selectedValue == 'CHAT_READY') {
					    finesse.modules.Gadget.changeToReady();
					}

					if (selectedValue == 'CHAT_NOT_READY') {
					    finesse.modules.Gadget.changeToNotReady();
					}

		            if (selectedValue == "ALL_READY") {
		                finesse.modules.Gadget.changeToReady();
						setVoiceReady();
		            }

					if (selectedValue == "ALL_NOT_READY") {
					    finesse.modules.Gadget.changeToNotReady();
						setVoiceNotReady();
					}

					if (selectedValue == 'VOICE_READY') {
						setVoiceReady();
					}

		            if (selectedValue == 'VOICE_NOT_READY') {
						setVoiceNotReady();
		            }

		            // finesse.modules.Gadget.logoutFromMrd();
		        });

		},
		
	

	
	setVoiceReady = function () {
		try {
		    user.setState("READY", "", {
		        success: function () {
		            clientLogs.log("Voice set to READY");
		        },
		        error: function (err) {
		            clientLogs.log("Ready error: " + err);
		        }
		    });
		} catch (err) {
		    clientLogs.log(err);
		}
	},
	
	
	setVoiceNotReady = function(){
		try {
			var reasonCode = {id:1};
			user.setState("NOT_READY", reasonCode, {
			    success: function () {
			        clientLogs.log("Voice set to READY");
			    },
			    error: function (err) {
			        clientLogs.log("Ready error: " + err);
			    }
			});
		} catch (err) {
		    clientLogs.log(err);
		}
	},


	/**
	 * Creates the AudioContext and keeps it running. Browsers refuse to play audio
	 * until the page has seen a user gesture, so we also re-try the resume on the
	 * agent's first click/keypress anywhere in the desktop.
	 */
	unlockAudio = function () {
		var resume = function (evt) {
			var trigger = (evt && evt.type) ? evt.type : "init";
			try {
				if (!audioCtx) {
					var Ctx = window.AudioContext || window.webkitAudioContext;
					if (!Ctx) {
						clientLogs.log("SOUND: WebAudio not supported, alert sounds disabled");
						return;
					}
					audioCtx = new Ctx();
					clientLogs.log("SOUND: AudioContext created via " + trigger + ", state=" + audioCtx.state);
				}
				if (audioCtx.state === "suspended") {
					clientLogs.log("SOUND: AudioContext suspended, resuming via " + trigger);
					audioCtx.resume().then(function () {
						clientLogs.log("SOUND: AudioContext resumed, state=" + audioCtx.state);
					}, function (err) {
						clientLogs.log("SOUND: AudioContext resume rejected: " + err);
					});
				}
			} catch (err) {
				clientLogs.log("SOUND: unlockAudio error: " + err);
			}
		};

		resume();

		try {
			document.addEventListener("click", resume, true);
			window.parent.document.addEventListener("click", resume, true);
			window.parent.document.addEventListener("keydown", resume, true);
		} catch (err) {
			clientLogs.log("unlockAudio listener error: " + err);
		}
	},


	/**
	 * Plays a sequence of tones back to back. Each tone is {freq, dur, vol}.
	 * label is used only for logging so we can tell the two alerts apart.
	 */
	playTones = function (label, tones) {
		clientLogs.log("SOUND: play requested [" + label + "] soundEnabled=" + soundEnabled +
			" audioCtx=" + (audioCtx ? audioCtx.state : "null"));

		if (!soundEnabled) {
			clientLogs.log("SOUND: skipped [" + label + "] — sounds are turned off");
			return;
		}
		if (!audioCtx) {
			clientLogs.log("SOUND: skipped [" + label + "] — no AudioContext yet (needs a user click first)");
			return;
		}

		try {
			if (audioCtx.state === "suspended") {
				clientLogs.log("SOUND: context suspended at play time [" + label + "], attempting resume");
				audioCtx.resume();
			}

			var startAt = audioCtx.currentTime + 0.02;
			for (var i = 0; i < tones.length; i++) {
				var tone = tones[i];
				var osc = audioCtx.createOscillator();
				var gain = audioCtx.createGain();

				osc.type = "sine";
				osc.frequency.value = tone.freq;

				// Ramp in/out so the tone doesn't click.
				gain.gain.setValueAtTime(0.0001, startAt);
				gain.gain.exponentialRampToValueAtTime(tone.vol, startAt + 0.02);
				gain.gain.exponentialRampToValueAtTime(0.0001, startAt + tone.dur);

				osc.connect(gain);
				gain.connect(audioCtx.destination);
				osc.start(startAt);
				osc.stop(startAt + tone.dur + 0.02);

				startAt += tone.dur;
			}

			clientLogs.log("SOUND: scheduled " + tones.length + " tone(s) [" + label + "]");
		} catch (err) {
			clientLogs.log("SOUND: playTones error [" + label + "]: " + err);
		}
	},


	/**
	 * Rising three note chime — a new chat has been routed to this agent.
	 */
	playNewChatSound = function () {
		playTones("new-chat", [
			{ freq: 659,  dur: 0.16, vol: 0.25 },
			{ freq: 880,  dur: 0.16, vol: 0.25 },
			{ freq: 1175, dur: 0.22, vol: 0.25 }
		]);
	},


	/**
	 * Short blip — the customer sent a message on an existing chat.
	 */
	playNewMessageSound = function () {
		var now = new Date().getTime();

		// A task switch re-renders the whole transcript, which would otherwise
		// fire one blip per historical message.
		var sinceLast = now - lastMessageSoundTs;
		if (sinceLast < 1200) {
			clientLogs.log("SOUND: skipped [new-message] — throttled, only " + sinceLast + "ms since last");
			return;
		}
		lastMessageSoundTs = now;

		playTones("new-message", [
			{ freq: 880, dur: 0.10, vol: 0.20 },
			{ freq: 1046, dur: 0.12, vol: 0.20 }
		]);
	},


	/**
	 * True when the node is (or contains) an inbound customer message bubble.
	 * Agent replies use chat-message-mt and are ignored.
	 */
	isInboundMessageNode = function (node) {
		try {
			if (node.getAttribute && node.getAttribute("data-testid") === "chat-message-mo") {
				return true;
			}
			if (node.querySelector && node.querySelector('[data-testid="chat-message-mo"]')) {
				return true;
			}
		} catch (e) {}
		return false;
	},
	
	
	
	
	
	
	
	
	

	
    /**
     * Handler that is called anytime a dialog is added for the user on all media.
     */
    handleMediaDialogsAdd = function (dialog) {
		
		
        //this gets called whenever there's a dialog change for all media
        //only update if the notification is for this gadgets's specific media
        //since there could be multiple media gadgets corresponding to a different media id
        if(mrdID === dialog._data.mediaProperties.mediaId) {
			clientLogs.log("in handleMediaDialogsAdd...");
			activeDialog = dialog;

			if (!suppressNewChatSound) {
				playNewChatSound();
			}
        }
    },

	
    /**
     * Handler called anytime a dialog is ended
     */
    handleMediaDialogsDelete = function (dialog) {
		clientLogs.log("in handleMediaDialogsDelete...");
		
        if(mrdID === dialog._data.mediaProperties.mediaId) {
			activeDialog = null;
            adjustGadgetHeight();
        }
    },

	
    /**
     * Handler for the onLoad of a User object.  This occurs when the User object is initially read
     * from the Finesse server.  Any once only initialization should be done within this function.
     */
    handleUserLoad = function (_user) {
		clientLogs.log("in handleUserLoad...");
		
		setTimeout(function() {
			try {
				clientLogs.log("ChatHelperGadget.js version: " + code_version);
			} catch (err){
				clientLogs.log("Show version info error: " + err);
			}
			
			//media.refresh();
			var state = media.getState();
			setIndicator(state);
			
			var currentState = user.getState();
			setVoiceIndicator(currentState);
			
		}, 3000);
		
        mediaList = user.getMediaList( {
            onLoad: handleMediaListLoad
        });
    },
    
    
    handleUserChange = function(userevent) {
		var currentState = user.getState();
		setVoiceIndicator(currentState);
		clientLogs.log("CurrentState: " + currentState);
	},
	
	
	checkGadgetQueryParams = function() {
		clientLogs.log("in checkGadgetQueryParams...");
		clientLogs.log("These values stored in Finesse admin desktop layout.");
		
	    //First get just the URI for this gadget out of the full finesse URI and decode it.
	    var gadgetURI = decodeURIComponent(getUrlVars(location.search)["url"]);

	    //Now get the individual query params from the gadget URI
	    var decodedGadgetURI = getUrlVars(gadgetURI);
	    mrdID = "5016";
	    mrdName = "Test";
	    maxDialogs = "1";
	    interruptAction = finesse.restservices.InterruptActions.ACCEPT;
	    dialogLogoutAction = finesse.restservices.DialogLogoutActions.CLOSE;
	    
	    
	    clientLogs.log("mrdID: " + mrdID);
	    clientLogs.log("mrdName: " + mrdName);
	    clientLogs.log("maxDialogs: " + maxDialogs);

	    //If no MRD ID is configured or it's not a number we want to throw an error during init.
	    if (!mrdID || isNaN(mrdID)) {
	        return false;
	    }

	    //If there's no max dialogs configured or the value is not a number then default it to 5.
	    if (!maxDialogs || isNaN(maxDialogs)) {
	        maxDialogs = "1";
	    }

	    //If there's no interruptAction configured or the value is not valid, default to "ACCEPT".
	    if (!finesse.restservices.InterruptActions.isValidAction(interruptAction)) {
	        interruptAction = finesse.restservices.InterruptActions.ACCEPT;
	    }

	    if (!finesse.restservices.DialogLogoutActions.isValidAction(dialogLogoutAction)) {
	        dialogLogoutAction = finesse.restservices.DialogLogoutActions.CLOSE;
	    }

	    //If there's no dialogLogoutAction configured or the value is not valid, default to "CLOSE".
	    if (!dialogLogoutAction || dialogLogoutAction.toUpperCase()!=="CLOSE" && dialogLogoutAction.toUpperCase()!=="TRANSFER") {
	        dialogLogoutAction = "CLOSE";
	    }

	   
	},
	
	showError = function (errText) {
		clientLogs.log(errText)
	},
	
	

    /**
     * Handler for the onLoad of a MediaList object.  This occurs when the MediaList object is initially read
     * from the Finesse server.
     */
    handleMediaListLoad = function (_mediaList) {
		clientLogs.log("in handleMediaListLoad...");

		try {
			if (_mediaList == null || _mediaList.length < 1){
				clientLogs.log("_mediaList is null!");
			}
		} catch(err){
			clientLogs.log("err1xa: " + err);
		}
		
        try {
            //get the media with the specified id
            media = _mediaList.getMedia({
                id: mrdID,
                onLoad: handleMediaLoad,
                onError: handleMediaError,
                onChange: handleMediaChange,
                mediaOptions: mediaOptions
            });
        } catch ( error ) {
			clientLogs.log("error 2xb: " + error);
            showError(mrdID + " Media Channel Not Found.");
        }
    },


	watchForChatEnd = function () {
		var parentDoc = window.parent.document;
		var observedDocs = [];
		var mdcDoc = null;

		function onChatEnded() {
			clientLogs.log('Customer ended the chat!');
		}

		// Polling fallback — every 2s check #liveRegion and announcements directly
		function startPolling() {
			setInterval(function () {
				var docsToScan = mdcDoc ? [mdcDoc] : [];
				// also scan any nested iframes we found later
				if (mdcDoc) {
					try {
						var frames = mdcDoc.querySelectorAll('iframe');
						for (var k = 0; k < frames.length; k++) {
							try {
								var fd = frames[k].contentDocument || frames[k].contentWindow.document;
								if (fd && fd.body) docsToScan.push(fd);
							} catch(e) {}
						}
					} catch(e) {}
				}

				for (var d = 0; d < docsToScan.length; d++) {
					try {
						var doc = docsToScan[d];

						// log liveRegion text so we can see what it actually contains
						var lr = doc.getElementById('liveRegion');
						if (lr && lr.textContent) {
							clientLogs.log('POLL liveRegion: ' + lr.textContent);
							if (lr.textContent.indexOf('Customer ended the conversation') > -1) {
								onChatEnded();
							}
						}

						// check announcement nodes
						var anns = doc.querySelectorAll('[data-testid="announcement"]');
						for (var a = 0; a < anns.length; a++) {
							var txt = anns[a].textContent || '';
							if (txt.indexOf('Customer ended the conversation') > -1) {
								onChatEnded();
							}
						}
					} catch(e) {}
				}
			}, 2000);
		}

		function createObserver(doc) {
			// The transcript paints in right after we attach; ignore that first burst
			// so we don't alert on messages that were already on screen.
			var attachedAt = new Date().getTime();

			var obs = new MutationObserver(function (mutations) {
				for (var i = 0; i < mutations.length; i++) {
					var mutation = mutations[i];

					// #liveRegion text changed
					if (mutation.type === 'characterData' || mutation.type === 'childList') {
						var t = mutation.target;
						var liveNode = (t.id === 'liveRegion') ? t :
						               (t.parentNode && t.parentNode.id === 'liveRegion') ? t.parentNode : null;
						if (liveNode && (liveNode.textContent || '').indexOf('Customer ended the conversation') > -1) {
							onChatEnded();
							continue;
						}
					}

					if (mutation.addedNodes) {
						for (var j = 0; j < mutation.addedNodes.length; j++) {
							var node = mutation.addedNodes[j];
							if (node.nodeType !== 1) continue;

							// new inbound message from the customer
							if (new Date().getTime() - attachedAt > 2000 && isInboundMessageNode(node)) {
								playNewMessageSound();
							}

							// announcement node
							if (node.getAttribute && node.getAttribute('data-testid') === 'announcement' &&
							    (node.textContent || '').indexOf('Customer ended the conversation') > -1) {
								onChatEnded();
							}

							// new iframe added dynamically
							if (node.nodeName === 'IFRAME') {
								clientLogs.log('New IFRAME added inside ManageDigitalChannel!');
								(function (frame) {
									setTimeout(function () { tryObserveIframe(frame); }, 1500);
								}(node));
							}
						}
					}
				}
			});
			obs.observe(doc.body, { childList: true, subtree: true, characterData: true });
		}

		function tryObserveIframe(frame) {
			try {
				var doc = frame.contentDocument || frame.contentWindow.document;
				if (!doc || !doc.body) return;
				for (var i = 0; i < observedDocs.length; i++) {
					if (observedDocs[i] === doc) return;
				}
				observedDocs.push(doc);
				clientLogs.log('Observing nested iframe src=' + (frame.src || '(no src)'));
				createObserver(doc);
				var deeper = doc.querySelectorAll('iframe');
				for (var j = 0; j < deeper.length; j++) {
					tryObserveIframe(deeper[j]);
				}
			} catch (e) {}
		}

		function findManageDigitalChannel() {
			var iframes = parentDoc.querySelectorAll('iframe');
			for (var i = 0; i < iframes.length; i++) {
				var frame = iframes[i];
				if ((frame.src || '').indexOf('ManageDigitalChannel') === -1) continue;
				try {
					var doc = frame.contentDocument || frame.contentWindow.document;
					if (!doc || !doc.body) {
						clientLogs.log('ManageDigitalChannel iframe found but not ready yet.');
						return false;
					}
					mdcDoc = doc;
					observedDocs.push(doc);
					createObserver(doc);

					var nested = doc.querySelectorAll('iframe');
					clientLogs.log('ManageDigitalChannel attached. Nested iframes: ' + nested.length);
					for (var j = 0; j < nested.length; j++) {
						clientLogs.log('  nested[' + j + '] src=' + (nested[j].src || '(no src)'));
						tryObserveIframe(nested[j]);
					}
					startPolling();
					return true;
				} catch (e) {
					clientLogs.log('ManageDigitalChannel error: ' + e.message);
				}
			}
			return false;
		}

		if (!findManageDigitalChannel()) {
			clientLogs.log('ManageDigitalChannel not found yet, retrying...');
			var retryCount = 0;
			var retryInterval = setInterval(function () {
				retryCount++;
				if (findManageDigitalChannel() || retryCount >= 30) {
					clearInterval(retryInterval);
					if (retryCount >= 30) {
						clientLogs.log('Chat end observer: gave up after 30 retries.');
					}
				}
			}, 2000);
		}
	}


    /** @scope finesse.modules.Gadget */
    return {
		
		changeToNotReady : function () {
			var reasonCode = {id:1};
			media.setState(states.NOT_READY, reasonCode);
		},
		
		
		changeToReady : function () {
		    media.setState(states.READY);
		},


		/**
		 * Turns the new chat / new message alert sounds on or off.
		 */
		setSoundEnabled : function (enabled) {
			soundEnabled = !!enabled;
			clientLogs.log("alert sounds enabled: " + soundEnabled);
		},


		/**
		 * Plays the new message tone so the agent can check their volume.
		 */
		testSound : function () {
			playNewChatSound();
		},
		
		
        /**
         * Sets the user state on the media that this gadget is configured for.
         */
        setUserStateOnMedia : function (state) {
            //clear any previous error message
            //uiMsg.hideBanner();

            //state change will trigger media change notification, which will call handleMediaChange and then re-render
            if (state === 'READY') {
                media.setState(states.READY);
            } else if (state === 'NOT_READY') {
                //hardcoding for now until we do UX for how to do this
                var reasonCode = null;//{id:2};
                media.setState(states.NOT_READY, reasonCode);
            }
        },
		
		
		logoutA : function(){
			clientLogs.log("send logout request...");
			var params = {
			    handlers: {
					error: function (err) {
					    clientLogs.log("Logout error:" + err);
					}
			    }
			};

			try{
			//hardcoding for now until we do UX for how to do this
			var reasonCode = null;//{id:1};
			media.logout(reasonCode, params);
			} catch (err){
				clientLogs.log("Logout error2:" + err);
			}
			clientLogs.log("Logging out complete!");
		},



        /**
         * Logs out the agent out of the MRD that this gadget is configured for.
         */
        logoutFromMrd : function() {
			clientLogs.log("Logging out of Chat...");
			
			
			clientLogs.log("setRoutability to false...");
			try{
				var params = {
				    routable: false,
				    handlers: {
						success: function () {
						    clientLogs.log("setRoutable success");
							
							clientLogs.log("send logout request...");
							var params = {
							    handlers: {
									error: function (err) {
									    clientLogs.log("Logout error:" + err);
									}
							    }
							};

							try {
								var reasonCode = null;//{id:1}; //hardcoding for now until we do UX for how to do this
								media.logout(reasonCode, params);
							} catch (err){
								clientLogs.log("Logout error2:" + err);
							}
							clientLogs.log("Logging out complete!");
						},
						error: function (err) {
						    clientLogs.log("setRoutability error:" + JSON.stringify(err));
						}
				    }
				};
				media.setRoutable(params);
			} catch(err){
				clientLogs.log("Logout setRoutable error: " + err);
			}
			
        },
		

        /**
         * Login an agent to the MRD that this gadget is configured for.
         * If the agent is successfully logged in to the media it will load
         * the dialogs for the agent on that media, otherwise an error will be thrown.
         */
        loginToMrd : function() {
            var params = {
                maxDialogLimit: mediaOptions.maxDialogLimit,
                interruptAction: mediaOptions.interruptAction,
                dialogLogoutAction: mediaOptions.dialogLogoutAction,
                handlers: {
                    error: handleMediaError
                }
            };
            media.login(params);
        },

		
        /**
         * Set agent to routable or not routable based on checkbox.
         *
         * Call media API whenever checkbox is checked or unchecked (called from onClick handler in TaskManagementGadget.xml).
         */
        setRoutability : function(isRoutable) {

            var params = {
                routable: isRoutable,
                handlers: {
                    error: handleMediaError
                }
            };

            media.setRoutable(params);
        },

        /**
         * Performs all initialization for this gadget
         */
        init : function () {
			console.log("ChatHelper inside of init...");
			
			hideComponents();
			
            config = finesse.gadget.Config;

            clientLogs = finesse.cslogger.ClientLogger;   // declare clientLogs

            /** Initialize private references */
            utils = finesse.utilities.Utilities;
			
			
			
		//	checkGadgetQueryParams();
			
			console.log("ChatHelper media options next...");
			
			mrdID = "5016";
		
            mediaOptions = {
                maxDialogLimit: "1",
                interruptAction: finesse.restservices.InterruptActions.IGNORE,
                dialogLogoutAction: finesse.restservices.DialogLogoutActions.CLOSE
            };
			
			console.log("ChatHelper After media options...");


            // Initiate the ClientServices and load the user object.  ClientServices are
            // initialized with a reference to the current configuration.
            finesse.clientservices.ClientServices.init(config);
			
			console.log("ChatHelper After ClientServices.init");

            clientLogs.init(gadgets.Hub, "ChatHelper"); //this gadget id will be logged as a part of the message
			unlockAudio();
			watchForChatEnd();
            user = new finesse.restservices.User({
                id: config.id,
                onLoad : handleUserLoad,
                onChange : handleUserChange
            });
			
			console.log("ChatHelper Pre agentId");
            
            agentId = config.id;
			clientLogs.log("Logger Initialized!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
			
            clientLogs.log("config.id: " + config.id);  

            // Initiate the ContainerServices and add a handler for when the tab is visible
            // to adjust the height of this gadget in case the tab was not visible
            // when the html was rendered (adjustHeight only works when tab is visible)

            containerServices = finesse.containerservices.ContainerServices.init();
            containerServices.addHandler(finesse.containerservices.ContainerServices.Topics.ACTIVE_TAB, function(){
				gadgets.window.adjustHeight();
                clientLogs.log("Chat Helper Gadget is now visible");  // log to Finesse logger
            });
            containerServices.makeActiveTabReq();
			
			gadgets.window.adjustHeight();

			(function attachMessageListener() {
				var iframes = window.parent.document.querySelectorAll('iframe');
				for (var i = 0; i < iframes.length; i++) {
					if ((iframes[i].src || '').indexOf('ManageDigitalChannel') === -1) continue;
					try {
						iframes[i].contentWindow.addEventListener('onMessageReceived', function(event) {
							if (event.detail && event.detail.message === '$$$$CLOSECHAT$$$$') {
								clientLogs.log("caught chat end event, conversationId: " + event.detail.conversationId);
								if (activeDialog) {
									activeDialog.setTaskState(finesse.restservices.MediaDialog.TaskActions.WRAP_UP, {
										success: function() { clientLogs.log("moved to WRAP_UP"); },
										error: function(err) { clientLogs.log("WRAP_UP error: " + JSON.stringify(err)); }
									}, null);
								} else {
									clientLogs.log("WRAP_UP skipped — no active dialog");
								}
							}
						});

						iframes[i].contentWindow.addEventListener('taskitem-click', function(event) {
							var targetId = event.target && event.target.id;
							if (!targetId) return;
							clientLogs.log("taskitem-click: targetId=" + targetId);
							if (mediaDialogs) {
								var collection = mediaDialogs.getCollection();
								if (collection[targetId]) {
									activeDialog = collection[targetId];
									clientLogs.log("activeDialog updated to: " + targetId);
								} else {
									clientLogs.log("taskitem-click: no dialog found for id: " + targetId);
								}
							}
						});

						clientLogs.log("onMessageReceived listener attached to ManageDigitalChannel");
						return;
					} catch(e) {
						clientLogs.log("attachMessageListener error: " + e.message);
					}
				}
				// ManageDigitalChannel not ready yet, retry
				clientLogs.log("ManageDigitalChannel not found, retrying listener attach...");
				setTimeout(attachMessageListener, 2000);
			}());

			console.log("ChatHelper Init complete!!");
        }
    };
}(jQuery));
