var finesse = finesse || {};
finesse.modules = finesse.modules || {};

finesse.modules.Gadget = (function ($) {

    var user, media, mediaDialogs, mrdID = "";

    function log(msg) {
        finesse.cslogger.ClientLogger.log(msg);
    }

    /* ==============================
       DIALOG HANDLERS
    ============================== */

    function handleDialogAdd(dialog) {
        var mediaId = dialog._data.mediaProperties && dialog._data.mediaProperties.mediaId;
        if (mediaId !== mrdID) return;

        log("chat arrived id=" + dialog._data.id + " state=" + dialog._data.state);
    }

    function handleDialogChange(dialog) {
        var mediaId = dialog._data.mediaProperties && dialog._data.mediaProperties.mediaId;
        if (mediaId !== mrdID) return;

        log("chat changed id=" + dialog._data.id + " state=" + dialog._data.state);
    }

    function handleDialogDelete(dialog) {
        log("chat ended id=" + dialog._data.id);
    }

    function handleDialogsLoad() {
        var dialogs = mediaDialogs.getCollection();
        log("dialogs loaded count=" + Object.keys(dialogs).length);
        for (var id in dialogs) {
            handleDialogAdd(dialogs[id]);
        }
    }

    function loadDialogs() {
        mediaDialogs = media.getMediaDialogs({
            onCollectionAdd: handleDialogAdd,
            onCollectionChange: handleDialogChange,
            onCollectionDelete: handleDialogDelete,
            onLoad: handleDialogsLoad
        });
    }

    /* ==============================
       MEDIA HANDLERS
    ============================== */

    function handleMediaLoad(_media) {
        media = _media;
        loadDialogs();
    }

    function handleMediaChange(_media) {
    }

    function handleMediaError(err) {
    }

    /* ==============================
       USER HANDLERS
    ============================== */

    function handleUserLoad() {
        user.getMediaList({
            onLoad: function (mediaList) {
                mediaList.getMedia({
                    id: mrdID,
                    onLoad: handleMediaLoad,
                    onChange: handleMediaChange,
                    onError: handleMediaError
                });
            }
        });
    }

    function handleUserChange() {
    }

    /* ==============================
       INIT
    ============================== */

    return {
        init: function (chatMrdId) {
            mrdID = chatMrdId;

            finesse.clientservices.ClientServices.init(finesse.gadget.Config);
            finesse.cslogger.ClientLogger.init(gadgets.Hub, "ChatHelperGadget");
            log("initializing mrdID=" + mrdID);

            user = new finesse.restservices.User({
                id: finesse.gadget.Config.id,
                onLoad: handleUserLoad,
                onChange: handleUserChange
            });
        }
    };

}(jQuery));
