var finesse = finesse || {};
finesse.modules = finesse.modules || {};

finesse.modules.Gadget = (function ($) {

    var user, media, mrdID = "", mediaDialogs, clientLogs;
    var cachedToken = null;
    var tokenExpiry = 0;

    var OKTA_TOKEN_URL = "https://assurant.oktapreview.com/oauth2/aus26n6j3p4xj3UEE0h8/v1/token";
    var RETRIEVE_URL   = "https://intra-api-gl-ccd-model.assurant.com/ccd/shared/liason/v1/retrieve";
    var SUBSCRIPTION_KEY = "bfb35b140a194dd7b88f8305d45366bc";
    var CLIENT_ID      = "0oa26n6exiojXTKSC0h8";
    var CLIENT_SECRET  = "UO8E5wbWsqTimRnXGyInnMweUGAISZj11WIXxTBQXDMg_iTDBXTqnTh2N8TPfY7R";

    function getAuthToken() {
        if (cachedToken && Date.now() < tokenExpiry - 60000) {
            return Promise.resolve(cachedToken);
        }

        var params = new URLSearchParams();
        params.append("grant_type", "client_credentials");
        params.append("client_id", CLIENT_ID);
        params.append("client_secret", CLIENT_SECRET);
        params.append("scope", "claim");

        return fetch(OKTA_TOKEN_URL, {
            method: "POST",
            headers: { "Content-Type": "application/x-www-form-urlencoded" },
            body: params
        })
        .then(function(response) {
            if (!response.ok) throw new Error("Okta token request failed: " + response.status);
            return response.json();
        })
        .then(function(tokenData) {
            cachedToken = tokenData.access_token;
            tokenExpiry = Date.now() + (tokenData.expires_in * 1000);
            return cachedToken;
        });
    }

    /* ==============================
       DIALOG HANDLERS
    ============================== */

    function handleDialogAdd(dialog) {
        if (dialog._data.mediaProperties.mediaId !== mrdID) {
            return;
        }

        clientLogs.log("Chat arrived!");

        var callVars = dialog._data.mediaProperties;
        clientLogs.log("Call Vars: " + JSON.stringify(callVars));
        var callVariablesArray = callVars.callvariables.CallVariable;
        clientLogs.log("callVariablesArray: " + JSON.stringify(callVariablesArray));

        // Helper function
        function getCallVariable(name) {
            var item = callVariablesArray.find(cv => cv.name === name);
            return item && item.value ? item.value : "";
        }

        var mediaResourceId = getCallVariable("user_DR_MediaResourceID");
        clientLogs.log("user_DR_MediaResourceID: " + mediaResourceId);

        getAuthToken()
            .then(function(token) {
                return fetch(RETRIEVE_URL, {
                    method: "POST",
                    headers: {
                        "Content-Type": "application/json",
                        "Authorization": "Bearer " + token,
                        "Ocp-Apim-Subscription-Key": SUBSCRIPTION_KEY,
                        "X-Correlation-Id": mediaResourceId
                    },
                    body: JSON.stringify({ callId: mediaResourceId })
                });
            })
            .then(function(response) {
                if (!response.ok) throw new Error("Retrieve API responded with status " + response.status);
                return response.json();
            })
            .then(function(apiData) {
                clientLogs.log("API response: " + JSON.stringify(apiData));

                var chatData = mapWebPayload(apiData.webPayload);
                clientLogs.log("Mapped chat data: " + JSON.stringify(chatData));

                window.finesseBridge.setChatData(chatData);
                if (window.finesseBridge && window.finesseBridge.adjustHeight) {
                    window.finesseBridge.adjustHeight();
                }
            })
            .catch(function(err) {
                clientLogs.log("Failed to fetch chat data: " + err.message);
            });
    }

    function handleDialogDelete(dialog) {
        clientLogs.log("Chat ended");

        window.finesseBridge.setChatData(null);
    }

    function handleDialogsLoad() {
        clientLogs.log("Dialogs loaded");

        var dialogs = mediaDialogs.getCollection();

        for (var id in dialogs) {
            handleDialogAdd(dialogs[id]);
        }
    }

    function loadDialogs() {
        clientLogs.log("Loading dialogs...");

        mediaDialogs = media.getMediaDialogs({
            onCollectionAdd: handleDialogAdd,
            onCollectionDelete: handleDialogDelete,
            onLoad: handleDialogsLoad
        });
    }




    /* ==============================
       MEDIA HANDLERS
    ============================== */

    function handleMediaLoad(_media) {
        clientLogs.log("Media loaded");

        media = _media;
        loadDialogs();
    }

    function handleMediaChange(_media) {
        if (_media._data.id === mrdID) {
            clientLogs.log("Media state changed: " + _media.getState());
        }
    }

    function handleMediaError(err) {
        clientLogs.log("Media error: " + JSON.stringify(err));
    }

    /* ==============================
       USER HANDLERS
    ============================== */

    function handleUserLoad() {
        clientLogs.log("User loaded");
        //window.finesseBridge.setTeam("sales")

        user.getMediaList({
            onLoad: function (mediaList) {

                clientLogs.log("MediaList loaded");

                mediaList.getMedia({
                    id: mrdID,
                    onLoad: handleMediaLoad,
                    onChange: handleMediaChange,
                    onError: handleMediaError
                });

            }
        });
    }

    function handleUserChange() {
        clientLogs.log("User state changed: " + user.getState());
    }


    /* ==============================
       INIT
    ============================== */

    return {
        init: function (chatMrdId) {

			mrdID = chatMrdId;
            finesse.clientservices.ClientServices.init(finesse.gadget.Config);

            // ✅ Initialize logger FIRST
            clientLogs = finesse.cslogger.ClientLogger;
            clientLogs.init(gadgets.Hub, "MSAChatDataGadget");
			clientLogs.log("MrdID:"+mrdID);
            clientLogs.log("chat Data Gadget initializing...");
             if (window.__vueHubConnected) {
                        window.__vueHubConnected();
             }


            user = new finesse.restservices.User({
                id: finesse.gadget.Config.id,
                onLoad: handleUserLoad,
                onChange: handleUserChange
            });

            
        }
    };

}(jQuery));