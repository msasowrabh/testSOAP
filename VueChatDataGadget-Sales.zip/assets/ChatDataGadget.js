var finesse = finesse || {};
finesse.modules = finesse.modules || {};

finesse.modules.Gadget = (function ($) {

    var user, media, mrdID = "", mediaDialogs, clientLogs;

	var currentScript = (document.currentScript || {}).src || "";
	var wsPath = currentScript.replace(/\/script.*/,"");
    var RETRIEVE_URL   = wsPath + "/softphone/callData/retrieve";
    var UPDATE_URL     = wsPath + "/softphone/callData/update";
    var storedCallData = null;

    function callUpdate(fieldId, newValue) {
        if (!storedCallData) {
            clientLogs.log("[callUpdate] No stored call data, skipping");
            return;
        }
        var shortKey = getShortKey(fieldId);
        storedCallData.webPayload[shortKey] = newValue;
        clientLogs.log("[callUpdate] fieldId=" + fieldId + " shortKey=" + shortKey + " newValue=" + newValue);

        fetch(UPDATE_URL, {
            method: "POST",
            headers: {
                "Content-Type": "application/json",
                "X-Correlation-Id": storedCallData.callId || ""
            },
            body: JSON.stringify(storedCallData)
        })
        .then(function (response) {
            if (!response.ok) throw new Error("HTTP " + response.status);
            return response.json();
        })
        .then(function (data) {
            clientLogs.log("[callUpdate] Update success: " + JSON.stringify(data));
            storedCallData = data;
            var chatData = mapWebPayload(data.webPayload);
            if (window.finesseBridge) {
                window.finesseBridge.setChatData(chatData);
            }
        })
        .catch(function (err) {
            clientLogs.log("[callUpdate] Update failed: " + err.message);
        });
    }

    /* ==============================
       DIALOG HANDLERS
    ============================== */

    function handleDialogAdd(dialog) {
        var dialogMediaId = dialog._data.mediaProperties.mediaId;
        clientLogs.log("[handleDialogAdd] Dialog arrived - dialogMediaId=" + dialogMediaId + ", expected mrdID=" + mrdID);

        if (dialogMediaId !== mrdID) {
            clientLogs.log("[handleDialogAdd] Skipping dialog — mediaId mismatch");
            return;
        }

        clientLogs.log("Chat arrived!");

        var callVars = dialog._data.mediaProperties;
        clientLogs.log("Call Vars: " + JSON.stringify(callVars));

        var callVariablesRaw = callVars.callvariables;
        clientLogs.log("[handleDialogAdd] callvariables raw: " + JSON.stringify(callVariablesRaw));

        var callVariablesArray = callVars.callvariables.CallVariable;
        if (!Array.isArray(callVariablesArray)) {
            clientLogs.log("[handleDialogAdd] WARNING: CallVariable is not an array, got type=" + typeof callVariablesArray + ", value=" + JSON.stringify(callVariablesArray));
        } else {
            clientLogs.log("[handleDialogAdd] CallVariable count: " + callVariablesArray.length);
        }
        clientLogs.log("callVariablesArray: " + JSON.stringify(callVariablesArray));

        // Helper function
        function getCallVariable(name) {
            var item = Array.isArray(callVariablesArray) && callVariablesArray.find(cv => cv.name === name);
            var value = item && item.value ? item.value : "";
            clientLogs.log("[getCallVariable] " + name + " = " + (value || "(empty)"));
            return value;
        }

        var mediaResourceId = getCallVariable("user_DR_MediaResourceID");
        clientLogs.log("user_DR_MediaResourceID: " + mediaResourceId);

        if (!mediaResourceId) {
            clientLogs.log("[handleDialogAdd] WARNING: mediaResourceId is empty — API call will proceed with empty callId");
        }

        var requestBody = JSON.stringify({ callId: mediaResourceId });
        clientLogs.log("[handleDialogAdd] Calling Retrieve API - URL=" + RETRIEVE_URL + " X-Correlation-Id=" + mediaResourceId + " body=" + requestBody);
        
		fetch(RETRIEVE_URL, {
                    method: "POST",
                    headers: {
                        "Content-Type": "application/json",
                        "X-Correlation-Id": mediaResourceId
                    },
                    body: requestBody
            })
            .then(function(response) {
                if (!response.ok) throw new Error("HTTP " + response.status);
                return response.json();
            })
            .then(function(apiData) {
                clientLogs.log("API response: " + JSON.stringify(apiData));
                clientLogs.log("[handleDialogAdd] apiData keys: " + Object.keys(apiData).join(", "));

                var webPayload = apiData.webPayload;
                clientLogs.log("[handleDialogAdd] webPayload present=" + (webPayload != null) + " value=" + JSON.stringify(webPayload));

                storedCallData = apiData;

                var chatData = mapWebPayload(webPayload);
                clientLogs.log("Mapped chat data: " + JSON.stringify(chatData));
                clientLogs.log("[handleDialogAdd] chatData keys: " + Object.keys(chatData).join(", "));

                clientLogs.log("[handleDialogAdd] Calling finesseBridge.setChatData...");
                if (window.finesseBridge) {
                    window.finesseBridge.setChatData(chatData);
                    window.finesseBridge._updateHandler = callUpdate;
                    if (window.finesseBridge.adjustHeight) {
                        clientLogs.log("[handleDialogAdd] Calling finesseBridge.adjustHeight...");
                        window.finesseBridge.adjustHeight();
                    }
                }
                clientLogs.log("[handleDialogAdd] Data flow complete");
            })
            .catch(function(err) {
                clientLogs.log("Failed to fetch chat data: " + err.message);
                clientLogs.log("[handleDialogAdd] Error stack: " + (err.stack || "unavailable"));
            });
    }

    function handleDialogDelete(dialog) {
        clientLogs.log("Chat ended");

        storedCallData = null;
        if (window.finesseBridge) {
            window.finesseBridge._updateHandler = null;
            window.finesseBridge.setChatData(null);
        }
    }

    function handleDialogsLoad() {
        clientLogs.log("Dialogs loaded");

        var dialogs = mediaDialogs.getCollection();
        var dialogIds = Object.keys(dialogs);
        clientLogs.log("[handleDialogsLoad] Dialog count: " + dialogIds.length + " ids=[" + dialogIds.join(", ") + "]");

        for (var id in dialogs) {
            clientLogs.log("[handleDialogsLoad] Processing dialog id=" + id);
            handleDialogAdd(dialogs[id]);
        }
    }

    function loadDialogs() {
        clientLogs.log("Loading dialogs...");

        mediaDialogs = media.getMediaDialogs({
            onCollectionAdd: handleDialogAdd,
            onCollectionDelete: handleDialogDelete,
            onLoad: handleDialogsLoad
        });
    }




    /* ==============================
       MEDIA HANDLERS
    ============================== */

    function handleMediaLoad(_media) {
        clientLogs.log("Media loaded");

        media = _media;
        loadDialogs();
    }

    function handleMediaChange(_media) {
        if (_media._data.id === mrdID) {
            clientLogs.log("Media state changed: " + _media.getState());
        }
    }

    function handleMediaError(err) {
        clientLogs.log("Media error: " + JSON.stringify(err));
    }

    /* ==============================
       USER HANDLERS
    ============================== */

    function handleUserLoad() {
        clientLogs.log("User loaded");
        //window.finesseBridge.setTeam("sales")

        user.getMediaList({
            onLoad: function (mediaList) {

                clientLogs.log("MediaList loaded");

                mediaList.getMedia({
                    id: mrdID,
                    onLoad: handleMediaLoad,
                    onChange: handleMediaChange,
                    onError: handleMediaError
                });

            }
        });
    }

    function handleUserChange() {
        clientLogs.log("User state changed: " + user.getState());
    }


    /* ==============================
       INIT
    ============================== */

    return {
        init: function (chatMrdId) {

			mrdID = chatMrdId;
            finesse.clientservices.ClientServices.init(finesse.gadget.Config);

            // ✅ Initialize logger FIRST
            clientLogs = finesse.cslogger.ClientLogger;
            clientLogs.init(gadgets.Hub, "MSAChatDataGadget");
			clientLogs.log("MrdID:"+mrdID);
            clientLogs.log("chat Data Gadget initializing...");
             if (window.__vueHubConnected) {
                        window.__vueHubConnected();
             }


            user = new finesse.restservices.User({
                id: finesse.gadget.Config.id,
                onLoad: handleUserLoad,
                onChange: handleUserChange
            });

            
        }
    };

}(jQuery));