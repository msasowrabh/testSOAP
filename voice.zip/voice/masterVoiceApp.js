// Master Voice Application - Vue.js Application
(function() {
	var BOOT_RETRY_DELAY_MS = 50;
	var BOOT_MAX_RETRIES = 120;
	window.masterVoicePendingComponents = window.masterVoicePendingComponents || [];

	if (typeof window.registerVoiceComponent !== 'function') {
		window.registerVoiceComponent = function(name, definition) {
			if (!name || !definition) {
				return;
			}
			window.masterVoicePendingComponents.push({
				name: name,
				definition: definition
			});
		};
	}

	function isPiniaReady() {
		return !!(window.Pinia && typeof window.Pinia.createPinia === 'function' && typeof window.Pinia.defineStore === 'function');
	}

	function isVueReady() {
		return !!(window.Vue && typeof window.Vue.createApp === 'function');
	}

	function startWhenDependenciesReady(startFn) {
		var retries = 0;
		(function waitForDeps() {
			if (isPiniaReady() && isVueReady()) {
				startFn();
				return;
			}

			retries += 1;
			if (retries >= BOOT_MAX_RETRIES) {
				if (window.console && typeof window.console.error === 'function') {
					window.console.error('Master Voice app failed to start: Vue/Pinia not ready in time.');
				}
				return;
			}

			window.setTimeout(waitForDeps, BOOT_RETRY_DELAY_MS);
		})();
	}

	function startMasterVoiceApp() {
		if (window.masterVoiceAppBootstrapStarted) {
			return;
		}
		window.masterVoiceAppBootstrapStarted = true;

		// App boots with English by default unless overridden globally.
		window.masterVoiceLocale = window.masterVoiceLocale || 'en';

		window.masterVoicePinia = window.masterVoicePinia || window.Pinia.createPinia();

		if (!window.useMasterVoiceComponentStore) {
			window.useMasterVoiceComponentStore = window.Pinia.defineStore('masterVoiceComponentRegistry', {
				state: function() {
					return {
						definitions: {}
					};
				},
				getters: {
					all: function(state) {
						return Object.keys(state.definitions).map(function(name) {
							return {
								name: name,
								definition: state.definitions[name]
							};
						});
					}
				},
				actions: {
					register: function(name, definition) {
						if (!name || !definition) {
							return;
						}
						var normalizedDefinition = definition;
						if (window.Vue && typeof window.Vue.markRaw === 'function') {
							normalizedDefinition = window.Vue.markRaw(definition);
						}
						this.definitions[name] = normalizedDefinition;
					}
				}
			});
		}

		var componentStore = window.useMasterVoiceComponentStore(window.masterVoicePinia);

		window.registerVoiceComponent = function(name, definition) {
			componentStore.register(name, definition);
		};

		if (Array.isArray(window.masterVoicePendingComponents) && window.masterVoicePendingComponents.length) {
			window.masterVoicePendingComponents.forEach(function(entry) {
				componentStore.register(entry.name, entry.definition);
			});
			window.masterVoicePendingComponents = [];
		}

		window.masterVoiceBaseUrl = window.masterVoiceBaseUrl || '';

	function getByPath(source, path) {
		if (!source || !path) {
			return undefined;
		}
		var parts = String(path).split('.');
		var value = source;
		for (var i = 0; i < parts.length; i++) {
			if (value == null || !Object.prototype.hasOwnProperty.call(value, parts[i])) {
				return undefined;
			}
			value = value[parts[i]];
		}
		return value;
	}

	function mergeDeep(target, source) {
		var output = target && typeof target === 'object' ? target : {};
		if (!source || typeof source !== 'object') {
			return output;
		}
		Object.keys(source).forEach(function(key) {
			var sourceValue = source[key];
			if (sourceValue && typeof sourceValue === 'object' && !Array.isArray(sourceValue)) {
				output[key] = mergeDeep(output[key] && typeof output[key] === 'object' ? output[key] : {}, sourceValue);
				return;
			}
			output[key] = sourceValue;
		});
		return output;
	}

	function interpolate(text, params) {
		if (!params || typeof params !== 'object') {
			return text;
		}
		return String(text).replace(/\{(\w+)\}/g, function(match, token) {
			return Object.prototype.hasOwnProperty.call(params, token) ? String(params[token]) : match;
		});
	}

	function createNoFallbackI18n(options) {
		var locale = options && options.locale ? options.locale : 'en';
		var messages = options && options.messages ? options.messages : {};

		function translate(key, params) {
			var localeDict = messages[locale] || {};
			var value = getByPath(localeDict, key);
			if (typeof value === 'undefined') {
				return '';
			}
			if (typeof value !== 'string') {
				return String(value);
			}
			return interpolate(value, params);
		}

		return {
			global: {
				locale: { value: locale },
				messages: messages,
				t: translate
			},
			install: function(app) {
				app.config.globalProperties.$t = translate;
			}
		};
	}

	function createMasterVoiceI18n(options) {
		if (window.VueI18n && typeof window.VueI18n.createI18n === 'function') {
			return window.VueI18n.createI18n({
				legacy: false,
				locale: options.locale,
				fallbackLocale: false,
				messages: options.messages
			});
		}
		return createNoFallbackI18n(options);
	}

	function fetchJson(url) {
		if (!url || typeof fetch !== 'function') {
			return Promise.resolve({});
		}
		return fetch(url, { credentials: 'same-origin' })
			.then(function(response) {
				if (!response.ok) {
					return {};
				}
				return response.json();
			})
			.catch(function() {
				return {};
			});
	}

	function loadI18nResources() {
		var locale = window.masterVoiceLocale || 'en';
		var base = window.masterVoiceBaseUrl || '';
		var localeCoreUrl = base + '/i18n/gadgets/voice/labels.' + locale + '.json';
		var localeCustomUrl = base + '/custom/i18n/labels.' + locale + '.json';

		var localeCorePromise = fetchJson(localeCoreUrl);
		var localeCustomPromise = fetchJson(localeCustomUrl);

		return Promise.all([
			localeCorePromise,
			localeCustomPromise
		]).then(function(payloads) {
			var localeMessages = mergeDeep(mergeDeep({}, payloads[0]), payloads[1]);
			return {
				locale: locale,
				messages: (function() {
					var result = {};
					result[locale] = localeMessages;
					return result;
				})()
			};
		});
	}

	function initializeApp() {
		loadI18nResources().then(function(i18nConfig) {
		var service = window.softPhoneCoreService || (window.finesse && window.finesse.gadget && window.finesse.gadget.softPhoneCoreService);
		if (service && typeof service.init === 'function') {
			try {
				service.init();
				if (window.console && typeof window.console.log === 'function') {
					window.console.log('Master Voice service initialized successfully');
				}
			} catch (e) {
				if (window.console && typeof window.console.error === 'function') {
					window.console.error('Master Voice service init failed', e);
				}
			}
		} else if (window.console && typeof window.console.warn === 'function') {
			window.console.warn('Master Voice service not available at app startup');
		}

		if (typeof Vue === 'undefined' || typeof Vue.createApp !== 'function') {
			if (window.console && typeof window.console.error === 'function') {
				window.console.error('Vue 3 is required. Vue.createApp is not available.');
			}
			return;
		}

		var rootOptions = {
			data: function() {
				return {
					appReady: true,
					appVersion: '1.0.0',
					allButtonsDisabled: false,
					selectedDepartment: '',
					selectedDial: '',
					isDialEnabled: false,
					mainCallState: 'NOCALL',
					isDialNewCallVisible: false,
					dialNewCallMode: 'dial'
				};
			},
			methods: {
				syncDialNewCallPanelState: function(visibleOverride, stateOverride) {
					var dialRef = this.$refs.dialNewCall;
					this.isDialNewCallVisible = typeof visibleOverride === 'boolean'
						? visibleOverride
						: !!(dialRef && dialRef.isVisible);
					this.dialNewCallMode = stateOverride || (dialRef && dialRef.state) || 'dial';
				},
				isConferenceButtonActive: function() {
					return this.isDialNewCallVisible && this.dialNewCallMode === 'conference';
				},
				isTransferButtonActive: function() {
					return this.isDialNewCallVisible && this.dialNewCallMode === 'transfer';
				},
				setAllButtonsDisabled: function(isDisabled) {
					this.allButtonsDisabled = !!isDisabled;
				},
				isMainCallInteractive: function() {
					return this.mainCallState === 'ACTIVE' || this.mainCallState === 'HELD';
				},
				recomputeDialEnabled: function() {
					var dialRef = this.$refs.dialNewCall;
					var dialState = dialRef ? dialRef.state : 'dial';
					var isDialStateMode = dialState === 'dial';
					var isTransferOrConferenceMode = dialState === 'transfer' || dialState === 'conference';
					var isMainCallActive = this.mainCallState === 'ACTIVE' || this.mainCallState === 'HELD';
					var canDialInDialMode = isDialStateMode && !!this.selectedDial && (this.mainCallState === 'END' || this.mainCallState === 'NOCALL');
					var canDialInTransferOrConference = isTransferOrConferenceMode && !!this.selectedDial && isMainCallActive;
					this.isDialEnabled = canDialInDialMode || canDialInTransferOrConference;
				},
				updateDialCallVisibility: function() {
					var dialRef = this.$refs.dialNewCall;
					if (!dialRef || dialRef.state !== 'dial') { return; }
					var dialVisibleStates = ['NOCALL', 'END'];
					if (dialVisibleStates.indexOf(this.mainCallState) > -1) {
						dialRef.showDialNewCall();
					} else {
						dialRef.hideDialNewCall();
					}
				},
				emitCallDataVisibility: function(isVisible, source) {
					if (window.masterVoiceEvents) {
						window.masterVoiceEvents.emit('master-voice-call-data-visibility', {
							visible: !!isVisible,
							source: source || 'unknown'
						});
					}
				},
				onDepartmentSelectionChanged: function(selectedDepartment) {
					this.selectedDepartment = selectedDepartment || '';
					this.recomputeDialEnabled();
				},
				onSpeedDialSelectionChanged: function(selectedDial) {
					this.selectedDial = selectedDial == null ? '' : String(selectedDial);
					this.recomputeDialEnabled();
				},
				resetDialState: function() {
					this.selectedDepartment = '';
					this.selectedDial = '';
					this.isDialEnabled = false;
					this.$refs.dialNewCall.setState('dial');
					this.syncDialNewCallPanelState(false, 'dial');
					this.emitCallDataVisibility(false, 'reset');
				},
				onCancelRequested: function() {
					var dialRef = this.$refs.dialNewCall;
					if (dialRef && dialRef.isDialInitiating && window.softPhoneCoreService && typeof window.softPhoneCoreService.endConsultCall === 'function') {
						window.softPhoneCoreService.endConsultCall();
						this.resetDialState();
						return;
					}

					var consultState = (window.softPhoneConfig && window.softPhoneConfig.consultCallState && window.softPhoneConfig.consultCallState.state) || '';
					var normalizedState = String(consultState).toUpperCase();
					if ((normalizedState === 'INITIATING' || normalizedState === 'INITIATED') && window.softPhoneCoreService && typeof window.softPhoneCoreService.endConsultCall === 'function') {
						window.softPhoneCoreService.endConsultCall();
					}
					this.resetDialState();
				},
				onConferenceRequested: function() {
					if (!this.isMainCallInteractive()) {
						return;
					}
					this.$refs.mainCall.startConference();
					this.$refs.dialNewCall.setState('conference');
					this.$refs.dialNewCall.showDialNewCall();
					this.syncDialNewCallPanelState(true, 'conference');
					this.recomputeDialEnabled();
				},
				onAnswerRequested: function() {
					if (window.softPhoneCoreService) {
						window.softPhoneCoreService.answerMainCall();
					}
				},
				onHoldToggle: function() {
					var mainCallState = this.$refs.mainCall && this.$refs.mainCall.callState;
					if (!window.softPhoneCoreService) {
						return;
					}

					if (mainCallState === 'HELD') {
						window.softPhoneCoreService.retrieveMainCall();
					} else {
						window.softPhoneCoreService.holdMainCall();
					}
				},
				onTransferRequested: function() {
					if (!this.isMainCallInteractive()) {
						return;
					}
					this.$refs.mainCall.startTransfer();
					this.$refs.dialNewCall.setState('transfer');
					this.$refs.dialNewCall.showDialNewCall();
					this.syncDialNewCallPanelState(true, 'transfer');
					this.recomputeDialEnabled();
				},
				onDialRequested: function() {
					var dialState = this.$refs.dialNewCall && this.$refs.dialNewCall.state;
					var dialValue = this.selectedDial == null ? '' : String(this.selectedDial);
					var service = window.softPhoneCoreService;
					var config = window.softPhoneConfig || {};
					if (!dialValue) {
						return;
					}
					if (dialState !== 'dial' && dialState !== 'transfer' && dialState !== 'conference') {
						return;
					}
					if (dialState === 'conference' && typeof config.confHook === 'function') {
						config.confHook(dialValue);
						return;
					}
					if (typeof config.dialHook === 'function') {
						config.dialHook(dialValue);
						return;
					}
					if (service && typeof service.makeCall === 'function') {
						service.makeCall(dialValue);
					}
				},
				onEndCallRequested: function() {
					var service = window.softPhoneCoreService;
					var config = window.softPhoneConfig || {};
					if (!service) {
						return;
					}

					if (typeof config.releaseHook === 'function') {
						config.releaseHook();
						return;
					}

					service.endMainCall();
				}
			},
			mounted: function() {
				if (window.console && typeof window.console.log === 'function') {
					window.console.log('Master Voice App initialized successfully');
				}
				var self = this;
				if (window.masterVoiceEvents) {
					var eventName = (window.PROXYCONST && window.PROXYCONST.EVENT_TYPE_MAIN_CALL_CHANGE) || 'MAIN_CALL_CHANGE';
					var dialVisibilityEvent = 'master-voice-dial-new-call-visibility-completed';
					this._unsubMainCallChangeApp = window.masterVoiceEvents.on(eventName, function() {
						var state = (window.softPhoneConfig && window.softPhoneConfig.mainCallState && window.softPhoneConfig.mainCallState.state) || 'NOCALL';
						self.mainCallState = state;
						if ((state === 'NOCALL' || state === 'END' || state === 'WRAP_UP') && self.$refs.dialNewCall) {
							self.$refs.dialNewCall.setState('dial');
							self.$refs.dialNewCall.showDialNewCall();
							self.syncDialNewCallPanelState(true, 'dial');
						}
						self.recomputeDialEnabled();
						self.updateDialCallVisibility();
					});
					this._unsubDialVisibilityApp = window.masterVoiceEvents.on(dialVisibilityEvent, function(payload) {
						self.syncDialNewCallPanelState(!!(payload && payload.visible), payload && payload.state);
					});
				}
				this.syncDialNewCallPanelState();

				//gadgets.window.adjustHeight();
			},
			beforeUnmount: function() {
				if (this._unsubMainCallChangeApp) { this._unsubMainCallChangeApp(); }
				if (this._unsubDialVisibilityApp) { this._unsubDialVisibilityApp(); }
			}
		};

		var app = Vue.createApp(rootOptions);
		app.use(window.masterVoicePinia);
		window.masterVoiceI18n = createMasterVoiceI18n(i18nConfig);
		app.use(window.masterVoiceI18n);

		componentStore.all.forEach(function(entry) {
			app.component(entry.name, entry.definition);
		});

		window.masterVoiceApp = app.mount('#masterVoiceApp');
		}).catch(function(error) {
			if (window.console && typeof window.console.error === 'function') {
				window.console.error('Master Voice i18n initialization failed', error);
			}
		});
	}

	initializeApp();
	}

	window.startMasterVoiceAppBootstrap = function() {
		startWhenDependenciesReady(startMasterVoiceApp);
	};

	if (window.masterVoiceAutoStart !== false) {
		window.startMasterVoiceAppBootstrap();
	}
})();
