
"use strict";
// cSpell:ignoreRegExp  [A-Z]+

var finesse = finesse || {};
finesse.gadget = finesse.gadget || {};
finesse.container = finesse.container || {};
const NULL_CALL = {
	id: null,
	endId: null,
	state: "NOCALL",
	from: "",
	to: "",
	direction: "",
	calldata: null,
	callvariablesJSON: null,
	consultCall: false,
	skill: null,
	actions: null,
	pendingUpdate: null,
};

(function(global) {
	function createLogger() {
		var noop = function() {};
		return {
			log: console.log ? console.log.bind(console) : noop,
			debug: console.debug ? console.debug.bind(console) : (console.log ? console.log.bind(console) : noop),
			info: console.info ? console.info.bind(console) : (console.log ? console.log.bind(console) : noop),
			error: console.error ? console.error.bind(console) : (console.log ? console.log.bind(console) : noop),
			infoObfuscated: console.info ? console.info.bind(console) : (console.log ? console.log.bind(console) : noop),
			logObfuscated: console.log ? console.log.bind(console) : (console.log ? console.log.bind(console) : noop),
		};
	}

	function createTranslateAdapter() {
		return {
			use: function() {
				return global.currentLocale || "en_US";
			},
			instant: function(key) {
				var dictionary = global.i18n || global.translations;
				if (dictionary && dictionary[key]) {
					return dictionary[key];
				}
				return key;
			},
		};
	}

	function resolveScriptBaseUrl() {
		if (global.masterVoiceBaseUrl) {
			return global.masterVoiceBaseUrl;
		}

		var currentScript = document.currentScript;
		if (currentScript && currentScript.src) {
			return currentScript.src.replace(/\/scripts\/gadgets\/voice\/masterVoiceService\.js(?:\?.*)?$/, "");
		}

		var scripts = document.getElementsByTagName("script");
		for (var i = scripts.length - 1; i >= 0; i--) {
			var script = scripts[i];
			if (script.src && script.src.indexOf("/scripts/gadgets/voice/masterVoiceService.js") > -1) {
				return script.src.replace(/\/scripts\/gadgets\/voice\/masterVoiceService\.js(?:\?.*)?$/, "");
			}
		}

		return global.location ? (global.location.origin || "") : "";
	}

	function resolveLogContext() {
		var provided = global.logContext || {};
		var pathname = global.location && global.location.pathname ? global.location.pathname : "";
		var app = provided.app;

		if (!app && pathname) {
			var pathParts = pathname.split("/").filter(Boolean);
			app = pathParts.length > 0 ? pathParts[0] : "";
		}

		return {
			app: app || "",
			location: provided.location || null,
			cm: provided.cm || null,
		};
	}

	function resolveWsPath(logContext) {
		if (global.wsPath) {
			return global.wsPath;
		}

		var baseUrl = resolveScriptBaseUrl();
		if (baseUrl) {
			return baseUrl.replace(/\/?$/, "/");
		}

		if (logContext && logContext.app && global.location && global.location.origin) {
			return global.location.origin + "/" + logContext.app + "/";
		}

		return "/";
	}

	var PROXYCONST = {
		DOMAIN: 'finesse.assurant.com',
		EVENT_EFINESSESTATSWS_UPDATE: 'EFINESSESTATSWS_UPDATE',
		EVENT_TYPE_CONNECT: 'CONNECT',
		EVENT_TYPE_CONNECTED: 'CONNECTED',
		EVENT_TYPE_RECONNECTING: 'RECONNECTING',
		EVENT_TYPE_DISCONNECTED: 'DISCONNECTED',
		EVENT_TYPE_CALL_DATA: 'CALLDATA',
		EVENT_TYPE_AGENT_STATUS_CHANGE: 'AGENT_STATUS_CHANGE',
		EVENT_TYPE_BUSINESS_CONFIG_CHANGE: 'BUSINESS_CONFIG_CHANGE',
		EVENT_TYPE_CALL_DATA_CHANGE: 'CALL_DATA_CHANGE',
		EVENT_TYPE_MAIN_CALL_CHANGE: 'MAIN_CALL_CHANGE',
		EVENT_TYPE_ERROR: 'ERROR',
		EVENT_TYPE_CONSULT_CALL_CHANGE: 'CONSULT_CALL_CHANGE',
		EVENT_CLEAR_CTI_FIELD: 'EVENT_CLEAR_CTI_FIELD',
		EVENT_TIMER_TICK: 'EVENT_TIMER_TICK',
		FINESSE_CONNECTED: 'FINESSE_CONNECTED',
		PENDING_STATE_CHANGE: 'PENDING_STATE_CHANGE',
		AGENT_STATE: {
			READY: 'READY',
			NOT_READY: 'NOT_READY',
			LOGOUT: 'LOGOUT',
			TALKING: 'TALKING',
			HOLD: 'HOLD',
			WORK: 'WORK',
			WORK_READY: 'WORK_READY',
		},
		ECC: {
			USER_CONTACT_CTI_0: 'user.ContactCTI[0]',
			USER_CONTACT_CTI_1: 'user.ContactCTI[1]',
			USER_CONTACT_CTI_2: 'user.ContactCTI[2]',
			USER_CONTACT_CTI_MAXLENGTH: 133,
		},
		CALLVARIABLES: {
			CALLVARIABLE1: 'callVariable1',
			CALLVARIABLE2: 'callVariable2',
			CALLVARIABLE3: 'callVariable3',
			CALLVARIABLE4: 'callVariable4',
			CALLVARIABLE5: 'callVariable5',
			CALLVARIABLE6: 'callVariable6',
			CALLVARIABLE7: 'callVariable7',
			CALLVARIABLE8: 'callVariable8',
			CALLVARIABLE9: 'callVariable9',
			CALLVARIABLE10: 'callVariable10',
		},
		NULL_CALL: NULL_CALL,
	};

	var softPhoneConfig = {
		finesseNotReadyReasonCodesUnfiltered: {},
		businessConfiguration: {},
		mainCallState: NULL_CALL,
		consultCallState: {
			id: null,
			state: '',
			from: '',
			to: '',
			direction: '',
		},
		agentState: null,
		callData: {
			ecc: {},
			user: {},
		},
		userFirstName: "",
		userLastName: "",
		userLoginName: "",
		_userId: "",
		_extension: "",
		_mobileNumber: "",
		_callByCall: false,
		_location: null,
		_agentIdMode: false,
		wrap: '',
		hostEnvironment: '-DEV-',
		transferHook: null,
		dialHook: null,
		singleStepHook: null,
		releaseHook: null,
		callDataHook: null,
		confHook: null,
		joinHook: null,
		niceHook: null,
		endCallHook: null,
		endConsultCallHook: null,
		reloadBiz: false,
		refreshBiz: false,
		actions: {
			mainCall: {},
			consultCall: {},
		},
		transferToSurvey: null,
	};
		var $log = createLogger();
		var $timeout = function(callback, delay) { return global.setTimeout(callback, delay); };
		var $translate = createTranslateAdapter();
		var logContext = resolveLogContext();
		var wsPath = resolveWsPath(logContext);
		global.logContext = logContext;
		global.wsPath = wsPath;
			let SoftPhoneDataOp = {};
			global.PROXYCONST = PROXYCONST;
			var ctiDataService = window.ctiDataService || {
				parse: function() { return {}; },
				pack: function() { return new Map(); }
			};
			var User = null;
			var MainDialog = null;
			var ConsultDialog = null;

			function isDefined(value) {
				return typeof value !== "undefined";
			}

			function isUndefined(value) {
				return typeof value === "undefined";
			}

			function isFunction(value) {
				return typeof value === "function";
			}

			function isString(value) {
				return typeof value === "string" || value instanceof String;
			}

			function isObject(value) {
				return value !== null && typeof value === "object";
			}

			function isNumber(value) {
				return typeof value === "number" && !isNaN(value);
			}

			function isEmptyObject(value) {
				return isObject(value) && Object.keys(value).length === 0;
			}

			const _timerListeners = [];

			function _emitVueEvent(eventName, payload) {
				if (window.masterVoiceEvents) {
					window.masterVoiceEvents.emit(eventName, payload);
				}
			}

			function _onTimerTick(listener) {
				if (!isFunction(listener)) {
					return function() {};
				}

				_timerListeners.push(listener);
				return function() {
					var idx = _timerListeners.indexOf(listener);
					if (idx > -1) {
						_timerListeners.splice(idx, 1);
					}
				};
			}

			let _lastProcessedTimerTick = null;
			const _maxTimerCallbackThreshold = 200, _forceTickProcessingEvery = 500;

			/**
			* Processes a timer tick - updating the UI.
			* @param start is the time that the tick was received
			* @returns {boolean} true
			*/
			const _processTick = function(start) {
				_emitVueEvent(PROXYCONST.EVENT_TIMER_TICK, start);
				_timerListeners.slice().forEach(function(listener) {
					listener(start);
				});
				_lastProcessedTimerTick = start;
				return true;
			};

			/**
			* Timer tick callback handler.
			* @param data
         */
			const _timerTickHandler = function(timerTickEvent) {
				var start, end, diff, discardThreshold, processed;

				start = finesse.utilities.Utilities.currentServerTimeMillis();
				processed = false;

				//Prevent starvation of timer logic
				if (_lastProcessedTimerTick === null) {
					processed = _processTick(start);
				} else {
					if ((_lastProcessedTimerTick + _forceTickProcessingEvery) <= start) {
						//Force processing at least every _forceTickProcessingEvery milliseconds
						processed = _processTick(start);
					}

					end = finesse.utilities.Utilities.currentServerTimeMillis();
					diff = end - start;
					if (diff > _maxTimerCallbackThreshold) {
						$log.log("Softphone took too long to process timer tick (_maxTimerCallbackThreshold exceeded).");
					}
				}
			};


			SoftPhoneDataOp.createTimer = function(scope, callback, time) {
				const timerProto = {
					listener: null,
					time: 0,

					start(ini) {
						var _this = this;
						_this.time = finesse.utilities.Utilities.currentServerTimeMillis(); + (ini || 0);
						_this.listener = _onTimerTick(function(t) {
							callback(t - _this.time);
                });
            },

			stop() {
				isFunction(this.listener) && this.listener();
            }
		};

		const timer = Object.create(timerProto);

			timer.scope = scope;
			timer.callback = callback;
			timer.time = time || 0;
			return timer;
		}


		/**
		 * Performs all initialization for this gadget
		 */
		var init = function() {
			// TODO: Replace this testing override with the real location resolution logic.
			softPhoneConfig._location = "DUL";
			softPhoneConfig._cm = logContext.cm || null;;
			
			/*softPhoneConfig._userId = null;
			
						*/
			var cfg = finesse.gadget.Config;

			finesse.clientservices.ClientServices.init(cfg, false);
			containerServices = finesse.containerservices.ContainerServices.init();
			finesse.containerservices.ContainerServices.addHandler(
				finesse.containerservices.ContainerServices.Topics.TIMER_TICK_EVENT,
				_timerTickHandler);

			finesse.containerservices.ContainerServices.addHandler(
				finesse.containerservices.ContainerServices.Topics.ACTIVE_TAB,
				function() {
					gadgets.window.adjustHeight();
				}
			);

			User = new finesse.restservices.User({
				id: cfg.id,
				onLoad: _handleUserLoad,
				onChange: _handleUserChange,
				onError: _handleFinesseError("User service"),
			});

			$log.debug("< init end.");
		};

		const _handleUserLoad = function(user) {
			let data = user.getData();

			if (
				softPhoneConfig.agentState === null ||
				isUndefined(softPhoneConfig.agentState)
			) {
				softPhoneConfig.agentState = {};
			}

			softPhoneConfig._extension = User.getExtension();
			softPhoneConfig.userFirstName = User.getFirstName();
			softPhoneConfig.userLastName = User.getLastName();
			softPhoneConfig.userLoginName = data.loginName;
			softPhoneConfig._userId = data.loginId;
			softPhoneConfig.wrap = User.getWrapUpOnIncoming();

			let reasonCode = User.getReasonCode();
			let code = (reasonCode && reasonCode.code) || "";
			let label = (reasonCode && reasonCode.label) || "";
			let stateChangeTime = User.getStateChangeTime();

			SoftPhoneDataOp.sendAgentState(
				User.getState(),
				null,
				label,
				stateChangeTime ? new Date(stateChangeTime).getTime() : null,
				0,
				null,
				code
			);

			User.getNotReadyReasonCodes(
				_handlers(_getUserStateNotReadyReasonCodesHandler, _handleFinesseError("getting Not Reason Codes"))
			);

			User.getDialogs({
				onLoad: _handleDialogsLoad,
				onCollectionAdd: _handleAddDialog,
				onCollectionDelete: _handleDeleteDialog,
				onError: _handleFinesseError("Dialog service"),
			});
		};

		const _handleUserChange = function(user) {
			let oldState = softPhoneConfig.agentState;

			let reasonCode = User.getReasonCode();
			let code = (reasonCode && reasonCode.code) || "";
			let label = (reasonCode && reasonCode.label) || "";
			let id = (reasonCode && reasonCode.id) || 0;
			let state = user.getState();

			if (
				state === PROXYCONST.AGENT_STATE.NOT_READY &&
				id === 0 &&
				oldState &&
				oldState.state === PROXYCONST.AGENT_STATE.NOT_READY &&
				oldState.reasonCodeId !== 0
			) {
				$log.info("event reason code is 0 (agent being re-skilled) begin");
				softPhoneConfig.reskilling = oldState.reasonCodeId;
				SoftPhoneDataOp.notReady(
					softPhoneConfig.finesseNotReadyReasonReskillingGlobal
				);
			} else {
				let pending = User.getPendingStateReasonCode();
				pending = (pending && pending.label) || null;
				let stateChangeTime = User.getStateChangeTime();

				SoftPhoneDataOp.sendAgentState(
					state,
					null,
					label,
					stateChangeTime ? new Date(stateChangeTime).getTime() : null,
					id,
					pending,
					code
				);
			}
		};



		const _handleFinesseError = function(request, errorHandler) {
			return function(rsp) {

				softPhoneConfig.mainCallState.pendingUpdate = null;

				var status = rsp.status;
				let errors = rsp.object && rsp.object.ApiErrors && rsp.object.ApiErrors.ApiError;

				function processError(error) {
					$log.error('Finesse Api Error (' + status + ') when ' + request + ':' + error.ErrorType + ', ' +
						error.ErrorMessage + (error.ErrorData ? (': ' + error.ErrorData) : ''));
				}

				if (Array.isArray(errors)) {
					for (let error of errors) {
						processError(error);
					}
				} else if (errors) {
					processError(errors);
				} else {
					$log.error('Finesse Api Error (' + status + ') when ' + request + ':' + rsp);
				}

				if (isFunction(errorHandler)) {
					errorHandler(rsp);
				}
			};
		}

		const _handleDialogsLoad = function(dialogs) {
			MainDialog = null;
			ConsultDialog = null;
			let collection = dialogs.getCollection();
			if (isEmptyObject(collection)) {
				softPhoneConfig.mainCallState = PROXYCONST.NULL_CALL;
				_emitVueEvent(PROXYCONST.EVENT_TYPE_MAIN_CALL_CHANGE);
			} else  {
				for (var dialogId in collection) {
    				if (collection.hasOwnProperty(dialogId)) {
        				var dialog = collection[dialogId];
						if(dialog.getMediaProperties().callType === 'CONSULT') {
							ConsultDialog = dialog;
							_handleAddDialog(dialog);
						} else {
							MainDialog = dialog;
							_handleAddDialog(dialog);
						}
					}
				}
			}
		};

		const _handleAddDialog = function(dialog) {
				dialog.addHandler("load", _handleDialog);
				dialog.addHandler("delete", _handleDeleteDialog);
				dialog.addHandler("change", _handleDialog);
				dialog.addHandler("error", _handleFinesseError("adding dialog"));
		};

		const _handleDialog = function(dialog) {
			if(!MainDialog || dialog._id === MainDialog._id){
				_handleMainDialog(dialog);
			} else if (!ConsultDialog && dialog.getMediaProperties().callType === 'CONSULT' ||
						ConsultDialog && dialog._id === ConsultDialog._id) {
				_handleConsultDialog(dialog);
			}
		}

		const _handleDeleteDialog = function(dialog) {
			if(dialog._id === MainDialog._id){
				_handleMainDialog(dialog);
				MainDialog = null;
			} else if (dialog.getMediaProperties().callType === 'CONSULT' ||
						ConsultDialog && dialog._id === ConsultDialog._id) {
				_handleConsultDialog(dialog);
				ConsultDialog = null;
			}
		};

		var _autoResumeInFlight = false;

		function _syncHeldDialogs(changedDialogType, previousState, currentState) {
			if (_autoResumeInFlight || previousState === currentState || currentState !== 'HELD') {
				return;
			}

			if (changedDialogType === 'main') {
				if (softPhoneConfig.consultCallState && softPhoneConfig.consultCallState.state === 'HELD' && ConsultDialog) {
					_autoResumeInFlight = true;
					retrieveConsultCall(
						function() {
							_autoResumeInFlight = false;
						},
						function(error) {
							_autoResumeInFlight = false;
							SoftPhoneDataOp._errorHandler(error);
						}
					);
				}
				return;
			}

			if (changedDialogType === 'consult') {
				if (softPhoneConfig.mainCallState && softPhoneConfig.mainCallState.state === 'HELD' && MainDialog) {
					_autoResumeInFlight = true;
					SoftPhoneDataOp.retrieveMainCall(
						function() {
							_autoResumeInFlight = false;
						},
						function(error) {
							_autoResumeInFlight = false;
							SoftPhoneDataOp._errorHandler(error);
						}
					);
				}
			}
		}

		const _handleMainDialog = function(dialog) {

			softPhoneConfig.mainCallState.previousState = softPhoneConfig.mainCallState.state;
			
			if (softPhoneConfig.mainCallState.id === null) {
				softPhoneConfig.mainCallState.id = dialog._id;
				softPhoneConfig.consultCallState.id = null;
			}

			MainDialog = dialog;
			softPhoneConfig.mainCallState.id = dialog._id;
			softPhoneConfig.mainCallState.state = dialog.getState();
			softPhoneConfig.mainCallState.from = dialog.getFromAddress();
			softPhoneConfig.mainCallState.to = dialog.getToAddress();
			if (softPhoneConfig.mainCallState.from === softPhoneConfig._extension) {
				softPhoneConfig.mainCallState.direction = "OUT";
			} else {
				softPhoneConfig.mainCallState.direction = "IN";
			}

			let mediaProps = dialog.getMediaProperties();

			softPhoneConfig.mainCallState.skill = mediaProps.queueName || "";
			softPhoneConfig.mainCallState.callType = mediaProps.callType || "";
			softPhoneConfig.mainCallState.dialedNumber = mediaProps.dialedNumber;
			softPhoneConfig.mainCallState.wrapUpReason = mediaProps.wrapUpReason;

			dialog.getParticipants().forEach(function(participant) {
				if (participant.mediaAddress === softPhoneConfig._extension) {
					if (participant.state === "HELD") {
						softPhoneConfig.mainCallState.state = "HELD";
					} else if (participant.state === "WRAP_UP") {
						softPhoneConfig.mainCallState.state = "WRAP_UP";
					} else if (participant.state === "DROPPED") {
						softPhoneConfig.mainCallState.state = "END";
					}
				}
			});

			// conference add participants numbers
			if (softPhoneConfig.mainCallState.state !== "WRAP_UP") {
				softPhoneConfig.mainCallState.parties = "";
				var parties = 0;
				softPhoneConfig.mainCallState.participants = dialog.getParticipants();
				softPhoneConfig.mainCallState.participants.forEach(function(
					participant
				) {
					if (participant.mediaAddress !== softPhoneConfig._extension) {
						if (participant.state !== "DROPPED") {
							if (parties > 0) {
								softPhoneConfig.mainCallState.parties += " - ";
								softPhoneConfig.mainCallState.direction = "IN";
							}
							softPhoneConfig.mainCallState.parties +=
								participant.mediaAddress;
							parties++;
						}
					} else {
						softPhoneConfig.mainCallState.startTime = participant.startTime;
					}
				});

				if (softPhoneConfig.callData.ecc.originalAni) {
					softPhoneConfig.mainCallState.parties =
						softPhoneConfig.mainCallState.parties.replace(
							softPhoneConfig.mainCallState.from,
							softPhoneConfig.callData.ecc.originalAni
						);
				}
			}

			// check if there is a consult call

			softPhoneConfig.mainCallState.consultCall =
				!!softPhoneConfig.consultCallState.id;
			softPhoneConfig.mainCallState.actions = _findActions(softPhoneConfig.mainCallState);

        	$log.logObfuscated('Main Call State:' + softPhoneConfig.mainCallState.state, softPhoneConfig.mainCallState);

			if (softPhoneConfig.mainCallState.id !== null) {
                if (softPhoneConfig.mainCallState.state === 'FAILED') {
                    softPhoneConfig.mainCallState.from = 'FAILED';
                    softPhoneConfig.mainCallState.parties = 'FAILED';
                    softPhoneConfig.mainCallState.to = 'FAILED';
                }
            }
			
			if (
				(softPhoneConfig.mainCallState.state === "WRAP_UP" &&
					softPhoneConfig.mainCallState.previousState !== "WRAP_UP") ||
				(softPhoneConfig.mainCallState.state === "END" &&
					softPhoneConfig.mainCallState.previousState !== "WRAP_UP")
			) {
				if (isFunction(softPhoneConfig.endCallHook)) {
					softPhoneConfig.endCallHook();
				} else if (softPhoneConfig.niceHook !== null) {
					var callId = softPhoneConfig.mainCallState.id || softPhoneConfig.mainCallState.endId;
					SoftPhoneDataOp._updateNiceBizData(callId);
				}
			} else if (isFunction(softPhoneConfig.mainCallState.pendingUpdate) &&
				softPhoneConfig.mainCallState.actions &&
				softPhoneConfig.mainCallState.actions.includes("UPDATE_CALL_DATA")) {
				const callback = softPhoneConfig.mainCallState.pendingUpdate;
				softPhoneConfig.mainCallState.pendingUpdate = null;
				callback();
			}
			
			if (Object.keys(mediaProps).length > 0) {
			        SoftPhoneDataOp._callDataHandler(mediaProps);
			} else if ( softPhoneConfig.mainCallState.direction === 'IN' &&
			            softPhoneConfig.mainCallState.state === 'ALERTING' ) {
			            _emitVueEvent(PROXYCONST.EVENT_CLEAR_CTI_FIELD);
			}

			_syncHeldDialogs('main', softPhoneConfig.mainCallState.previousState, softPhoneConfig.mainCallState.state);

			_emitVueEvent(PROXYCONST.EVENT_TYPE_MAIN_CALL_CHANGE);
		};

		const _handleConsultDialog = function(dialog) {
			softPhoneConfig.consultCallState.previousState = softPhoneConfig.consultCallState.state;
			ConsultDialog = dialog;
			softPhoneConfig.mainCallState.consultCall = true;
			softPhoneConfig.consultCallState.id = dialog._id;
			softPhoneConfig.consultCallState.state = dialog.getState();
			softPhoneConfig.consultCallState.from = dialog.getFromAddress();
			softPhoneConfig.consultCallState.to = dialog.getToAddress();
			if (softPhoneConfig.consultCallState.from === softPhoneConfig._extension) {
				softPhoneConfig.consultCallState.direction = "OUT";
			} else {
				softPhoneConfig.consultCallState.direction = "IN";
			}

			let mediaProps = dialog.getMediaProperties();

			softPhoneConfig.consultCallState.skill = mediaProps.queueName || "";
			softPhoneConfig.consultCallState.callType = mediaProps.callType || "";
			softPhoneConfig.consultCallState.dialedNumber = mediaProps.dialedNumber;
			softPhoneConfig.consultCallState.wrapUpReason = mediaProps.wrapUpReason;

			dialog.getParticipants().forEach(function(participant) {
				if (participant.mediaAddress === softPhoneConfig._extension) {
					if (participant.state === "HELD") {
						softPhoneConfig.consultCallState.state = "HELD";
					} else if (participant.state === "WRAP_UP") {
						softPhoneConfig.consultCallState.state = "WRAP_UP";
					} else if (participant.state === "DROPPED") {
						softPhoneConfig.consultCallState.state = "END";
					}
				}
			});


			if (softPhoneConfig.consultCallState.state === 'END' && softPhoneConfig.mainCallState.state === 'ACTIVE' &&
				softPhoneConfig.mainCallState.callType === 'CONFERENCE') {

				if (isFunction(softPhoneConfig.endConsultCallHook)) {
					softPhoneConfig.endConsultCallHook()
				} else if (softPhoneConfig.niceHook !== null) {
					SoftPhoneDataOp._updateNiceBizData(softPhoneConfig.mainCallState.id);
				}
			}

			_syncHeldDialogs('consult', softPhoneConfig.consultCallState.previousState, softPhoneConfig.consultCallState.state);

			_emitVueEvent(PROXYCONST.EVENT_TYPE_CONSULT_CALL_CHANGE);
		};





		const _getUserStateNotReadyReasonCodesHandler = function(data) {
			softPhoneConfig.finesseNotReadyReasonCodesUnfiltered = data;
			softPhoneConfig.businessConfiguration.finesseNotReadyReasonCodes =
				SoftPhoneDataOp.filterFinesseReasonCodeBySoftphoneConfiguration();

			if (isEmptyObject(softPhoneConfig.businessConfiguration)) {
				loadConfig();
			} else {
				updateBusinessConfig();
			}
		};

		/**
		 * Load the configuration from browser db
		 *
		 */
		const loadConfig = function() {
			updateBusinessConfig();
		};

		function normalizeNiceEnabled(value) {
			if (Array.isArray(value)) {
				return value.map(function(item) {
					return String(item || '').trim();
				}).filter(function(item) {
					return item.length > 0;
				});
			}

			if (!isDefined(value) || value === null) {
				return [];
			}

			if (isObject(value)) {
				return Object.keys(value).map(function(key) {
					return String(value[key] || '').trim();
				}).filter(function(item) {
					return item.length > 0;
				});
			}

			return String(value).split(/[\s,;|]+/).map(function(item) {
				return item.trim();
			}).filter(function(item) {
				return item.length > 0;
			});
		}

		/**
		 * saves the business configuration and sends the message there is a new one
		 */
		SoftPhoneDataOp.sendConfiguration = function(skipTimer) {
			softPhoneConfig.businessConfiguration = isUndefined(
				softPhoneConfig.businessConfiguration
			)
				? {}
				: softPhoneConfig.businessConfiguration;

			softPhoneConfig.businessConfiguration.niceEnabled =
				normalizeNiceEnabled(softPhoneConfig.businessConfiguration.niceEnabled);

			softPhoneConfig.businessConfiguration.finesseNotReadyReasonCodes =
				SoftPhoneDataOp.filterFinesseReasonCodeBySoftphoneConfiguration();
			if (isFunction(softPhoneConfig.bizConfigHook)) {
				softPhoneConfig.bizConfigHook();
			}
			_emitVueEvent(
				PROXYCONST.EVENT_TYPE_BUSINESS_CONFIG_CHANGE,
				softPhoneConfig.businessConfiguration
			);

			if (!skipTimer && softPhoneConfig.reloadBiz) {
				reloadBizConfig();
			}
		};

		// waits an hour to check for a new buisness config
		function reloadBizConfig() {
			$timeout(function() {
				if (softPhoneConfig.agentState.state === "NOT_READY") {
					User.getNotReadyReasonCodes(
						_handlers(_getUserStateNotReadyReasonCodesHandler, _handleFinesseError("reloading Not Ready Reason Codes"))
					);
				} else {
					softPhoneConfig.refreshBiz = true;
				}
			}, 3600000);
		}

		function updateBusinessConfig() {
			loadBusinessConfig().then(
				function successCallbackBusinessConfig(response) {
					if (
						!response.data ||
						!response.data.phonebook ||
						!response.data.reasonCode
					) {
						// try reloading biz config
						if (softPhoneConfig.reloadBiz) {
							reloadBizConfig();
						}
					} else {
						softPhoneConfig.businessConfiguration = response.data;
						softPhoneConfig.businessConfiguration.niceEnabled =
							normalizeNiceEnabled(softPhoneConfig.businessConfiguration.niceEnabled);
						softPhoneConfig.businessConfiguration.finesseNotReadyReasonCodes =
							SoftPhoneDataOp.filterFinesseReasonCodeBySoftphoneConfiguration();
						SoftPhoneDataOp.sendConfiguration();
						softPhoneConfig.refreshBiz = false;
					}
				},
				function errorCallbackBusinessConfig(response) {
					$log.error(response);
					// try reloading biz config
					if (softPhoneConfig.reloadBiz) {
						reloadBizConfig();
					}
				}
			);
		}

		// Calls the WS to get configuration
		function loadBusinessConfig() {
			return new Promise(function(resolve, reject) {
				jQuery.ajax({
					url: wsPath + "softphone/businessconfig",
					method: "GET",
					dataType: "xml",
					timeout: 10000,
					headers: {
						BUSINESS: softPhoneConfig._location || "",
					},
				}).done(function(xmlDoc, textStatus, jqXHR) {
					var data = parseBusinessConfigXml(xmlDoc);
					resolve({ status: jqXHR.status, data: data, object: data });
				}).fail(function(jqXHR) {
					reject({ status: jqXHR.status, data: jqXHR.responseText });
				});
			});
		}

		function parseBusinessConfigXml(xmlDoc) {
			function parseSection(tag) {
				return jQuery(xmlDoc).find(tag + " > " + tag).map(function() {
					var obj = {};
					jQuery(this).children().each(function() {
						obj[this.tagName] = jQuery(this).text();
					});
					return obj;
				}).get();
			}

			function parseMap(element) {
				var obj = {};
				jQuery(element).children().each(function() {
					obj[this.tagName] = jQuery(this).text();
				});
				return obj;
			}
			
			var result = {};
			var root = jQuery(xmlDoc).find(":root");
			
			// Dynamically parse all elements - sections, key-value maps, or scalars
			root.children().each(function() {
				var tagName = this.tagName;
				// Check if this tag contains nested elements with the same name (section/collection pattern)
				var nestedElements = jQuery(xmlDoc).find(tagName + " > " + tagName);
				
				if (nestedElements.length > 0) {
					if (tagName === 'niceEnabled') {
						result[tagName] = nestedElements.map(function() {
							return jQuery(this).text();
						}).get().map(function(item) {
							return String(item || '').trim();
						}).filter(function(item) {
							return item.length > 0;
						});
						return;
					}
					// It's a section - parse as a collection of objects
					result[tagName] = parseSection(tagName);
				} else if (jQuery(this).children().length > 0) {
					// It has children with distinct tag names - parse as a key-value map object
					result[tagName] = parseMap(this);
				} else {
					// It's a scalar value - extract text
					result[tagName] = jQuery(this).text();
				}
			});
			
			return result;
		}

		/**
		 * Filter reason code to only include results that are related to business configuration
		 *
		 * @return {Object} filtered results
		 */
		SoftPhoneDataOp.filterFinesseReasonCodeBySoftphoneConfiguration =
			function() {
				var _finesseNotReadyReasonAgentForcedLogoutGlobalFound = false;
				var result = [];

				if (
					Array.isArray(
						softPhoneConfig.finesseNotReadyReasonCodesUnfiltered
					) &&
					isDefined(softPhoneConfig.businessConfiguration.reasonCode)
				) {
					var reasonCodeOrderSet = {}; // new Set();
					for (
						var i = 0;
						i < softPhoneConfig.businessConfiguration.reasonCode.length;
						i++
					) {
						var businessConfigurationReasonCode =
							softPhoneConfig.businessConfiguration.reasonCode[i];
						reasonCodeOrderSet[businessConfigurationReasonCode.reasonCode] =
							businessConfigurationReasonCode.order;
					}

					for (
						i = 0;
						i < softPhoneConfig.finesseNotReadyReasonCodesUnfiltered.length;
						i++
					) {
						var reasonCode =
							softPhoneConfig.finesseNotReadyReasonCodesUnfiltered[i];
						var code = reasonCode.code;

						var reasonCodeOrder = reasonCodeOrderSet[code];
						if (isDefined(reasonCodeOrder)) {
							reasonCode.order = reasonCodeOrder;
							result.push(reasonCode);
						}
					}

					result.sort(function(a, b) {
						if (a.order > b.order) {
							return 1;
						} else if (b.order > a.order) {
							return -1;
						} else {
							return a.label.localeCompare(b.label);
						}
					});
				}

				if (_finesseNotReadyReasonAgentForcedLogoutGlobalFound == false) {
					$log.error(
						"Could not find Finesse code for 2999,AgentForcedLogoutGlobal"
					);
				}

				return result;
			};

		/**
		 * agents dialog handler
		 *
		 * @param {Object} data
		 */


		/**
		 * Find actions
		 */
		var _findActions = function(call) {
			// dont recalculate button if we are dropping a call

			const participants = call.participants;
			
			if (participants) {
			    var processActions = function (value) {
			        var createActionsMap = function(actionValue){
			            var actionsMap = {};
			            if (actionValue.actions && actionValue.actions.action) {
				                if (Array.isArray(actionValue.actions.action)) {
			                    actionsMap = actionValue.actions.action.reduce(function (map, currentValue) {
			                        map[currentValue] = currentValue;
			                        return map;
			                    }, {});
			                } else {
			                    // there is only one action
			                    // set that as map
			                    actionsMap[actionValue.actions.action] = actionValue.actions.action;
			                }
			            }

			            return actionsMap;
			        };

			        if (value.mediaAddress === softPhoneConfig._extension) {
			    		if(call.id===softPhoneConfig.mainCallState.id){
			    			softPhoneConfig.actions.mainCall = createActionsMap(value);
			    		}

			        	if(call.id===softPhoneConfig.consultCallState.id){
			        		softPhoneConfig.actions.consultCall = createActionsMap(value);
			        	}
			        }
			    };

				if (Array.isArray(participants)) {
			    	participants.forEach(processActions);
				} else {
			    	processActions(participants);
				}
			}
	    };
		


        
        
        function changeLanguage(){ 
        
	        var lang ='';
	        
	        switch (softPhoneConfig.callData.ecc.callerLanguage) {
	        
	            case 'English':
					lang = 'en_US';
					break;
				case 'Ingles':
					lang = 'en_US';
					break;
				case 'Ingl\u00E9s':
					lang = 'en_US';
					break;
				case 'Spanish':
					lang = 'es';
					break;
				case 'Espanol':
					lang = 'es';
					break;
				case 'Espa\u00f1ol':
					lang = 'es';
					break;
				case 'French':
					lang = 'fr';
					break;
				case 'Frances':
					lang = 'fr';
					break;
				case 'Franc\u00E9s':
					lang = 'fr';
					break;
				default:
					lang = $translate.use();
					break;
	        }
	        
	        return lang;
        
        }
        /**
         * Update main call data
         *
         * @param {function} _handler
         * @param {function} _errHandler
         */
        var updateMainCallData = function(_handler, _errHandler) {
            var callData = softPhoneConfig.callData;
            var dataMap = {};
			if (isDefined(callData)) {
                dataMap = ctiDataService.pack(callData.ecc);
            }

			_updateCallData(MainDialog, dataMap, _handler, _errHandler);
            
            if(softPhoneConfig.mainCallState.consultCall && softPhoneConfig.consultCallState.state === 'ACTIVE') {
				_updateCallData(ConsultDialog, dataMap, _handler, _errHandler);
            }
        };

        /**
         * Update main call wrap up
         *
         * @param {String} wrapUpDesc
         * @param {function} _handler
         * @param {function} _errHandler
         */
        var updateMainCallWrapup = function(wrapUpDesc, _handler, _errHandler) {
			if(isDefined(softPhoneConfig.actions.mainCall) &&
				isDefined(softPhoneConfig.actions.mainCall['UPDATE_CALL_DATA'])) {
				_updateWrapup(MainDialog, wrapUpDesc, _handler, _errHandler);

					/*if (
					  softPhoneConfig.mainCallState.consultCall &&
					  softPhoneConfig.consultCallState.state === "ACTIVE"
					) {
					  _updateWrapup(
						softPhoneConfig.consultCallState.id,
						wrapUpDesc,
						handler,
						errHandler
					  );
                }
					*/
            }
        };

        /**
         * Update main call data and wrap up
         *
         * @param {String} wrapUpDesc
         * @param {function} _handler
         * @param {function} _errHandler
         */
        var updateMainCallDataAndWrapup = function(wrapUpDesc, _handler, _errHandler) {
            var callData = softPhoneConfig.callData;
            var dataMap = {};
			if (isDefined(callData)) {
                dataMap = ctiDataService.pack(callData.ecc);
            }

			_updateCallDataAndWrapup(MainDialog, dataMap, wrapUpDesc, _handler, _errHandler);
            if(softPhoneConfig.mainCallState.consultCall && softPhoneConfig.consultCallState.state === 'ACTIVE') {
				_updateCallDataAndWrapup(ConsultDialog, dataMap, wrapUpDesc, _handler, _errHandler);
            }
        };

			var retrieveConsultCall = function(handler, errHandler) {
				return _requestDialogAction(ConsultDialog, 'RETRIEVE', "retrieving consult call", handler, errHandler);
        };

        /**
         * Setup customization if available
         *
         * @param {String} data
         */
        SoftPhoneDataOp.getCustomization = function(data) {

	        if (isDefined(data.nacwDisabled)) {
                softPhoneConfig.nacwDisabled = data.nacwDisabled;
            }

			if ( isDefined(data.acwDisabled)) {
                softPhoneConfig.acwDisabled = data.acwDisabled;
            }

			if (isDefined(data.departmentDisabled)) {
                softPhoneConfig.deptDisabled = data.departmentDisabled;
            }

			if (isDefined(data.departmentManual)) {
                softPhoneConfig.deptManual = data.departmentManual;
            }

			if (isDefined(data.customView) && data.customView !== null) {
                softPhoneConfig.customView = data.customView;
            }
        };

        /**
         * Call data handler
         *
         * @param {Object} callDataMap
         */
        SoftPhoneDataOp._callDataHandler = function(callDataMap) {
            var userContactCTI0 = '';
            var userContactCTI1 = '';
            var userContactCTI2 = '';
            var userMap = {};

			Object.keys(callDataMap || {}).forEach(function(key) {
				var value = callDataMap[key];
				if(value !== null && value !== undefined) {
					if (key === PROXYCONST.ECC.USER_CONTACT_CTI_0) {
						userContactCTI0 = value;
					} else if (key === PROXYCONST.ECC.USER_CONTACT_CTI_1) {
						userContactCTI1 = value;
					} else if (key === PROXYCONST.ECC.USER_CONTACT_CTI_2) {
						userContactCTI2 = value;
					} else if (key.indexOf('user.') === 0) {
						userMap[key.substring(5)] = value;
					}
				}
            });

            var userContactCTI = userContactCTI0 + userContactCTI1 + userContactCTI2;
            var userContactCTIMap = ctiDataService.parse(userContactCTI);

			    if (isUndefined(userContactCTIMap.callerLanguage) ||
                    userContactCTIMap.callerLanguage === null ||
				    !isString(userContactCTIMap.callerLanguage) ) {
                        userContactCTIMap.callerLanguage = 'en';
            }

            userContactCTIMap.callerLanguage = userContactCTIMap.callerLanguage.length > 2 &&
            (userContactCTIMap.callerLanguage.charAt(2) === '-' ||  userContactCTIMap.callerLanguage.charAt(2) === '_')
                                            ? userContactCTIMap.callerLanguage.substring(0, 2)
                                : userContactCTIMap.callerLanguage;

            if (userContactCTIMap.callerLanguage.length === 2 ) {
                var key = 'language.' + userContactCTIMap.callerLanguage.toLowerCase();
                var language = $translate.instant(key);

                if (language !== null && language !== key) {
                    userContactCTIMap.callerLanguage = language;
                }
            }

			if (isUndefined(userContactCTIMap.originalDnis) && isDefined(userMap.DNIS)) {
                userContactCTIMap.originalDnis = userMap.DNIS;
            }

			if (isUndefined(userContactCTIMap.originalAni)) {
                userContactCTIMap.originalAni = softPhoneConfig.mainCallState.from;
            }

            var callData = {
                ecc: userContactCTIMap,
                callVariable1: callDataMap[PROXYCONST.CALLVARIABLES.CALLVARIABLE1],
                callVariable2: callDataMap[PROXYCONST.CALLVARIABLES.CALLVARIABLE2],
                callVariable3: callDataMap[PROXYCONST.CALLVARIABLES.CALLVARIABLE3],
                callVariable4: callDataMap[PROXYCONST.CALLVARIABLES.CALLVARIABLE4],
                callVariable5: callDataMap[PROXYCONST.CALLVARIABLES.CALLVARIABLE5],
                callVariable6: callDataMap[PROXYCONST.CALLVARIABLES.CALLVARIABLE6],
                callVariable7: callDataMap[PROXYCONST.CALLVARIABLES.CALLVARIABLE7],
                callVariable8: callDataMap[PROXYCONST.CALLVARIABLES.CALLVARIABLE8],
                callVariable9: callDataMap[PROXYCONST.CALLVARIABLES.CALLVARIABLE9],
                callVariable10: callDataMap[PROXYCONST.CALLVARIABLES.CALLVARIABLE10],
                user: userMap,
                wrapUpReason: softPhoneConfig.mainCallState.wrapUpReason,
            };

           softPhoneConfig.callData = callData;
           
		   if (softPhoneConfig.callDataHook !== null && isFunction(softPhoneConfig.callDataHook)) {
                softPhoneConfig.callDataHook();
            }

            if (softPhoneConfig.callData.ecc.originalAni && softPhoneConfig.mainCallState.parties) {
                softPhoneConfig.mainCallState.parties = softPhoneConfig.mainCallState.parties.replace(
                softPhoneConfig.mainCallState.from, softPhoneConfig.callData.ecc.originalAni);
            }

            $log.infoObfuscated('Call Data' , callData, {dwh:true});
            
            if(softPhoneConfig.transferToSurvey) {
            	$log.info("Direct Transfering to " + softPhoneConfig.transferToSurvey);
            	SoftPhoneDataOp.makeDirectTransfer(softPhoneConfig.transferToSurvey);
            	softPhoneConfig.transferToSurvey = null;
            }
            
		    _emitVueEvent(PROXYCONST.EVENT_TYPE_CALL_DATA_CHANGE);
        };

		function clearCall() {
                softPhoneConfig.callData = { ecc: {}, user: {} };
                softPhoneConfig.mainCallState = {};
		        softPhoneConfig.mainCallState.id= null;
		        softPhoneConfig.mainCallState.state = 'END';
		        softPhoneConfig.consultCallState = {};
		        softPhoneConfig.consultCallState.id = null; 
		        //reset actions
		        softPhoneConfig.actions.mainCall={};
		        softPhoneConfig.actions.consultCall={};
		} 


        /**
         * Broadcast state has changed
         *
         * @param {String} state
         * @param {String} errorMessage
         * @param {String} reasonCodeDescription
         * @param {String} stateChangeTime
         */
        SoftPhoneDataOp.sendAgentState = function(state, errorMessage, reasonCodeDescription, stateChangeTime,reasonCodeId, pendingState, reasonCode) {
            var message = {
                state: state,
                errorMessage: errorMessage,
                reasonCode: reasonCode,
                reasonCodeDescription: reasonCodeDescription,
                reasonCodeId:reasonCodeId,
                stateChangeTime: stateChangeTime,
                pendingState: pendingState,
            };
            softPhoneConfig.agentState = message;

            if(softPhoneConfig.mainCallState.state === "END" && (state === "READY" || state === "NOT_READY") ||
            	state === "LOGOUT") {
				clearCall();	
            }
            
            if(state === "NOT_READY" && softPhoneConfig.refreshBiz && softPhoneConfig.reloadBiz) {
            	updateBusinessConfig();
            }
            
				_emitVueEvent(PROXYCONST.EVENT_TYPE_AGENT_STATUS_CHANGE, message);
        };


 		SoftPhoneDataOp._errorHandler = function(error) {
			$log.error(error);
        };
 
        SoftPhoneDataOp._updateNiceBizData = function(callId) {
	        if (isFunction(softPhoneConfig.niceHook) &&
            		softPhoneConfig.businessConfiguration.niceUrl &&
	            		Array.isArray(softPhoneConfig.businessConfiguration.niceEnabled) &&
            			(softPhoneConfig.businessConfiguration.niceEnabled.indexOf('ALL') !== -1 ||
            					softPhoneConfig.businessConfiguration.niceEnabled.indexOf(softPhoneConfig._location) !== -1 )) {
	        
	        var nicePayload = softPhoneConfig.niceHook();
	    	
	    	if(nicePayload && isObject(nicePayload) && !isEmptyObject(nicePayload)) {
	    		var csrfInput = document.getElementById('_masterVoiceCsrfToken');
	    		var csrfHeaderName = csrfInput && csrfInput.getAttribute('data-header');
	    		var csrfToken = csrfInput && csrfInput.value;
	    	
    			let ivrCallId = softPhoneConfig.callData &&
    						(softPhoneConfig.callData.ecc.ivrCallId ||
    								(softPhoneConfig.callData.user && softPhoneConfig.callData.user['media.id'])) || '';
	    	
	        	var config = {
	            		headers: {'Content-Type': 'application/json',
	            					'callId': callId,
	            					'ivrCallId':ivrCallId}
	            };

				if (csrfHeaderName && csrfToken) {
					config.headers[csrfHeaderName] = csrfToken;
				}
	
	        	var bizData = [];
	        	
	        	function addBd(key) {
	        		bizData.push({"bdName":key, "bdValue": nicePayload[key]});
	        	}
	
	        	Object.keys(nicePayload).forEach(addBd);
	        	
	        	var data = {
	        			callExternalInfo: {
	        				callId:callId,
	        				callIdType:2
	        			},
	        			businessCallData: bizData,
	        	};
	        	
	        	fetch(wsPath + softPhoneConfig.businessConfiguration.niceUrl, {
	        		method: "POST",
	        		headers: config.headers,
	        		body: JSON.stringify(data),
	        	}).then(function(response) {
	        		if (!response.ok) {
	        			return Promise.reject(response);
	        		}
	        		$log.info('NICE: send was attempted successfully');
	        	}).catch(function() {
	           	    $log.info('NICE: send errored out');
	            	});
	    			}
				}
        };
        
        /**
         * default handler for async calls. This just logs the values
         *
         * @param {any} data
         */
        var defaultHandler = function(data) {
        	if(data){
        		$log.debug(data);
        	}
        };

			var _handlers = function(handler, errHandler) {
				if (!isFunction(handler)) {
					handler = defaultHandler;
                }

				if (!isFunction(errHandler)) {
					errHandler = SoftPhoneDataOp._errorHandler;
            }

				return { success: handler, error: errHandler };
        };

		var _requestStateChange = function(targetState, reason, actionLabel, handler, errHandler) {
			return User.setState(
				targetState,
				reason,
				_handlers(handler, _handleFinesseError(actionLabel, errHandler))
			);
		};

		var _requestDialogAction = function(dialogObj, action, actionLabel, handler, errHandler) {
			if (!dialogObj || !isFunction(dialogObj.requestAction)) {
				return;
			}

			return dialogObj.requestAction(
				User.getExtension(),
				action,
				_handlers(handler, _handleFinesseError(actionLabel, errHandler))
			);
		};

		function _invokeHandler(handler, payload) {
			if (isFunction(handler)) {
				handler(payload);
			}
		}

		function checkParameters(args) {
			if (!args || args.length === 0 || !isString(args[0])) {
				throw new Error("First parameter has to be a valid string");
			}
		}

		function _createErrorHandler(request) {
			return _handleFinesseError(request || "softphone operation", SoftPhoneDataOp._errorHandler);
		}

		function _updateCallData(dialogObj, dataMap, handler, errHandler) {
			if (!dialogObj) {
				_invokeHandler(_handleFinesseError("updating call data", errHandler), {
					status: 0,
					object: { ApiErrors: { ApiError: { ErrorType: "DialogUnavailable", ErrorMessage: "No dialog is available for updating call data." } } },
				});
				return;
			}

			if (isFunction(dialogObj.updateCallData)) {
				return dialogObj.updateCallData(dataMap, handler, _handleFinesseError("updating call data", errHandler));
			}
			if (isFunction(dialogObj.updateCalldata)) {
				return dialogObj.updateCalldata(dataMap, handler, _handleFinesseError("updating call data", errHandler));
			}

			_invokeHandler(_handleFinesseError("updating call data", errHandler), {
				status: 0,
				object: { ApiErrors: { ApiError: { ErrorType: "UnsupportedOperation", ErrorMessage: "updateCallData/updateCalldata is not supported by the current Finesse client." } } },
			});
		}

		function _updateWrapup(dialogObj, wrapUpDesc, handler, errHandler) {
			if (!dialogObj) {
				_invokeHandler(_handleFinesseError("updating wrap up", errHandler), {
					status: 0,
					object: { ApiErrors: { ApiError: { ErrorType: "DialogUnavailable", ErrorMessage: "No dialog is available for updating wrap up." } } },
				});
				return;
			}

			if (isFunction(dialogObj.updateWrapUpReason)) {
				return dialogObj.updateWrapUpReason(wrapUpDesc, handler, _handleFinesseError("updating wrap up", errHandler));
			}
			if (isFunction(dialogObj.updateWrapUpReason)) {
				return dialogObj.updateWrapUpReason(wrapUpDesc, handler, _handleFinesseError("updating wrap up", errHandler));
			}

			_invokeHandler(_handleFinesseError("updating wrap up", errHandler), {
				status: 0,
				object: { ApiErrors: { ApiError: { ErrorType: "UnsupportedOperation", ErrorMessage: "updateWrapup/updateWrapUp is not supported by the current Finesse client." } } },
			});
		}

		function _updateCallDataAndWrapup(dialogObj, dataMap, wrapUpDesc, handler, errHandler) {
			if (!dialogObj) {
				_invokeHandler(_handleFinesseError("updating call data and wrap up", errHandler), {
					status: 0,
					object: { ApiErrors: { ApiError: { ErrorType: "DialogUnavailable", ErrorMessage: "No dialog is available for updating call data and wrap up." } } },
				});
				return;
			}

			if (isFunction(dialogObj.updateCallDataAndWrapup)) {
				return dialogObj.updateCallDataAndWrapup(dataMap, wrapUpDesc, handler, _handleFinesseError("updating call data and wrap up", errHandler));
			}
			if (isFunction(dialogObj.updateCalldataAndWrapup)) {
				return dialogObj.updateCalldataAndWrapup(dataMap, wrapUpDesc, handler, _handleFinesseError("updating call data and wrap up", errHandler));
			}

			_invokeHandler(_handleFinesseError("updating call data and wrap up", errHandler), {
				status: 0,
				object: { ApiErrors: { ApiError: { ErrorType: "UnsupportedOperation", ErrorMessage: "updateCallDataAndWrapup/updateCalldataAndWrapup is not supported by the current Finesse client." } } },
			});
		}

		function _directTransferCall(dialogObj, extension, toAddress, handler, errHandler) {
			if (!dialogObj) {
				_invokeHandler(_handleFinesseError("direct transfering to " + toAddress, errHandler), {
					status: 0,
					object: { ApiErrors: { ApiError: { ErrorType: "DialogUnavailable", ErrorMessage: "No dialog is available for direct transfer." } } },
				});
				return;
			}

			if (isFunction(dialogObj.initiateDirectTransfer)) {
				return dialogObj.initiateDirectTransfer(extension, toAddress, _handlers(handler, _handleFinesseError("direct transfering to " + toAddress, errHandler)));
			}
			if (isFunction(dialogObj.directTransferCall)) {
				return dialogObj.directTransferCall(extension, toAddress, _handlers(handler, _handleFinesseError("direct transfering to " + toAddress, errHandler)));
			}

			_invokeHandler(_handleFinesseError("direct transfering to " + toAddress, errHandler), {
				status: 0,
				object: { ApiErrors: { ApiError: { ErrorType: "UnsupportedOperation", ErrorMessage: "initiateDirectTransfer/directTransferCall is not supported by the current Finesse client." } } },
			});
		}

		function _dropCall(dialogObj, extension, handler, errHandler) {
			if (dialogObj && isFunction(dialogObj.requestAction)) {
				return dialogObj.requestAction(
					extension,
					"DROP",
					_handlers(handler, _handleFinesseError("ending consult call", errHandler))
				);
			}

			if (dialogObj && isFunction(dialogObj.dropCall)) {
				return dialogObj.dropCall(extension, handler, _handleFinesseError("ending consult call", errHandler));
			}

			_invokeHandler(_handleFinesseError("ending consult call", errHandler), {
				status: 0,
				object: { ApiErrors: { ApiError: { ErrorType: "DialogUnavailable", ErrorMessage: "No dialog is available for ending consult call." } } },
			});
		}

		function _populateOutboundCallData() {
			var callData = softPhoneConfig.callData;
			if (!isDefined(callData)) {
				return;
			}

			callData.ecc.agentName =
				softPhoneConfig.userFirstName + " " + softPhoneConfig.userLastName;

			var lang = changeLanguage();
			if (isDefined(lang)) {
				callData.ecc.callerLanguage = lang;
			}
		}

		SoftPhoneDataOp.logout = function(reasonCode, handler, errHandler) {
			reasonCode = isUndefined(reasonCode) ? null : reasonCode;
			if (reasonCode !== null && !isNumber(reasonCode)) {
				throw new Error("First parameter has to be a valid number or null");
			}

			return User.logout(reasonCode, _handleFinesseError("loging out", errHandler));
		};

		SoftPhoneDataOp.ready = function(handler, errHandler) {
			return _requestStateChange(
				PROXYCONST.AGENT_STATE.READY,
				null,
				"going Ready",
				handler,
				errHandler
			);
		};

		SoftPhoneDataOp.notReady = function(reason, handler, errHandler) {
			if (!isDefined(reason) ||
				(!isNumber(reason.id) && !isFinite(reason.id))) {
				throw new Error("Reason has to be a valid number");
			}

			return _requestStateChange(
				PROXYCONST.AGENT_STATE.NOT_READY,
				reason,
				"going Not Ready " + reason,
				handler,
				errHandler
			);
		};

		SoftPhoneDataOp.workReady = function(handler, errHandler) {
			return _requestStateChange(
				PROXYCONST.AGENT_STATE.WORK_READY,
				null,
				"requesting ACW ",
				handler,
				errHandler
			);
		};

		SoftPhoneDataOp.workNotReady = function(handler, errHandler) {
			return _requestStateChange(
				PROXYCONST.AGENT_STATE.WORK,
				null,
				"requesting ACW Not Ready",
				handler,
				errHandler
			);
		};


		SoftPhoneDataOp.makeCall = function(number, handler, errHandler) {
			if (!isString(number)) {
				throw new Error("Number has to be a valid string");
			}

			var dialNum = number.replace(/[^*#\d]/g, "");

			_populateOutboundCallData();

			var canMakeConsultCall = !!softPhoneConfig.mainCallState.id && MainDialog && isFunction(MainDialog.makeConsultCall);

			if (canMakeConsultCall) {
				MainDialog.makeConsultCall(
					softPhoneConfig._extension,
					dialNum,
					_handlers(
						handler,
						_handleFinesseError("calling " + number + (number !== dialNum ? ("->" + dialNum) : ''), errHandler)
					)
				);
			} else {
				if (softPhoneConfig.mainCallState.id && !MainDialog) {
					// Recover from stale call state where dialog was dropped before state cleanup completed.
					softPhoneConfig.mainCallState.id = null;
				}

				return User.makeCall(
					dialNum,
					_handlers(
						function() {
							softPhoneConfig.mainCallState.pendingUpdate = function() {
								updateMainCallData(handler, errHandler);
							};
						},
						_handleFinesseError("calling " + number + (number !== dialNum ? ("->" + dialNum) : ''), errHandler)
					)
				);
			}
		};

		SoftPhoneDataOp.answerMainCall = function(handler, errHandler) {
			return _requestDialogAction(MainDialog, 'ANSWER', "answering main call", handler, errHandler);
		};

		SoftPhoneDataOp.endMainCall = function(handler, errHandler) {
			return _requestDialogAction(MainDialog, 'DROP', "hangingup main call", handler, errHandler);
		};

        SoftPhoneDataOp.isSuitableForSurvey = function() {
        	return (softPhoneConfig.mainCallState.callType === 'ACD_IN' ||
                    softPhoneConfig.mainCallState.callType === 'PREROUTE_ACD_IN' ||
                    softPhoneConfig.mainCallState.callType === 'CONSULT_OFFERED' ||
                    softPhoneConfig.mainCallState.callType === 'CONFERENCE' ||
                    softPhoneConfig.mainCallState.callType === 'TRANSFER');
        };

        SoftPhoneDataOp.canTransferToSurveyCheckConference = function() {
        	var result = false;
            var participantsLen = 0;

            if (!Array.isArray(softPhoneConfig.mainCallState.participants) &&
            		softPhoneConfig.mainCallState.participants.mediaAddressType == "AGENT_DEVICE" &&
            		softPhoneConfig.mainCallState.from == "Unknown") {
            	return true;
            }

            for (var i = 0; i < softPhoneConfig.mainCallState.participants.length; i++) {
            	if (softPhoneConfig.mainCallState.participants[i].state.indexOf("WRAP") == -1 &&
            			softPhoneConfig.mainCallState.participants[i].state !== 'DROPPED') {
            		participantsLen++;
            	}
            }

            var isOneMediaAddressTypeNotAnAgent = false;
            for (i = 0; i < softPhoneConfig.mainCallState.participants.length; i++) {
            	if (softPhoneConfig.mainCallState.participants[i].state.indexOf("WRAP") == -1 &&
            			softPhoneConfig.mainCallState.participants[i].state !== 'DROPPED') {
            		if (softPhoneConfig.mainCallState.participants[i].mediaAddressType != "AGENT_DEVICE") {
            			isOneMediaAddressTypeNotAnAgent = true;
            			break;
            		}
            	}
            }

            if (participantsLen == 2 && isOneMediaAddressTypeNotAnAgent) {
            	result = true;
            }

            return result;
        };

		SoftPhoneDataOp.holdMainCall = function(handler, errHandler) {
			return _requestDialogAction(MainDialog, 'HOLD', "holding main call", handler, errHandler);
		};

		SoftPhoneDataOp.holdConsultCall = function(handler, errHandler) {
			return _requestDialogAction(ConsultDialog, 'HOLD', "holding consult call", handler, errHandler);
		};

		SoftPhoneDataOp.retrieveMainCall = function(handler, errHandler) {
			return _requestDialogAction(MainDialog, 'RETRIEVE', "retrieving main call", handler, errHandler);
		};

		SoftPhoneDataOp.makeDirectTransfer = function(toAddress, handler, errHandler) {
			if (!isString(toAddress)) {
				throw new Error("Number has to be a valid string");
			}

			var dialToAddress = toAddress.replace(/[^*#\d]/g, "");
			_populateOutboundCallData();

			updateMainCallData(
				function() {
					softPhoneConfig.mainCallState.pendingUpdate = function() {
						MainDialog.initiateDirectTransfer(
							softPhoneConfig._extension,
							dialToAddress,
							_handlers(handler, _handleFinesseError("direct transfering to " + toAddress + (toAddress !== dialToAddress ? ("->" + dialToAddress) : ''), errHandler))
						);
					};
				},
				_handlers(handler, _handleFinesseError("updating data before direct transfering to " + toAddress + (toAddress !== dialToAddress ? ("->" + dialToAddress) : ''), errHandler))
			);
		};

		var makeSurveyTransfer = function(toAddress, dataMap, handler, errHandler) {
			var map = dataMap instanceof Map ? dataMap : new Map();
			if (!(dataMap instanceof Map) && isObject(dataMap)) {
				Object.keys(dataMap).forEach(function(key) {
					map.set(key, dataMap[key]);
				});
			}

			var env = softPhoneConfig.hostEnvironment;
			if (env === "modl") {
				env = "model";
			} else if (env === "training") {
				env = "test";
			}

			if (env !== "prod") {
				map.set(PROXYCONST.CALLVARIABLES.CALLVARIABLE8, env);
			}

			return _updateCallData(
				MainDialog,
				map,
				function() {
					softPhoneConfig.transferToSurvey = toAddress;
					_directTransferCall(
						MainDialog,
						softPhoneConfig._extension,
						toAddress,
						handler,
						errHandler
					);
				},
				errHandler
			);
		};

		var updateConsultCallData = function(handler, errHandler) {
			var callData = softPhoneConfig.callData;
			var dataMap = {};
			if (isDefined(callData)) {
				dataMap = ctiDataService.pack(callData.ecc);
			}

			return _updateCallData(
				ConsultDialog,
				dataMap,
				handler,
				errHandler
			);
		};

		var endConsultCall = function(handler, errHandler) {
			return _dropCall(
				ConsultDialog,
				softPhoneConfig._extension,
				function() {
					if (softPhoneConfig.mainCallState.state === "HELD") {
						retrieveMainCall(handler, errHandler);
					} else {
						_invokeHandler(handler);
					}
				},
				errHandler
			);
		};

		SoftPhoneDataOp.makeSurveyTransfer = function() {
			var args = Array.prototype.slice.call(arguments);
			if (args.length < 1) {
				throw new Error('Too few parameters to this function, refer to doc for more instructions');
			}
			if (args.length > 4) {
				throw new Error('Too many parameters to this function, refer to doc for more instructions');
			}

			checkParameters(args.slice(0, 1));
			if (args[1] !== null && !isObject(args[1])) {
				throw new Error('Second parameter has to be a valid object');
			}

			var transferHandler = defaultHandler;
			var transferErrHandler = SoftPhoneDataOp._errorHandler;
			if (args.length > 2 && isFunction(args[2])) {
				transferHandler = args[2];
			}
			if (args.length === 4 && isFunction(args[3])) {
				transferErrHandler = args[3];
			}

			makeSurveyTransfer(args[0], args[1], transferHandler, transferErrHandler);
		};

		SoftPhoneDataOp.transferMainCall = function(handler, errHandler) {
				return _requestDialogAction(MainDialog, 'TRANSFER', "transfering main call", handler, errHandler);
        };

		SoftPhoneDataOp.conferenceMainCall = function(handler, errHandler) {
				return _requestDialogAction(MainDialog, 'CONFERENCE', "conferencing main call", handler, errHandler);
        };

		SoftPhoneDataOp.updateMainCallData = function(handler, errHandler) {
            updateMainCallData(handler, errHandler);
        };

		SoftPhoneDataOp.updateMainCallWrapup = function(wrapUpReason, handler, errHandler) {
				updateMainCallWrapup(wrapUpReason, handler, errHandler);
        };
		

		SoftPhoneDataOp.updateMainCallDataAndWrapup = function(wrapUpReason, handler, errHandler) {
				updateMainCallData(handler, errHandler);
				updateMainCallWrapup(wrapUpReason, handler, errHandler);
        };

		SoftPhoneDataOp.updateConsultCallData = function(handler, errHandler) {
			return updateConsultCallData(handler, errHandler);
        };

		SoftPhoneDataOp.retrieveConsultCall = function(handler, errHandler) {
				return retrieveConsultCall(handler, errHandler);
        };

		SoftPhoneDataOp.endConsultCall = function(handler, errHandler) {
            return endConsultCall(handler, errHandler);
        };

		function _resolveDtmfDialog(dialogType) {
			var normalizedType = String(dialogType || 'main').toLowerCase();
			if (normalizedType === 'consult') {
				return ConsultDialog;
			}

			return MainDialog;
		}

		SoftPhoneDataOp._canSendDTMF = function(dialogType) {
			var dialogObj = _resolveDtmfDialog(dialogType);
			return !!(dialogObj && isFunction(dialogObj.sendDTMFRequest));
		};

		SoftPhoneDataOp._sendDTMF = function(digit, handler, errHandler, dialogType) {
			var dialogObj = _resolveDtmfDialog(dialogType);
			var targetLabel = String(dialogType || 'main').toLowerCase() === 'consult' ? 'consult call' : 'main call';

			if (!dialogObj || !isFunction(dialogObj.sendDTMFRequest)) {
				_invokeHandler(_handleFinesseError('sending dtmf code:' + digit + ' to ' + targetLabel, errHandler), {
					status: 0,
					object: { ApiErrors: { ApiError: { ErrorType: 'DialogUnavailable', ErrorMessage: 'No dialog is available for sending DTMF.' } } },
				});
				return;
			}

			dialogObj.sendDTMFRequest(
				User.getExtension(),
				_handlers(handler, _handleFinesseError('sending dtmf code:' + digit + ' to ' + targetLabel, errHandler)),
				digit
			);
		};
		
		SoftPhoneDataOp._createErrorHandler = function() {
            return _createErrorHandler(arguments[0]);
        };
        SoftPhoneDataOp.init = function() {
            init();
        };

        // return value
		global.PROXYCONST = PROXYCONST;
		global.softPhoneConfig = softPhoneConfig;
		global.softPhoneCoreService = SoftPhoneDataOp;
		global.finesse.gadget.softPhoneCoreService = SoftPhoneDataOp;
})(window);