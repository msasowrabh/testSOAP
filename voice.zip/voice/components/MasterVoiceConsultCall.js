// Master Voice Consult Call Component
window.registerVoiceComponent('master-voice-consult-call', {
	template: `
		<div class="master-voice-consult-call" v-show="isVisible" :class="{ 'is-disabled': isConsultOnHold }" :inert="isConsultOnHold ? '' : null" :aria-disabled="isConsultOnHold ? 'true' : 'false'">
			<div class="consult-call-container" :class="consultBorderClass">
				<div class="consult-call-header">
					<div class="consult-call-title">In consult with:</div>
				</div>
				<div class="consult-call-body">
					<div class="consult-call-status-row">
						<span class="main-call-direction-badge" :class="consultDirectionClass">
						<svg v-if="consultDirectionClass === 'is-consult-active'" width="12" height="12" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
							<path d="M12.6667 8.66699C12.6667 8.49018 12.5964 8.32066 12.4714 8.19564C12.3463 8.07061 12.1768 8.00033 12 8.00033H11.3333C11.1565 8.00033 10.987 8.07061 10.862 8.19564C10.737 8.32066 10.6667 8.49018 10.6667 8.66699V10.667C10.6667 10.8438 10.737 11.0133 10.862 11.1383C10.987 11.2634 11.1565 11.3337 11.3333 11.3337H12C12.1768 11.3337 12.3463 11.2634 12.4714 11.1383C12.5808 11.0289 12.6483 10.8854 12.6634 10.7327L12.6667 10.667V8.66699ZM5.33333 8.66699C5.33333 8.49018 5.26305 8.32066 5.13802 8.19564C5.013 8.07061 4.84348 8.00033 4.66667 8.00033H4C3.82319 8.00033 3.65367 8.07061 3.52865 8.19564C3.40362 8.32066 3.33333 8.49018 3.33333 8.66699V10.667L3.33659 10.7327C3.35172 10.8854 3.41922 11.0289 3.52865 11.1383C3.65367 11.2634 3.82319 11.3337 4 11.3337H4.66667C4.84348 11.3337 5.013 11.2634 5.13802 11.1383C5.26305 11.0133 5.33333 10.8438 5.33333 10.667V8.66699ZM14 10.667C14 11.1974 13.7891 11.706 13.4141 12.0811C13.1749 12.3202 12.8813 12.4915 12.5625 12.585C12.3321 13.2246 11.7456 13.7013 11.127 14.0107C10.3445 14.402 9.32294 14.6366 8.22135 14.6644L8 14.667L7.93164 14.6637C7.59555 14.6295 7.33333 14.3454 7.33333 14.0003C7.33333 13.6321 7.63181 13.3337 8 13.3337L8.3776 13.3239C9.24273 13.2797 9.99419 13.0862 10.5306 12.818C10.6683 12.7492 10.7833 12.6797 10.8796 12.6123C10.519 12.5282 10.1853 12.3471 9.91927 12.0811C9.5442 11.706 9.33333 11.1974 9.33333 10.667V8.66699C9.33333 8.13656 9.5442 7.628 9.91927 7.25293C10.2943 6.87786 10.8029 6.66699 11.3333 6.66699H12C12.2295 6.66699 12.4543 6.70837 12.6667 6.78353V6.66699C12.6667 5.42932 12.1753 4.24203 11.3001 3.36686C10.425 2.49169 9.23768 2.00033 8 2.00033C6.76232 2.00033 5.57504 2.49169 4.69987 3.36686C3.8247 4.24203 3.33333 5.42932 3.33333 6.66699V6.78353C3.54567 6.70837 3.77046 6.66699 4 6.66699H4.66667C5.1971 6.66699 5.70566 6.87786 6.08073 7.25293C6.4558 7.628 6.66667 8.13656 6.66667 8.66699V10.667C6.66667 11.1974 6.4558 11.706 6.08073 12.0811C5.70566 12.4561 5.1971 12.667 4.66667 12.667H4C3.46957 12.667 2.96101 12.4561 2.58594 12.0811C2.21086 11.706 2 11.1974 2 10.667V6.66699C2 5.07569 2.63194 3.54937 3.75716 2.42415C4.88238 1.29894 6.4087 0.666992 8 0.666992C9.5913 0.666992 11.1176 1.29894 12.2428 2.42415C13.3681 3.54937 14 5.07569 14 6.66699V10.667Z" fill="white"/>
						</svg>
						<svg v-else-if="consultDirectionClass === 'is-held'" width="12" height="12" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
							<path fill-rule="evenodd" clip-rule="evenodd" d="M3.99967 2C3.63148 2 3.33301 2.29848 3.33301 2.66667V13.3333C3.33301 13.7015 3.63148 14 3.99967 14H6.66634C7.03453 14 7.33301 13.7015 7.33301 13.3333V2.66667C7.33301 2.29848 7.03453 2 6.66634 2H3.99967ZM4.66634 12.6667V3.33333H5.99967V12.6667H4.66634Z" fill="white"/>
							<path fill-rule="evenodd" clip-rule="evenodd" d="M9.33301 2C8.96482 2 8.66634 2.29848 8.66634 2.66667V13.3333C8.66634 13.7015 8.96482 14 9.33301 14H11.9997C12.3679 14 12.6663 13.7015 12.6663 13.3333V2.66667C12.6663 2.29848 12.3679 2 11.9997 2H9.33301ZM9.99967 12.6667V3.33333H11.333V12.6667H9.99967Z" fill="white"/>
						</svg>
						</span>
						<span class="consult-call-timer">{{ consultTimerText }}</span>
						<span class="main-call-status-separator" aria-hidden="true"></span>
						<span class="consult-call-party">{{ consultParty || 'N/A' }}</span>
						<span v-if="isConsultOnHold" class="main-call-status-separator" aria-hidden="true"></span>
						<span v-if="isConsultOnHold" class="main-call-hold-bubble" :class="consultHoldBubbleClass">
							<span>On hold</span>
							<span class="main-call-hold-bubble-separator" aria-hidden="true"></span>
							<span>{{ consultHoldTimerText }}</span>
						</span>
					</div>
					<div class="call-controls main-call-actions consult-call-actions">
						<hold-button :is-on-hold="isConsultOnHold" :disabled="!isConsultHoldEnabled" @toggle="onConsultHoldToggle"></hold-button>
						<dtmf-dialpad-button dialog-scope="consult"></dtmf-dialpad-button>
						<span class="dial-inline-separator" aria-hidden="true"></span>
						<button type="button" class="consult-cancel-button" :class="{ 'is-consult-active': isConsultActive }" @click="onConsultCancel">
							<svg v-if="isConsultActive" class="consult-action-icon" width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg" aria-hidden="true">
								<circle cx="8" cy="8" r="6" stroke="currentColor" stroke-width="1.5"/>
								<path d="M5.75 5.75L10.25 10.25M10.25 5.75L5.75 10.25" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"/>
							</svg>
							<span>Cancel</span>
						</button>
						<button type="button" class="consult-complete-button" :class="{ 'is-consult-active': isConsultActive }" @click="onConsultComplete">
							<svg v-if="isConsultActive" class="consult-action-icon" width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg" aria-hidden="true">
								<path d="M15.8334 0.833008L19.1668 4.16634M19.1668 4.16634L15.8334 7.49967M19.1668 4.16634H12.5001M18.3334 14.0997V16.5997C18.3344 16.8318 18.2868 17.0615 18.1939 17.2741C18.1009 17.4868 17.9645 17.6777 17.7935 17.8346C17.6225 17.9915 17.4206 18.1109 17.2007 18.1853C16.9809 18.2596 16.7479 18.2872 16.5168 18.2663C13.9525 17.9877 11.4893 17.1115 9.32511 15.708C7.31163 14.4286 5.60455 12.7215 4.32511 10.708C2.91676 8.53401 2.04031 6.05884 1.76677 3.48301C1.74595 3.25256 1.77334 3.02031 1.84719 2.80103C1.92105 2.58175 2.03975 2.38025 2.19575 2.20936C2.35174 2.03847 2.54161 1.90193 2.75327 1.80844C2.96492 1.71495 3.19372 1.66656 3.42511 1.66634H5.92511C6.32953 1.66236 6.7216 1.80557 7.02824 2.06929C7.33488 2.333 7.53517 2.69921 7.59177 3.09967C7.69729 3.89973 7.89298 4.68528 8.17511 5.44134C8.28723 5.73961 8.31149 6.06377 8.24503 6.37541C8.17857 6.68705 8.02416 6.9731 7.80011 7.19967L6.74177 8.25801C7.92807 10.3443 9.65549 12.0717 11.7418 13.258L12.8001 12.1997C13.0267 11.9756 13.3127 11.8212 13.6244 11.7548C13.936 11.6883 14.2602 11.7126 14.5584 11.8247C15.3145 12.1068 16.1001 12.3025 16.9001 12.408C17.3049 12.4651 17.6746 12.669 17.9389 12.9809C18.2032 13.2928 18.3436 13.691 18.3334 14.0997Z" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
							</svg>
							<span>{{ completeActionLabel }}</span>
						</button>
					</div>
				</div>
			</div>
		</div>
	`,
	data: function() {
		return {
			isVisible: false,
			consultState: '',
			consultParty: null,
			consultRequestType: 'transfer',
			consultCallState: {},
			consultTimerText: '00:00:00',
			consultStartedAtMs: null,
			consultHoldStartedAtMs: null,
			consultHoldTimerText: '00:00',
			consultHoldExceededThreshold: false,
			lastTimerTickMs: null,
			previousConsultState: null
		};
	},
	computed: {
		isConsultActive: function() {
			return this.consultState === 'ACTIVE';
		},
		isConsultOnHold: function() {
			return this.consultState === 'HELD';
		},
		isConsultHoldEnabled: function() {
			return this.consultState === 'ACTIVE' || this.consultState === 'HELD';
		},
		completeActionLabel: function() {
			return this.consultRequestType === 'conference' ? 'Group Conference' : 'Complete transfer';
		},
		consultDirectionIcon: function() {
			return this.consultCallState && this.consultCallState.direction === 'OUT' ? 'outbound-call' : 'inbound-call';
		},
		consultDirectionClass: function() {
			if (this.consultState === 'ACTIVE') {
				return 'is-consult-active';
			}
			if (this.consultState === 'HELD') {
				return 'is-held';
			}
			if (this.consultState === 'FAILED') {
				return 'is-failed';
			}
			return 'is-default';
		},
		consultHoldBubbleClass: function() {
			return this.consultHoldExceededThreshold ? 'is-critical' : 'is-default';
		},
		consultBorderClass: function() {
			if (this.consultState === 'ACTIVE') {
				return 'call-border-consult-active';
			}
			if (this.consultState === 'HELD') {
				return 'call-border-held';
			}
			if (this.consultState === 'FAILED') {
				return 'call-border-failed';
			}
			return '';
		}
	},
	methods: {
		pad2: function(value) {
			return value < 10 ? '0' + value : String(value);
		},
		resolveDialLabel: function(number) {
			var targetNumber = String(number || '').trim();
			if (!targetNumber) {
				return '';
			}

			var businessConfig = (window.softPhoneConfig && window.softPhoneConfig.businessConfiguration) || {};
			var phonebook = Array.isArray(businessConfig.phonebook) ? businessConfig.phonebook : [];
			for (var i = 0; i < phonebook.length; i++) {
				var entry = phonebook[i] || {};
				if (String(entry.phoneNumber || '').trim() === targetNumber) {
					return entry.name || targetNumber;
				}
			}

			return targetNumber;
		},
		resolveConsultParty: function() {
			var consultState = this.consultCallState || (window.softPhoneConfig && window.softPhoneConfig.consultCallState) || {};
			var extension = (window.softPhoneConfig && window.softPhoneConfig._extension) || '';
			var from = consultState.from || '';
			var to = consultState.to || '';
			var dialedNumber = consultState.dialedNumber || '';

			if (to && to !== extension) {
				return this.resolveDialLabel(to);
			}
			if (from && from !== extension) {
				return this.resolveDialLabel(from);
			}
			if (dialedNumber && dialedNumber !== extension) {
				return this.resolveDialLabel(dialedNumber);
			}
			return this.resolveDialLabel(to || from || dialedNumber || '');
		},
		updateConsultTimerText: function(nowMs) {
			if (!this.consultStartedAtMs) {
				this.consultTimerText = '00:00:00';
				return;
			}

			var elapsedMs = Math.max(0, (nowMs || Date.now()) - this.consultStartedAtMs);
			var totalSeconds = Math.floor(elapsedMs / 1000);
			var hours = Math.floor(totalSeconds / 3600);
			var minutes = Math.floor((totalSeconds % 3600) / 60);
			var seconds = totalSeconds % 60;
			this.consultTimerText = this.pad2(hours) + ':' + this.pad2(minutes) + ':' + this.pad2(seconds);
		},
		updateConsultHoldTimerText: function(nowMs) {
			if (!this.consultHoldStartedAtMs) {
				this.consultHoldTimerText = '00:00';
				this.consultHoldExceededThreshold = false;
				return;
			}

			var elapsedMs = Math.max(0, (nowMs || Date.now()) - this.consultHoldStartedAtMs);
			var totalSeconds = Math.floor(elapsedMs / 1000);
			var minutes = Math.floor(totalSeconds / 60);
			var seconds = totalSeconds % 60;
			this.consultHoldTimerText = this.pad2(minutes) + ':' + this.pad2(seconds);
			this.consultHoldExceededThreshold = totalSeconds >= 45;
		},
		handleTimerTick: function(timerTickMs) {
			if (typeof timerTickMs === 'number' && !isNaN(timerTickMs)) {
				this.lastTimerTickMs = timerTickMs;
				if (this.isVisible && (this.consultState === 'ACTIVE' || this.consultState === 'HELD')) {
					this.updateConsultTimerText(timerTickMs);
				}
				if (this.consultState === 'HELD') {
					this.updateConsultHoldTimerText(timerTickMs);
				}
			}
		},
		resolveConsultRequestType: function() {
			var dialNewCall = window.masterVoiceApp && window.masterVoiceApp.$refs ? window.masterVoiceApp.$refs.dialNewCall : null;
			var dialState = dialNewCall && dialNewCall.state ? String(dialNewCall.state).toLowerCase() : '';
			if (dialState === 'conference' || dialState === 'transfer') {
				return dialState;
			}
			var mainCallType = (window.softPhoneConfig && window.softPhoneConfig.mainCallState && window.softPhoneConfig.mainCallState.callType) || '';
			if (String(mainCallType).toUpperCase() === 'CONFERENCE') {
				return 'conference';
			}
			return 'transfer';
		},
		handleConsultCallChange: function() {
			var rawConsultState = (window.softPhoneConfig && window.softPhoneConfig.consultCallState) || {};
			this.consultCallState = Object.assign({}, rawConsultState);
			var consultState = this.consultCallState.state || '';
			var normalizedState = String(consultState).toUpperCase();
			var nowMs = this.lastTimerTickMs || Date.now();
			this.consultState = normalizedState;
			this.consultParty = this.resolveConsultParty();
			this.consultRequestType = this.resolveConsultRequestType();
			if ((normalizedState === 'ACTIVE' || normalizedState === 'HELD') && (this.previousConsultState !== 'ACTIVE' && this.previousConsultState !== 'HELD')) {
				this.consultStartedAtMs = nowMs;
				this.consultTimerText = '00:00:00';
			}

			if (normalizedState === 'HELD' && this.previousConsultState !== 'HELD') {
				this.consultHoldStartedAtMs = nowMs;
				this.consultHoldTimerText = '00:00';
				this.consultHoldExceededThreshold = false;
			}

			if (normalizedState !== 'HELD' && this.previousConsultState === 'HELD') {
				this.consultHoldStartedAtMs = null;
				this.consultHoldTimerText = '00:00';
				this.consultHoldExceededThreshold = false;
			}

			if (normalizedState !== 'ACTIVE' && normalizedState !== 'HELD') {
				this.consultStartedAtMs = null;
				this.consultTimerText = '00:00:00';
				this.consultHoldStartedAtMs = null;
				this.consultHoldTimerText = '00:00';
				this.consultHoldExceededThreshold = false;
			}

			this.updateConsultTimerText(nowMs);
			this.updateConsultHoldTimerText(nowMs);
			this.previousConsultState = normalizedState;
			if (normalizedState === 'ACTIVE' || normalizedState === 'HELD') {
				this.showConsultCall();
			} else {
				this.hideConsultCall();
			}
		},
		showConsultCall: function() {
			this.isVisible = true;
		},
		hideConsultCall: function() {
			this.isVisible = false;
		},
		onConsultHoldToggle: function() {
			if (!window.softPhoneCoreService) {
				return;
			}
			if (this.consultState === 'HELD') {
				if (typeof window.softPhoneCoreService.retrieveConsultCall === 'function') {
					window.softPhoneCoreService.retrieveConsultCall();
				}
				return;
			}
			if (typeof window.softPhoneCoreService.holdConsultCall === 'function') {
				window.softPhoneCoreService.holdConsultCall();
			}
		},
		onConsultCancel: function() {
			if (window.softPhoneCoreService && typeof window.softPhoneCoreService.endConsultCall === 'function') {
				window.softPhoneCoreService.endConsultCall();
			}
		},
		onConsultComplete: function() {
			if (!window.softPhoneCoreService) {
				return;
			}
			if (this.consultRequestType === 'conference') {
				var conferenceConfig = window.softPhoneConfig || {};
				if (typeof conferenceConfig.joinHook === 'function') {
					conferenceConfig.joinHook();
					return;
				}
				if (typeof window.softPhoneCoreService.conferenceMainCall === 'function') {
					window.softPhoneCoreService.conferenceMainCall();
				}
				return;
			}
			var config = window.softPhoneConfig || {};
			if (typeof config.transferHook === 'function') {
				config.transferHook();
				return;
			}
			if (config.callData && config.callData.ecc) {
				config.callData.ecc.transferFlag = 'Y';
			}
			if (typeof window.softPhoneCoreService.transferMainCall === 'function') {
				window.softPhoneCoreService.transferMainCall();
			}
		}
	},
	mounted: function() {
		this.lastTimerTickMs = Date.now();
		if (window.masterVoiceEvents) {
			var eventName = (window.PROXYCONST && window.PROXYCONST.EVENT_TYPE_CONSULT_CALL_CHANGE) || 'CONSULT_CALL_CHANGE';
			var timerTickEvent = (window.PROXYCONST && window.PROXYCONST.EVENT_TIMER_TICK) || 'EVENT_TIMER_TICK';
			var self = this;
			this._consultChangeHandler = function(payload) {
				self.handleConsultCallChange(payload);
			};
			this._consultTimerTickHandler = function(payload) {
				self.handleTimerTick(payload);
			};
			this._unsubConsultCallChange = window.masterVoiceEvents.on(eventName, this._consultChangeHandler);
			this._unsubConsultTimerTick = window.masterVoiceEvents.on(timerTickEvent, this._consultTimerTickHandler);
		}
		this.handleConsultCallChange();
	},
	beforeUnmount: function() {
		if (this._unsubConsultCallChange) {
			this._unsubConsultCallChange();
		}
		if (this._unsubConsultTimerTick) {
			this._unsubConsultTimerTick();
		}
	}
});
