// Master Voice Call Data Component
window.registerVoiceComponent('master-voice-call-data', {
	template: `
		<div class="master-voice-call-data">
			<div class="call-data-container">
				<component v-if="newDataComponent" :is="newDataComponent" :state="state" :auth-status="authStatus" :call-disposition-list="callDispositionList"></component>
				<div v-else class="call-data-body">
					<p class="call-data-empty-text">{{ $t('callData.loadingTemplate') }}</p>
				</div>
			</div>
		</div>
	`,
	data: function() {
		return {
			isVisible: true,
			state: 'no-data',
			callHistory: [],
			callDispositionList: [],
			authStatus: '',
			newDataComponent: null,
			newDataTemplatePath: '/custom/views/voice-call-data.html'
		};
	},
	watch: {
		state: function(newState) {
			if (newState === 'new-data' && !this.newDataComponent) {
				this.loadNewDataTemplate();
			}
		}
	},
	methods: {
		toRawComponent: function(componentDefinition) {
			if (window.Vue && typeof window.Vue.markRaw === 'function') {
				return window.Vue.markRaw(componentDefinition);
			}
			return componentDefinition;
		},
		resolveTemplateUrl: function() {
			if (/^https?:\/\//i.test(this.newDataTemplatePath)) {
				return this.newDataTemplatePath;
			}

			var baseUrl = window.masterVoiceBaseUrl || '';
			if (!baseUrl) {
				return this.newDataTemplatePath;
			}

			if (this.newDataTemplatePath.charAt(0) === '/') {
				return baseUrl + this.newDataTemplatePath;
			}

			return baseUrl + '/' + this.newDataTemplatePath;
		},
		ensureCustomCallDataStylesheet: function() {
			if (typeof document === 'undefined') {
				return;
			}

			var href = '/custom/styles/voice-call-data.css';
			if (window.masterVoiceBaseUrl) {
				href = window.masterVoiceBaseUrl + href;
			}

			if (document.querySelector('link[data-master-voice-call-data-style="true"]')) {
				return;
			}

			var link = document.createElement('link');
			link.rel = 'stylesheet';
			link.href = href;
			link.setAttribute('data-master-voice-call-data-style', 'true');
			document.head.appendChild(link);
		},
		setState: function(newState) {
			this.state = newState || 'no-data';
			if (this.state === 'new-data') {
				this.$nextTick(function() {
					this.emitCallDataRefresh();
				}.bind(this));
			}
		},
		emitCallDataRefresh: function() {
			if (!window.masterVoiceEvents) {
				return;
			}
			var eventName = (window.PROXYCONST && window.PROXYCONST.EVENT_TYPE_CALL_DATA_CHANGE) || 'CALL_DATA_CHANGE';
			window.masterVoiceEvents.emit(eventName, { source: 'call-data-display' });
		},
		showCallData: function() {
			this.isVisible = true;
			if (this.state === 'new-data') {
				this.$nextTick(function() {
					this.emitCallDataRefresh();
				}.bind(this));
			}
		},
		hideCallData: function() {
			this.isVisible = false;
		},
		loadNewDataTemplate: function() {
			var unableLoadText = '';
			if (this.$t && typeof this.$t === 'function') {
				unableLoadText = this.$t('callData.unableLoadTemplate');
			}
			var unableLoadTemplate = '<p class="call-data-empty-text">' + unableLoadText + '</p>';

			if (this.newDataComponent) {
				return;
			}

			if (typeof window.fetch !== 'function') {
				this.newDataComponent = this.toRawComponent({
					template: unableLoadTemplate
				});
				return;
			}

			var templateUrl = this.resolveTemplateUrl();
			this.ensureCustomCallDataStylesheet();

			window.fetch(templateUrl)
				.then(function(response) {
					if (!response.ok) {
						throw new Error('Failed to load template: ' + response.status);
					}
					return response.text();
				})
				.then(function(html) {
					if (!html || !String(html).trim()) {
						throw new Error('Call data template is empty');
					}
					this.newDataComponent = this.toRawComponent({
						template: html,
						props: {
							state: {
								type: String,
								default: 'no-data'
							},
							authStatus: {
								type: String,
								default: ''
							},
							callDispositionList: {
								type: Array,
								default: function() {
									return [];
								}
							}
						}
					});
				}.bind(this))
				.catch(function() {
					this.newDataComponent = this.toRawComponent({
						template: unableLoadTemplate
					});
				}.bind(this));
		},
		updateBusinessConfiguration: function(config) {
			var businessConfiguration = config || (window.softPhoneConfig && window.softPhoneConfig.businessConfiguration) || {};
			var callDisposition = businessConfiguration.callDisposition;
			this.callDispositionList = Array.isArray(callDisposition)
				? callDisposition.map(function(item) {
					return item && item.description ? item.description : '';
				}).filter(function(item) {
					return item !== '';
				})
				: [];
		},
		updateCallDataState: function() {
			var callData = window.softPhoneConfig && window.softPhoneConfig.callData;
			this.authStatus = callData && callData.ecc && callData.ecc.identityVerified ? String(callData.ecc.identityVerified) : '';
		},
		handleVisibilityEvent: function(payload) {
			if (payload && payload.visible === false) {
				this.hideCallData();
				return;
			}

			this.showCallData();
		},
		handleMainCallStateChanged: function(payload) {
			var rawState = (payload && payload.state) || '';
			var normalizedState = String(rawState).toUpperCase();

			// TODO: Remove testing-only state mapping once call-data is updated by real backend payloads.
			if (normalizedState === 'ACTIVE' || normalizedState === 'HELD' || normalizedState === 'WRAP_UP' || normalizedState === 'ALERTING') {
				this.setState('new-data');
				return;
			}

			this.setState('no-data');
		}
	},
	mounted: function() {
		if (window.masterVoiceEvents) {
			this._unsubVisibility = window.masterVoiceEvents.on('master-voice-call-data-visibility', this.handleVisibilityEvent);
			this._unsubCallState = window.masterVoiceEvents.on('master-voice-main-call-state-changed', this.handleMainCallStateChanged);
			this._unsubBusinessConfig = window.masterVoiceEvents.on('BUSINESS_CONFIG_CHANGE', this.updateBusinessConfiguration);
			var callDataEvent = (window.PROXYCONST && window.PROXYCONST.EVENT_TYPE_CALL_DATA_CHANGE) || 'CALL_DATA_CHANGE';
			this._unsubCallData = window.masterVoiceEvents.on(callDataEvent, this.updateCallDataState);
		}
		this.updateBusinessConfiguration();
		this.updateCallDataState();
		// Preload once on app startup so template is cached before first call-data render.
		this.loadNewDataTemplate();
	},
	beforeUnmount: function() {
		if (this._unsubVisibility) { this._unsubVisibility(); }
		if (this._unsubCallState) { this._unsubCallState(); }
		if (this._unsubBusinessConfig) { this._unsubBusinessConfig(); }
		if (this._unsubCallData) { this._unsubCallData(); }
	}
});
