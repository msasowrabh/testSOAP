// Main Call composition components used by voice.jsp tags
window.registerVoiceComponent('caller-name', {
	data: function() {
		return {
			name: ''
		};
	},
	methods: {
		translate: function(key) {
			var i18n = window.masterVoiceI18n;
			if (i18n && i18n.global && typeof i18n.global.t === 'function') {
				return i18n.global.t(key);
			}
			return '';
		},
		updateCallerName: function() {
			var callState = (window.softPhoneConfig && window.softPhoneConfig.mainCallState) || {};
			var customerHook = window.softPhoneConfig && window.softPhoneConfig.customerHook;
			var customerName = '';
			var direction = String(callState.direction || '').toUpperCase();
			if (typeof customerHook === 'function') {
				try {
					customerName = customerHook(callState);
				} catch (error) {
					customerName = '';
				}
			}
			this.name = direction === 'OUT'
				? this.translate('mainCall.outboundCall')
				: (customerName ? String(customerName) : this.translate('mainCall.customer'));
		}
	},
	mounted: function() {
		this.updateCallerName();
		if (window.masterVoiceEvents) {
			var mainCallEvent = (window.PROXYCONST && window.PROXYCONST.EVENT_TYPE_MAIN_CALL_CHANGE) || 'MAIN_CALL_CHANGE';
			this._unsubMainCallChange = window.masterVoiceEvents.on(mainCallEvent, this.updateCallerName);
		}
	},
	beforeUnmount: function() {
		if (this._unsubMainCallChange) {
			this._unsubMainCallChange();
		}
	},
	template: '<span class="main-call-customer-label">{{ name }}</span>'
});

window.registerVoiceComponent('call-status', {
	data: function() {
		return {
			mainCallState: {},
			lastTimerTickMs: null,
			timerText: '00:00:00',
			holdTimerText: '00:00',
			holdStartedAtMs: null,
			holdExceededThreshold: false,
			previousMainCallState: null
		};
	},
	computed: {
		directionIcon: function() {
			return this.mainCallState.direction === 'OUT' ? 'outbound-call' : 'inbound-call';
		},
		directionClass: function() {
			var state = this.mainCallState.state;
			if (state === 'ACTIVE') {
				return this.isConferenceState ? 'is-active-conference' : 'is-active';
			}
			if (state === 'HELD') {
				return 'is-held';
			}
			if (state === 'FAILED') {
				return 'is-failed';
			}
			return 'is-default';
		},
		participantCount: function() {
			var participants = this.mainCallState && this.mainCallState.participants;
			var extension = window.softPhoneConfig && window.softPhoneConfig._extension;
			var list = [];
			if (Array.isArray(participants)) {
				participants.forEach(function(p) {
					if (p && p.mediaAddress && p.mediaAddress !== extension) list.push(p.mediaAddress);
				});
			} else if (participants && participants.mediaAddress && participants.mediaAddress !== extension) {
				list.push(participants.mediaAddress);
			}
			return new Set(list).size;
		},
		isConferenceState: function() {
			return this.mainCallState && this.mainCallState.state === 'ACTIVE' && this.participantCount >= 2;
		},
		participantsText: function() {
			var participants = this.mainCallState && this.mainCallState.participants;
			var parties = this.mainCallState && this.mainCallState.parties;
			var extension = window.softPhoneConfig && window.softPhoneConfig._extension;
			var list = [];

			if (Array.isArray(participants)) {
				participants.forEach(function(participant) {
					if (participant && participant.mediaAddress && participant.mediaAddress !== extension) {
						list.push(participant.mediaAddress);
					}
				});
			} else if (participants && participants.mediaAddress && participants.mediaAddress !== extension) {
				list.push(participants.mediaAddress);
			}

			if (list.length === 0 && typeof parties === 'string' && parties.trim()) {
				parties.split(' - ').forEach(function(address) {
					var normalized = String(address || '').trim();
					if (normalized && normalized !== extension) {
						list.push(normalized);
					}
				});
			}

			return Array.from(new Set(list)).join(', ') || '--';
		},
		isOnHoldState: function() {
			return this.mainCallState && this.mainCallState.state === 'HELD';
		},
		holdBubbleClass: function() {
			return this.holdExceededThreshold ? 'is-critical' : 'is-default';
		}
	},
	methods: {
		pad2: function(value) {
			return value < 10 ? '0' + value : String(value);
		},
		getStartTimeMs: function() {
			var startTime = this.mainCallState && this.mainCallState.startTime;
			if (!startTime) {
				return null;
			}

			if (typeof startTime === 'number' && !isNaN(startTime)) {
				return startTime;
			}

			if (/^\d+$/.test(String(startTime))) {
				var numericStart = parseInt(startTime, 10);
				return String(startTime).length <= 10 ? (numericStart * 1000) : numericStart;
			}

			var parsed = Date.parse(startTime);
			return isNaN(parsed) ? null : parsed;
		},
		updateTimerText: function(nowMs) {
			var startMs = this.getStartTimeMs();
			if (!startMs) {
				this.timerText = '00:00:00';
				return;
			}

			var elapsedMs = Math.max(0, (nowMs || Date.now()) - startMs);
			var totalSeconds = Math.floor(elapsedMs / 1000);
			var hours = Math.floor(totalSeconds / 3600);
			var minutes = Math.floor((totalSeconds % 3600) / 60);
			var seconds = totalSeconds % 60;
			this.timerText = this.pad2(hours) + ':' + this.pad2(minutes) + ':' + this.pad2(seconds);
		},
		updateHoldTimerText: function(nowMs) {
			if (!this.holdStartedAtMs) {
				this.holdTimerText = '00:00';
				this.holdExceededThreshold = false;
				return;
			}

			var elapsedMs = Math.max(0, (nowMs || Date.now()) - this.holdStartedAtMs);
			var totalSeconds = Math.floor(elapsedMs / 1000);
			var minutes = Math.floor(totalSeconds / 60);
			var seconds = totalSeconds % 60;
			this.holdTimerText = this.pad2(minutes) + ':' + this.pad2(seconds);
			this.holdExceededThreshold = totalSeconds >= 45;
		},
		handleMainCallChange: function() {
			var rawState = (window.softPhoneConfig && window.softPhoneConfig.mainCallState) || {};
			var rawParticipants = rawState.participants;
			var participantsSnapshot = rawParticipants;

			if (Array.isArray(rawParticipants)) {
				participantsSnapshot = rawParticipants.map(function(participant) {
					if (!participant || typeof participant !== 'object') {
						return participant;
					}
					return {
						mediaAddress: participant.mediaAddress,
						state: participant.state
					};
				});
			} else if (rawParticipants && typeof rawParticipants === 'object') {
				participantsSnapshot = {
					mediaAddress: rawParticipants.mediaAddress,
					state: rawParticipants.state
				};
			}

			this.mainCallState = Object.assign({}, rawState, {
				participants: participantsSnapshot
			});

			var currentState = this.mainCallState && this.mainCallState.state;
			if (currentState === 'HELD' && this.previousMainCallState !== 'HELD') {
				this.holdStartedAtMs = this.lastTimerTickMs || Date.now();
				this.holdTimerText = '00:00';
				this.holdExceededThreshold = false;
			}

			if (currentState !== 'HELD' && this.previousMainCallState === 'HELD') {
				this.holdStartedAtMs = null;
				this.holdTimerText = '00:00';
				this.holdExceededThreshold = false;
			}

			this.previousMainCallState = currentState || null;
			this.updateTimerText(this.lastTimerTickMs || Date.now());
			this.updateHoldTimerText(this.lastTimerTickMs || Date.now());
		},
		handleTimerTick: function(timerTickMs) {
			if (typeof timerTickMs === 'number' && !isNaN(timerTickMs)) {
				this.lastTimerTickMs = timerTickMs;
				this.updateTimerText(timerTickMs);
				if (this.mainCallState && this.mainCallState.state === 'HELD') {
					this.updateHoldTimerText(timerTickMs);
				}
			}
		}
	},
	mounted: function() {
		this.handleMainCallChange();
		this.lastTimerTickMs = Date.now();
		this.updateTimerText(this.lastTimerTickMs);
		if (window.masterVoiceEvents) {
			var mainCallEvent = (window.PROXYCONST && window.PROXYCONST.EVENT_TYPE_MAIN_CALL_CHANGE) || 'MAIN_CALL_CHANGE';
			var timerTickEvent = (window.PROXYCONST && window.PROXYCONST.EVENT_TIMER_TICK) || 'EVENT_TIMER_TICK';
			var self = this;
			this._mainCallChangeHandler = function(payload) {
				self.handleMainCallChange(payload);
			};
			this._timerTickHandler = function(payload) {
				self.handleTimerTick(payload);
			};
			this._unsubMainCallChange = window.masterVoiceEvents.on(mainCallEvent, this._mainCallChangeHandler);
			this._unsubTimerTick = window.masterVoiceEvents.on(timerTickEvent, this._timerTickHandler);
		}
	},
	beforeUnmount: function() {
		if (this._unsubMainCallChange) {
			this._unsubMainCallChange();
		}
		if (this._unsubTimerTick) {
			this._unsubTimerTick();
		}
	},
	template: `
		<span class="main-call-status-row">
			<span class="main-call-direction-badge" :class="directionClass">
				<svg v-if="directionClass === 'is-active'" width="12" height="12" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
					<path d="M14.6667 11.2797V13.2797C14.6675 13.4654 14.6294 13.6492 14.555 13.8193C14.4807 13.9894 14.3716 14.1421 14.2348 14.2676C14.0979 14.3932 13.9364 14.4887 13.7605 14.5482C13.5847 14.6077 13.3983 14.6298 13.2134 14.6131C11.1619 14.3902 9.19137 13.6892 7.46004 12.5664C5.84926 11.5428 4.48359 10.1772 3.46004 8.56641C2.33336 6.82721 1.6322 4.84707 1.41337 2.78641C1.39671 2.60205 1.41862 2.41625 1.4777 2.24082C1.53679 2.0654 1.63175 1.9042 1.75655 1.76749C1.88134 1.63077 2.03324 1.52155 2.20256 1.44675C2.37189 1.37196 2.55493 1.33325 2.74004 1.33307H4.74004C5.06357 1.32989 5.37723 1.44446 5.62254 1.65543C5.86786 1.8664 6.02809 2.15937 6.07337 2.47974C6.15779 3.11978 6.31434 3.74822 6.54004 4.35307C6.62973 4.59169 6.64915 4.85102 6.59597 5.10033C6.5428 5.34964 6.41928 5.57848 6.24004 5.75974L5.39337 6.60641C6.34241 8.27544 7.72434 9.65737 9.39337 10.6064L10.24 9.75974C10.4213 9.5805 10.6501 9.45697 10.8994 9.4038C11.1488 9.35063 11.4081 9.37004 11.6467 9.45974C12.2516 9.68544 12.88 9.84199 13.52 9.92641C13.8439 9.97209 14.1396 10.1352 14.3511 10.3847C14.5625 10.6343 14.6748 10.9528 14.6667 11.2797Z" fill="white"/>
				</svg>
				<svg v-else-if="directionClass === 'is-held'" width="12" height="12" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
					<path fill-rule="evenodd" clip-rule="evenodd" d="M3.99967 2C3.63148 2 3.33301 2.29848 3.33301 2.66667V13.3333C3.33301 13.7015 3.63148 14 3.99967 14H6.66634C7.03453 14 7.33301 13.7015 7.33301 13.3333V2.66667C7.33301 2.29848 7.03453 2 6.66634 2H3.99967ZM4.66634 12.6667V3.33333H5.99967V12.6667H4.66634Z" fill="white"/>
					<path fill-rule="evenodd" clip-rule="evenodd" d="M9.33301 2C8.96482 2 8.66634 2.29848 8.66634 2.66667V13.3333C8.66634 13.7015 8.96482 14 9.33301 14H11.9997C12.3679 14 12.6663 13.7015 12.6663 13.3333V2.66667C12.6663 2.29848 12.3679 2 11.9997 2H9.33301ZM9.99967 12.6667V3.33333H11.333V12.6667H9.99967Z" fill="white"/>
				</svg>
			</span>
			<span class="main-call-timer">{{ timerText }}</span>
			<span class="main-call-status-separator" aria-hidden="true"></span>
			<span class="main-call-participants">{{ participantsText }}</span>
			<span v-if="isOnHoldState" class="main-call-status-separator" aria-hidden="true"></span>
			<span v-if="isOnHoldState" class="main-call-hold-bubble" :class="holdBubbleClass">
				<span>On hold</span>
				<span class="main-call-hold-bubble-separator" aria-hidden="true"></span>
				<span>{{ holdTimerText }}</span>
			</span>
			<span v-if="isConferenceState" class="main-call-status-separator" aria-hidden="true"></span>
			<span v-if="isConferenceState" class="main-call-conference-bubble">In Conference</span>
		</span>
	`
});

window.registerVoiceComponent('call-hold-status', {
	data: function() {
		return {
			isOnHold: false
		};
	},
	methods: {
		setHold: function(value) {
			this.isOnHold = value;
		}
	},
	template: '<span v-if="isOnHold" class="call-hold-status">On Hold</span>'
});

window.registerVoiceComponent('main-call-info', {
	template: `
		<div class="main-call-info">
			<div><caller-name /></div>
			<div><call-status /><call-hold-status /></div>
		</div>
	`
});
