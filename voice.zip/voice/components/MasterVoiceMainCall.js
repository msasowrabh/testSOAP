// Master Voice Main Call Component
window.registerVoiceComponent('master-voice-main-call', {
	template: `
		<div class="master-voice-main-call" :class="{ 'is-disabled': isMainCallDisabled, 'is-work-state': isWorkState }" :inert="isMainCallDisabled ? '' : null" :aria-disabled="isMainCallDisabled ? 'true' : 'false'" v-show="isCallVisible">
			<div class="main-call-container">
				<div class="dial-new-call-layout">
					<div class="call-display" :class="callBorderClass">
						<slot name="info"></slot>
					</div>
					<div class="call-controls main-call-actions dial-new-call-actions">
						<slot name="actions" :state="callState" :isAnswerEnabled="isAnswerEnabled" :isHoldEnabled="isHoldEnabled" :isTransferEnabled="isTransferEnabled" :isConferenceEnabled="isConferenceEnabled" :isWorkState="isWorkState"></slot>
					</div>
				</div>
			</div>
		</div>
	`,
	data: function() {
		return {
			callState: null,  // NOCALL, ALERTING, INITIATING, INITIATED, ACTIVE, HELD, WRAP_UP, END, FAILED
			callActive: true,
			isOnHold: false,
			isConsultActive: false,
			isAgentWorkState: false,
			callStatus: 'Connected',
			callDuration: '00:00:00',
			callParties: [],
			mainCallParticipants: null
		};
	},
	computed: {
		isMainCallDisabled: function() {
			return this.isConsultActive;
		},
		isWorkState: function() {
			return this.isAgentWorkState;
		},
		isCallVisible: function() {
			// Show when in these states, hide for END and FAILED
			const visibleStates = ['ALERTING', 'INITIATING', 'INITIATED', 'ACTIVE', 'HELD', 'WRAP_UP'];
			return visibleStates.includes(this.callState);
		},
		isAnswerEnabled: function() {
			// Answer available only in ALERTING state
			return this.callState === 'ALERTING';
		},
		isHoldEnabled: function() {
			// Hold/Resume available in ACTIVE and HELD states
			return this.callState === 'ACTIVE' || this.callState === 'HELD';
		},
		isTransferEnabled: function() {
			// Transfer available in ACTIVE and HELD states
			return this.callState === 'ACTIVE' || this.callState === 'HELD';
		},
		isConferenceEnabled: function() {
			// Conference available in ACTIVE and HELD states
			return this.callState === 'ACTIVE' || this.callState === 'HELD';
		},
		participantCount: function() {
			var participants = this.mainCallParticipants;
			var extension = window.softPhoneConfig && window.softPhoneConfig._extension;
			var list = [];
			if (Array.isArray(participants)) {
				participants.forEach(function(p) {
					if (p && p.mediaAddress && p.mediaAddress !== extension) list.push(p.mediaAddress);
				});
			} else if (participants && participants.mediaAddress && participants.mediaAddress !== extension) {
				list.push(participants.mediaAddress);
			}
			return new Set(list).size;
		},
		isConference: function() {
			return this.callState === 'ACTIVE' && this.participantCount >= 2;
		},
		callBorderClass: function() {
			if (this.callState === 'ACTIVE') {
				return this.isConference ? 'call-border-active-conference' : 'call-border-active';
			}
			if (this.callState === 'HELD') {
				return 'call-border-held';
			}
			if (this.callState === 'FAILED') {
				return 'call-border-failed';
			}
			return '';
		}
	},
	methods: {
		updateConsultState: function() {
			var consultCallState = (window.softPhoneConfig && window.softPhoneConfig.consultCallState) || {};
			var normalizedConsultState = String(consultCallState.state || '').toUpperCase();
			this.isConsultActive = normalizedConsultState === 'ACTIVE' || normalizedConsultState === 'INITIATING' || normalizedConsultState === 'INITIATED';
		},
		updateAgentState: function() {
			var agentState = (window.softPhoneConfig && window.softPhoneConfig.agentState) || {};
			var normalizedAgentState = String(agentState.state || '').toUpperCase();
			this.isAgentWorkState = normalizedAgentState === 'WORK' || normalizedAgentState === 'WORK_READY';
		},
		updateMainCallState: function() {
			var mainCallState = (window.softPhoneConfig && window.softPhoneConfig.mainCallState) || {};
			var nextState = mainCallState.state || 'NOCALL';
			this.mainCallParticipants = mainCallState.participants || null;
			this.setCallState(nextState);
		},
		setCallState: function(newState) {
			this.callState = newState;
			if (window.masterVoiceEvents) {
				window.masterVoiceEvents.emit('master-voice-main-call-state-changed', {
					state: this.callState
				});
			}
			
			// Update call status text based on state
			const stateText = {
				'ALERTING': 'Incoming Call',
				'INITIATING': 'Calling...',
				'INITIATED': 'Calling...',
				'ACTIVE': 'Connected',
				'HELD': 'On Hold',
				'WRAP_UP': 'Wrap Up',
				'END': 'Ended',
				'FAILED': 'Failed'
			};
			
			this.callStatus = stateText[newState] || 'Unknown';
			
			if (newState === 'HELD') {
				this.isOnHold = true;
			} else if (newState === 'ACTIVE') {
				this.isOnHold = false;
			}
		},
		toggleHold: function() {
			this.isOnHold = !this.isOnHold;
			this.callStatus = this.isOnHold ? 'On Hold' : 'Connected';
		},
		startConference: function() {
			this.callStatus = 'Conference Requested';
		},
		startTransfer: function() {
			this.callStatus = 'Transfer Requested';
		},
		endCall: function() {
			this.callActive = false;
			this.callStatus = 'Ended';
		}
	},
	mounted: function() {
		if (window.masterVoiceEvents) {
			var mainCallChangeEvent = (window.PROXYCONST && window.PROXYCONST.EVENT_TYPE_MAIN_CALL_CHANGE) || 'MAIN_CALL_CHANGE';
			var consultCallChangeEvent = (window.PROXYCONST && window.PROXYCONST.EVENT_TYPE_CONSULT_CALL_CHANGE) || 'CONSULT_CALL_CHANGE';
			var agentStatusChangeEvent = (window.PROXYCONST && window.PROXYCONST.EVENT_TYPE_AGENT_STATUS_CHANGE) || 'AGENT_STATUS_CHANGE';
			this._unsubMainCallChange = window.masterVoiceEvents.on(mainCallChangeEvent, this.updateMainCallState);
			this._unsubConsultCallChange = window.masterVoiceEvents.on(consultCallChangeEvent, this.updateConsultState);
			this._unsubAgentStatusChange = window.masterVoiceEvents.on(agentStatusChangeEvent, this.updateAgentState);
		}
		this.updateMainCallState();
		this.updateConsultState();
		this.updateAgentState();
	},
	beforeUnmount: function() {
		if (this._unsubMainCallChange) {
			this._unsubMainCallChange();
		}
		if (this._unsubConsultCallChange) {
			this._unsubConsultCallChange();
		}
		if (this._unsubAgentStatusChange) {
			this._unsubAgentStatusChange();
		}
	}
});
