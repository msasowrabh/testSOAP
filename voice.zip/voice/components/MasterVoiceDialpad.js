// Master Voice DTMF Dialpad Component
window.registerVoiceComponent('dtmf-dialpad-button', {
	props: {
		dialogScope: {
			type: String,
			default: 'main'
		},
		label: {
			type: String,
			default: 'Keypad'
		}
	},
	data: function() {
		return {
			isPanelOpen: false,
			enteredDigits: '',
			callState: '',
			actionsMap: {},
			canSendDtmf: false,
			highlightedIndex: -1,
			panelDirection: 'down',
			dialpadKeys: [
				'1', '2', '3',
				'4', '5', '6',
				'7', '8', '9',
				'*', '0', '#'
			]
		};
	},
	computed: {
		isDisabled: function() {
			return isMasterVoiceButtonsDisabled() || !this.isCallActive || !this.hasDtmfAvailability;
		},
		isCallActive: function() {
			return this.callState === 'ACTIVE';
		},
		hasDtmfAction: function() {
			return Object.keys(this.actionsMap).some(function(actionName) {
				return /DTMF/i.test(String(actionName || ''));
			});
		},
		hasDtmfAvailability: function() {
			return this.hasDtmfAction || this.canSendDtmf;
		}
	},
	watch: {
		isDisabled: function(newValue) {
			if (newValue) {
				this.closePanel();
			}
		},
		dialogScope: function() {
			this.refreshAvailability();
		}
	},
	methods: {
		normalizeActionsMap: function(actionSource) {
			if (Array.isArray(actionSource)) {
				return actionSource.reduce(function(result, actionName) {
					result[actionName] = actionName;
					return result;
				}, {});
			}

			if (actionSource && typeof actionSource === 'object') {
				return Object.assign({}, actionSource);
			}

			return {};
		},
		refreshAvailability: function() {
			var isConsult = String(this.dialogScope || '').toLowerCase() === 'consult';
			var softPhoneConfig = window.softPhoneConfig || {};
			var callState = isConsult ? (softPhoneConfig.consultCallState || {}) : (softPhoneConfig.mainCallState || {});
			var actions = isConsult ? (softPhoneConfig.actions && softPhoneConfig.actions.consultCall) : (softPhoneConfig.actions && softPhoneConfig.actions.mainCall);

			this.callState = String((callState && callState.state) || '').toUpperCase();
			this.actionsMap = this.normalizeActionsMap(actions);
			this.canSendDtmf = !!(window.softPhoneCoreService && typeof window.softPhoneCoreService._canSendDTMF === 'function' && window.softPhoneCoreService._canSendDTMF(this.dialogScope));
		},
		togglePanel: function() {
			if (this.isDisabled) {
				return;
			}

			if (this.isPanelOpen) {
				this.closePanel();
				return;
			}

			this.isPanelOpen = true;
			this.panelDirection = 'down';
			this.highlightedIndex = 0;
			this.$nextTick(function() {
				this.updatePanelDirection();
				if (this.$refs.dialpadDisplay) {
					this.$refs.dialpadDisplay.focus();
				}
			}.bind(this));
		},
		closePanel: function() {
			this.isPanelOpen = false;
			this.highlightedIndex = -1;
			this.panelDirection = 'down';
			this.clearDigits();
			this.$nextTick(function() {
				if (this.$refs.triggerButton) {
					this.$refs.triggerButton.focus();
				}
			}.bind(this));
		},
		clearDigits: function() {
			this.enteredDigits = '';
		},
		updatePanelDirection: function() {
			if (!this.isPanelOpen || !this.$el) {
				this.panelDirection = 'down';
				return;
			}

			var trigger = this.$refs.triggerButton;
			var panel = this.$el.querySelector('.dtmf-dialpad-panel');
			if (!trigger || !panel) {
				this.panelDirection = 'down';
				return;
			}

			var triggerRect = trigger.getBoundingClientRect();
			var panelHeight = panel.offsetHeight || 0;
			var viewportHeight = window.innerHeight || document.documentElement.clientHeight || 0;
			var spaceBelow = viewportHeight - triggerRect.bottom - 8;
			var spaceAbove = triggerRect.top - 8;

			if (spaceBelow < panelHeight && spaceAbove > spaceBelow) {
				this.panelDirection = 'up';
				return;
			}

			this.panelDirection = 'down';
		},
		handleOutsideClick: function(event) {
			if (!this.isPanelOpen || !this.$el || this.$el.contains(event.target)) {
				return;
			}

			this.closePanel();
		},
		handleViewportChange: function() {
			if (!this.isPanelOpen) {
				return;
			}
			this.updatePanelDirection();
		},
		focusHighlightedKey: function() {
			var keyRefs = this.$refs.dialpadKeys;
			if (!keyRefs || !keyRefs.length || this.highlightedIndex < 0 || this.highlightedIndex >= keyRefs.length) {
				return;
			}

			keyRefs[this.highlightedIndex].focus();
		},
		moveHighlight: function(step) {
			var count = this.dialpadKeys.length;
			if (!count) {
				return;
			}

			if (this.highlightedIndex < 0) {
				this.highlightedIndex = 0;
			} else {
				this.highlightedIndex = (this.highlightedIndex + step + count) % count;
			}

			this.$nextTick(this.focusHighlightedKey);
		},
		removeLastDigit: function() {
			if (!this.enteredDigits) {
				return;
			}

			this.enteredDigits = this.enteredDigits.slice(0, -1);
		},
		filterDtmf: function(raw) {
			return String(raw || '').replace(/[^0-9*#]/g, '');
		},
		handleDisplayInput: function(event) {
			var filtered = this.filterDtmf(event.target.value);
			var added = filtered.slice(this.enteredDigits.length);
			var self = this;

			// Sync filtered value back to DOM immediately
			event.target.value = filtered;
			this.enteredDigits = filtered;

			// Send only the newly added characters as DTMF
			added.split('').forEach(function(digit) {
				self.sendDtmfDigit(digit);
			});
		},
		handleDisplayPaste: function(event) {
			event.preventDefault();
			var pasted = event.clipboardData ? event.clipboardData.getData('text') : '';
			var filtered = this.filterDtmf(pasted);
			if (!filtered) {
				return;
			}

			var self = this;
			filtered.split('').forEach(function(digit) {
				self.onDigitPressed(digit);
			});
		},
		handleKeyboardDigit: function(key) {
			if (!/^[0-9*#]$/.test(key)) {
				return false;
			}

			this.onDigitPressed(key);
			return true;
		},
		handlePanelKeydown: function(event) {
			if (!this.isPanelOpen) {
				return;
			}

			// Let the textarea handle its own native text operations
			// only intercept on non-display elements
			var isDisplayFocused = event.target === this.$refs.dialpadDisplay;

			if (!isDisplayFocused && this.handleKeyboardDigit(event.key)) {
				event.preventDefault();
				return;
			}

			if (!isDisplayFocused && event.key === 'Backspace') {
				event.preventDefault();
				this.removeLastDigit();
				return;
			}

			if (event.key === 'Escape') {
				event.preventDefault();
				this.closePanel();
				return;
			}

			if (!isDisplayFocused && event.key === 'ArrowRight') {
				event.preventDefault();
				this.moveHighlight(1);
				return;
			}

			if (!isDisplayFocused && event.key === 'ArrowLeft') {
				event.preventDefault();
				this.moveHighlight(-1);
				return;
			}

			if (!isDisplayFocused && event.key === 'ArrowDown') {
				event.preventDefault();
				this.moveHighlight(3);
				return;
			}

			if (!isDisplayFocused && event.key === 'ArrowUp') {
				event.preventDefault();
				this.moveHighlight(-3);
			}
		},
		sendDtmfDigit: function(digit) {
			if (window.softPhoneCoreService && typeof window.softPhoneCoreService._sendDTMF === 'function') {
				window.softPhoneCoreService._sendDTMF(digit, null, null, this.dialogScope);
			}
		},
		onDigitPressed: function(digit) {
			if (this.isDisabled) {
				return;
			}

			this.enteredDigits += digit;
			this.sendDtmfDigit(digit);
		},
		onKeyFocus: function(index) {
			this.highlightedIndex = index;
		}
	},
	mounted: function() {
		this.refreshAvailability();
		document.addEventListener('click', this.handleOutsideClick);
		window.addEventListener('resize', this.handleViewportChange);
		window.addEventListener('scroll', this.handleViewportChange, true);
		if (window.masterVoiceEvents) {
			var isConsult = String(this.dialogScope || '').toLowerCase() === 'consult';
			var eventName = isConsult
				? ((window.PROXYCONST && window.PROXYCONST.EVENT_TYPE_CONSULT_CALL_CHANGE) || 'CONSULT_CALL_CHANGE')
				: ((window.PROXYCONST && window.PROXYCONST.EVENT_TYPE_MAIN_CALL_CHANGE) || 'MAIN_CALL_CHANGE');
			var self = this;
			this._availabilityHandler = function() {
				self.refreshAvailability();
			};
			this._unsubAvailability = window.masterVoiceEvents.on(eventName, this._availabilityHandler);
		}
	},
	beforeUnmount: function() {
		if (this._unsubAvailability) {
			this._unsubAvailability();
		}
		document.removeEventListener('click', this.handleOutsideClick);
		window.removeEventListener('resize', this.handleViewportChange);
		window.removeEventListener('scroll', this.handleViewportChange, true);
	},
	template: `
		<div class="dtmf-dialpad" :class="{ 'is-open-up': isPanelOpen && panelDirection === 'up', 'is-consult-scope': String(dialogScope || '').toLowerCase() === 'consult' }">
			<button
				ref="triggerButton"
				type="button"
				:class="{ 'is-persistent-active': isPanelOpen }"
				style="display:inline-flex;align-items:center;justify-content:center;gap:6px;"
				:disabled="isDisabled"
				aria-haspopup="dialog"
				:aria-expanded="isPanelOpen"
				@click="togglePanel"
			>
				<svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg"><path fill-rule="evenodd" clip-rule="evenodd" d="M5 5C5.4144 5 5.81183 4.83538 6.10485 4.54235C6.39788 4.24933 6.5625 3.8519 6.5625 3.4375C6.5625 3.0231 6.39788 2.62567 6.10485 2.33265C5.81183 2.03962 5.4144 1.875 5 1.875C4.5856 1.875 4.18817 2.03962 3.89515 2.33265C3.60212 2.62567 3.4375 3.0231 3.4375 3.4375C3.4375 3.8519 3.60212 4.24933 3.89515 4.54235C4.18817 4.83538 4.5856 5 5 5ZM5 9.375C5.4144 9.375 5.81183 9.21038 6.10485 8.91735C6.39788 8.62433 6.5625 8.2269 6.5625 7.8125C6.5625 7.3981 6.39788 7.00067 6.10485 6.70765C5.81183 6.41462 5.4144 6.25 5 6.25C4.5856 6.25 4.18817 6.41462 3.89515 6.70765C3.60212 7.00067 3.4375 7.3981 3.4375 7.8125C3.4375 8.2269 3.60212 8.62433 3.89515 8.91735C4.18817 9.21038 4.5856 9.375 5 9.375ZM10 5C10.4144 5 10.8118 4.83538 11.1049 4.54235C11.3979 4.24933 11.5625 3.8519 11.5625 3.4375C11.5625 3.0231 11.3979 2.62567 11.1049 2.33265C10.8118 2.03962 10.4144 1.875 10 1.875C9.5856 1.875 9.18817 2.03962 8.89515 2.33265C8.60212 2.62567 8.4375 3.0231 8.4375 3.4375C8.4375 3.8519 8.60212 4.24933 8.89515 4.54235C9.18817 4.83538 9.5856 5 10 5ZM10 9.375C10.4144 9.375 10.8118 9.21038 11.1049 8.91735C11.3979 8.62433 11.5625 8.2269 11.5625 7.8125C11.5625 7.3981 11.3979 7.00067 11.1049 6.70765C10.8118 6.41462 10.4144 6.25 10 6.25C9.5856 6.25 9.18817 6.41462 8.89515 6.70765C8.60212 7.00067 8.4375 7.3981 8.4375 7.8125C8.4375 8.2269 8.60212 8.62433 8.89515 8.91735C9.18817 9.21038 9.5856 9.375 10 9.375ZM5 13.75C5.4144 13.75 5.81183 13.5854 6.10485 13.2924C6.39788 12.9993 6.5625 12.6019 6.5625 12.1875C6.5625 11.7731 6.39788 11.3757 6.10485 11.0826C5.81183 10.7896 5.4144 10.625 5 10.625C4.5856 10.625 4.18817 10.7896 3.89515 11.0826C3.60212 11.3757 3.4375 11.7731 3.4375 12.1875C3.4375 12.6019 3.60212 12.9993 3.89515 13.2924C4.18817 13.5854 4.5856 13.75 5 13.75ZM10 13.75C10.4144 13.75 10.8118 13.5854 11.1049 13.2924C11.3979 12.9993 11.5625 12.6019 11.5625 12.1875C11.5625 11.7731 11.3979 11.3757 11.1049 11.0826C10.8118 10.7896 10.4144 10.625 10 10.625C9.5856 10.625 9.18817 10.7896 8.89515 11.0826C8.60212 11.3757 8.4375 11.7731 8.4375 12.1875C8.4375 12.6019 8.60212 12.9993 8.89515 13.2924C9.18817 13.5854 9.5856 13.75 10 13.75ZM10 18.125C10.4144 18.125 10.8118 17.9604 11.1049 17.6674C11.3979 17.3743 11.5625 16.9769 11.5625 16.5625C11.5625 16.1481 11.3979 15.7507 11.1049 15.4576C10.8118 15.1646 10.4144 15 10 15C9.5856 15 9.18817 15.1646 8.89515 15.4576C8.60212 15.7507 8.4375 16.1481 8.4375 16.5625C8.4375 16.9769 8.60212 17.3743 8.89515 17.6674C9.18817 17.9604 9.5856 18.125 10 18.125ZM15 5C15.4144 5 15.8118 4.83538 16.1049 4.54235C16.3979 4.24933 16.5625 3.8519 16.5625 3.4375C16.5625 3.0231 16.3979 2.62567 16.1049 2.33265C15.8118 2.03962 15.4144 1.875 15 1.875C14.5856 1.875 14.1882 2.03962 13.8951 2.33265C13.6021 2.62567 13.4375 3.0231 13.4375 3.4375C13.4375 3.8519 13.6021 4.24933 13.8951 4.54235C14.1882 4.83538 14.5856 5 15 5ZM15 9.375C15.4144 9.375 15.8118 9.21038 16.1049 8.91735C16.3979 8.62433 16.5625 8.2269 16.5625 7.8125C16.5625 7.3981 16.3979 7.00067 16.1049 6.70765C15.8118 6.41462 15.4144 6.25 15 6.25C14.5856 6.25 14.1882 6.41462 13.8951 6.70765C13.6021 7.00067 13.4375 7.3981 13.4375 7.8125C13.4375 8.2269 13.6021 8.62433 13.8951 8.91735C14.1882 9.21038 14.5856 9.375 15 9.375ZM15 13.75C15.4144 13.75 15.8118 13.5854 16.1049 13.2924C16.3979 12.9993 16.5625 12.6019 16.5625 12.1875C16.5625 11.7731 16.3979 11.3757 16.1049 11.0826C15.8118 10.7896 15.4144 10.625 15 10.625C14.5856 10.625 14.1882 10.7896 13.8951 11.0826C13.6021 11.3757 13.4375 11.7731 13.4375 12.1875C13.4375 12.6019 13.6021 12.9993 13.8951 13.2924C14.1882 13.5854 14.5856 13.75 15 13.75Z" fill="currentColor"/></svg>
				{{ label }}
			</button>
			<div v-if="isPanelOpen" class="dtmf-dialpad-panel" role="dialog" :aria-label="$t('dtmf.dialogLabel')" @keydown="handlePanelKeydown">
				<div class="dtmf-dialpad-display-row">
					<textarea
						ref="dialpadDisplay"
						class="dtmf-dialpad-display"
						:value="enteredDigits"
						rows="1"
						wrap="off"
						:aria-label="$t('dtmf.enteredDigits')"
						@paste="handleDisplayPaste"
						@input="handleDisplayInput"
					></textarea>
					<button type="button" class="dtmf-dialpad-clear" :aria-label="$t('dtmf.clearEnteredDigits')" tabindex="-1" @click="clearDigits">&#x2715;</button>
				</div>
				<div class="dtmf-dialpad-grid">
					<button
						v-for="(digit, index) in dialpadKeys"
						:key="digit"
						ref="dialpadKeys"
						type="button"
						class="dtmf-dialpad-key"
						:class="{ 'is-highlighted': highlightedIndex === index }"
						@focus="onKeyFocus(index)"
						@mouseenter="highlightedIndex = index"
						@click="onDigitPressed(digit)"
					>
						{{ digit }}
					</button>
				</div>
			</div>
		</div>
	`
});