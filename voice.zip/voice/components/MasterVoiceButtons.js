// Master Voice Button Components
function isMasterVoiceButtonsDisabled() {
	return !!(window.masterVoiceApp && window.masterVoiceApp.allButtonsDisabled);
}

window.registerVoiceComponent('hold-button', {
	emits: ['toggle'],
	props: {
		isOnHold: {
			type: Boolean,
			default: null
		},
		disabled: {
			type: Boolean,
			default: false
		}
	},
	data: function() {
		return {
			localIsOnHold: false
		};
	},
	computed: {
		isDisabled: function() {
			return isMasterVoiceButtonsDisabled() || this.disabled;
		},
		currentIsOnHold: function() {
			return this.isOnHold === null ? this.localIsOnHold : this.isOnHold;
		}
	},
	methods: {
		handleClick: function() {
			if (this.isDisabled) {
				return;
			}

			if (this.isOnHold === null) {
				this.localIsOnHold = !this.localIsOnHold;
			}

			if (window.console && typeof window.console.log === 'function') {
				window.console.log(this.currentIsOnHold ? 'Call resumed' : 'Call put on hold');
			}

			this.$emit('toggle');
		}
	},
	template: '<button type="button" :disabled="isDisabled" @click="handleClick" style="display:inline-flex;align-items:center;justify-content:center;gap:6px;"><svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg"><path fill-rule="evenodd" clip-rule="evenodd" d="M5.00008 2.5C4.53984 2.5 4.16675 2.8731 4.16675 3.33333V16.6667C4.16675 17.1269 4.53984 17.5 5.00008 17.5H8.33342C8.79365 17.5 9.16675 17.1269 9.16675 16.6667V3.33333C9.16675 2.8731 8.79365 2.5 8.33342 2.5H5.00008ZM5.83341 15.8333V4.16667H7.50008V15.8333H5.83341Z" fill="#262626"/><path fill-rule="evenodd" clip-rule="evenodd" d="M11.6667 2.5C11.2065 2.5 10.8334 2.8731 10.8334 3.33333V16.6667C10.8334 17.1269 11.2065 17.5 11.6667 17.5H15.0001C15.4603 17.5 15.8334 17.1269 15.8334 16.6667V3.33333C15.8334 2.8731 15.4603 2.5 15.0001 2.5H11.6667ZM12.5001 15.8333V4.16667H14.1667V15.8333H12.5001Z" fill="#262626"/></svg>{{ currentIsOnHold ? $t("buttons.resume") : $t("buttons.hold") }}</button>'
});

window.registerVoiceComponent('answer-button', {
	emits: ['answer'],
	props: {
		disabled: {
			type: Boolean,
			default: false
		}
	},
	computed: {
		isDisabled: function() {
			return isMasterVoiceButtonsDisabled() || this.disabled;
		}
	},
	methods: {
		handleClick: function() {
			if (this.isDisabled) {
				return;
			}

			if (window.console && typeof window.console.log === 'function') {
				window.console.log('Answer requested');
			}

			this.$emit('answer');
		}
	},
	template: '<button type="button" :disabled="isDisabled" @click="handleClick">{{ $t("buttons.answer") }}</button>'
});

window.registerVoiceComponent('conference-button', {
	emits: ['start'],
	props: {
		active: {
			type: Boolean,
			default: false
		},
		disabled: {
			type: Boolean,
			default: false
		}
	},
	computed: {
		isDisabled: function() {
			return isMasterVoiceButtonsDisabled() || this.disabled;
		}
	},
	methods: {
		handleClick: function() {
			if (this.isDisabled) {
				return;
			}

			if (window.console && typeof window.console.log === 'function') {
				window.console.log('Conference requested');
			}

			this.$emit('start');
		}
	},
	template: '<button type="button" :class="{ \'is-persistent-active\': active }" :disabled="isDisabled" @click="handleClick" style="display:inline-flex;align-items:center;justify-content:center;gap:6px;"><svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M12.5001 17.5003V16.667C12.5001 16.446 12.4122 16.2341 12.2559 16.0778C12.0997 15.9215 11.8878 15.8337 11.6667 15.8337H8.33341C8.1124 15.8337 7.9005 15.9215 7.74422 16.0778C7.58794 16.2341 7.50008 16.446 7.50008 16.667V17.5003C7.50008 17.9606 7.12699 18.3337 6.66675 18.3337C6.20651 18.3337 5.83341 17.9606 5.83341 17.5003V16.667C5.83341 16.004 6.097 15.3683 6.56584 14.8994C7.03468 14.4306 7.67037 14.167 8.33341 14.167H11.6667C12.3298 14.167 12.9655 14.4306 13.4343 14.8994C13.9032 15.3683 14.1667 16.004 14.1667 16.667V17.5003C14.1667 17.9606 13.7937 18.3337 13.3334 18.3337C12.8732 18.3337 12.5001 17.9606 12.5001 17.5003ZM10.8334 10.8337C10.8334 10.6126 10.7456 10.4007 10.5893 10.2445C10.433 10.0882 10.2211 10.0003 10.0001 10.0003C9.77907 10.0003 9.56717 10.0882 9.41089 10.2445C9.25461 10.4007 9.16675 10.6126 9.16675 10.8337C9.16675 11.0547 9.25461 11.2666 9.41089 11.4229C9.56717 11.5791 9.77907 11.667 10.0001 11.667C10.2211 11.667 10.433 11.5791 10.5893 11.4229C10.7456 11.2666 10.8334 11.0547 10.8334 10.8337ZM1.66675 10.8337V10.0003C1.66675 9.33728 1.93033 8.70159 2.39917 8.23275C2.86801 7.76391 3.50371 7.50033 4.16675 7.50033H5.83341C6.29365 7.50033 6.66675 7.87342 6.66675 8.33366C6.66675 8.7939 6.29365 9.16699 5.83341 9.16699H4.16675C3.94573 9.16699 3.73384 9.25485 3.57756 9.41113C3.42127 9.56741 3.33341 9.77931 3.33341 10.0003V10.8337C3.33341 11.2939 2.96032 11.667 2.50008 11.667C2.03984 11.667 1.66675 11.2939 1.66675 10.8337ZM16.6667 10.8337V10.0003C16.6667 9.77931 16.5789 9.56741 16.4226 9.41113C16.2663 9.25485 16.0544 9.16699 15.8334 9.16699H14.1667C13.7065 9.16699 13.3334 8.7939 13.3334 8.33366C13.3334 7.87342 13.7065 7.50033 14.1667 7.50033H15.8334C16.4965 7.50033 17.1322 7.76391 17.601 8.23275C18.0698 8.70159 18.3334 9.33728 18.3334 10.0003V10.8337C18.3334 11.2939 17.9603 11.667 17.5001 11.667C17.0398 11.667 16.6667 11.2939 16.6667 10.8337ZM6.66675 4.16699C6.66675 3.94598 6.57889 3.73408 6.42261 3.5778C6.28582 3.44101 6.10644 3.35664 5.91561 3.33773L5.83341 3.33366C5.6124 3.33366 5.4005 3.42152 5.24422 3.5778C5.08794 3.73408 5.00008 3.94598 5.00008 4.16699L5.00415 4.24919C5.02306 4.44002 5.10744 4.6194 5.24422 4.75618C5.4005 4.91247 5.6124 5.00033 5.83341 5.00033L5.91561 4.99626C6.10644 4.97735 6.28582 4.89297 6.42261 4.75618C6.57889 4.5999 6.66675 4.38801 6.66675 4.16699ZM15.0001 4.16699C15.0001 3.94598 14.9122 3.73408 14.7559 3.5778C14.5997 3.42152 14.3878 3.33366 14.1667 3.33366C13.9457 3.33366 13.7338 3.42152 13.5776 3.5778C13.4213 3.73408 13.3334 3.94598 13.3334 4.16699C13.3334 4.38801 13.4213 4.5999 13.5776 4.75618C13.7338 4.91247 13.9457 5.00033 14.1667 5.00033L14.2489 4.99626C14.4398 4.97735 14.6192 4.89297 14.7559 4.75618C14.9122 4.5999 15.0001 4.38801 15.0001 4.16699ZM12.5001 10.8337C12.5001 11.4967 12.2365 12.1324 11.7677 12.6012C11.2988 13.0701 10.6631 13.3337 10.0001 13.3337C9.33704 13.3337 8.70134 13.0701 8.2325 12.6012C7.76366 12.1324 7.50008 11.4967 7.50008 10.8337C7.50008 10.1706 7.76366 9.53492 8.2325 9.06608C8.70134 8.59724 9.33704 8.33366 10.0001 8.33366C10.6631 8.33366 11.2988 8.59724 11.7677 9.06608C12.2365 9.53492 12.5001 10.1706 12.5001 10.8337ZM8.33341 4.16699C8.33341 4.83003 8.06983 5.46573 7.60099 5.93457C7.19083 6.34474 6.65301 6.5979 6.08081 6.65479L5.83341 6.66699C5.17037 6.66699 4.53468 6.40341 4.06584 5.93457C3.65567 5.52441 3.4025 4.98659 3.34562 4.41439L3.33341 4.16699C3.33341 3.50395 3.597 2.86826 4.06584 2.39941C4.53468 1.93057 5.17037 1.66699 5.83341 1.66699L6.08081 1.6792C6.65301 1.73608 7.19083 1.98925 7.60099 2.39941C8.06983 2.86825 8.33341 3.50395 8.33341 4.16699ZM16.6667 4.16699C16.6667 4.83003 16.4032 5.46573 15.9343 5.93457C15.5242 6.34474 14.9863 6.5979 14.4141 6.65479L14.1667 6.66699C13.5037 6.66699 12.868 6.40341 12.3992 5.93457C11.9303 5.46573 11.6667 4.83003 11.6667 4.16699C11.6667 3.50395 11.9303 2.86825 12.3992 2.39941C12.868 1.93057 13.5037 1.66699 14.1667 1.66699C14.8298 1.66699 15.4655 1.93057 15.9343 2.39941C16.4032 2.86825 16.6667 3.50395 16.6667 4.16699Z" fill="#262626"/></svg>{{ $t("buttons.conference") }}</button>'
});

window.registerVoiceComponent('transfer-button', {
	emits: ['start'],
	props: {
		active: {
			type: Boolean,
			default: false
		},
		disabled: {
			type: Boolean,
			default: false
		}
	},
	computed: {
		isDisabled: function() {
			return isMasterVoiceButtonsDisabled() || this.disabled;
		}
	},
	methods: {
		handleClick: function() {
			if (this.isDisabled) {
				return;
			}

			if (window.console && typeof window.console.log === 'function') {
				window.console.log('Transfer requested');
			}

			this.$emit('start');
		}
	},
	template: '<button type="button" :class="{ \'is-persistent-active\': active }" :disabled="isDisabled" @click="handleClick" style="display:inline-flex;align-items:center;justify-content:center;gap:6px;"><svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg"><g clip-path="url(#clip0_573_3656)"><path d="M15.8334 0.833008L19.1668 4.16634M19.1668 4.16634L15.8334 7.49967M19.1668 4.16634H12.5001M18.3334 14.0997V16.5997C18.3344 16.8318 18.2868 17.0615 18.1939 17.2741C18.1009 17.4868 17.9645 17.6777 17.7935 17.8346C17.6225 17.9915 17.4206 18.1109 17.2007 18.1853C16.9809 18.2596 16.7479 18.2872 16.5168 18.2663C13.9525 17.9877 11.4893 17.1115 9.32511 15.708C7.31163 14.4286 5.60455 12.7215 4.32511 10.708C2.91676 8.53401 2.04031 6.05884 1.76677 3.48301C1.74595 3.25256 1.77334 3.02031 1.84719 2.80103C1.92105 2.58175 2.03975 2.38025 2.19575 2.20936C2.35174 2.03847 2.54161 1.90193 2.75327 1.80844C2.96492 1.71495 3.19372 1.66656 3.42511 1.66634H5.92511C6.32953 1.66236 6.7216 1.80557 7.02824 2.06929C7.33488 2.333 7.53517 2.69921 7.59177 3.09967C7.69729 3.89973 7.89298 4.68528 8.17511 5.44134C8.28723 5.73961 8.31149 6.06377 8.24503 6.37541C8.17857 6.68705 8.02416 6.9731 7.80011 7.19967L6.74177 8.25801C7.92807 10.3443 9.65549 12.0717 11.7418 13.258L12.8001 12.1997C13.0267 11.9756 13.3127 11.8212 13.6244 11.7548C13.936 11.6883 14.2602 11.7126 14.5584 11.8247C15.3145 12.1068 16.1001 12.3025 16.9001 12.408C17.3049 12.4651 17.6746 12.669 17.9389 12.9809C18.2032 13.2928 18.3436 13.691 18.3334 14.0997Z" stroke="#262626" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/></g><defs><clipPath id="clip0_573_3656"><rect width="20" height="20" fill="white"/></clipPath></defs></svg>{{ $t("buttons.transfer") }}</button>'
});

window.registerVoiceComponent('end-call-button', {
	emits: ['end'],
	props: {
		disabled: {
			type: Boolean,
			default: false
		}
	},
	computed: {
		isDisabled: function() {
			return isMasterVoiceButtonsDisabled() || this.disabled;
		}
	},
	methods: {
		handleClick: function() {
			if (this.isDisabled) {
				return;
			}

			if (window.console && typeof window.console.log === 'function') {
				window.console.log('Call ended');
			}

			this.$emit('end');
		}
	},
	template: '<button type="button" class="danger" :disabled="isDisabled" @click="handleClick" style="display:inline-flex;align-items:center;justify-content:center;gap:6px;"><svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg"><g clip-path="url(#clip0_573_3672)"><path d="M8.89992 11.0913C9.74563 11.9378 10.7014 12.6666 11.7416 13.258L12.7999 12.1997C13.0265 11.9756 13.3125 11.8212 13.6242 11.7548C13.9358 11.6883 14.26 11.7126 14.5583 11.8247C15.3143 12.1068 16.0999 12.3025 16.8999 12.408C17.3004 12.4646 17.6666 12.6649 17.9303 12.9715C18.194 13.2782 18.3372 13.6703 18.3333 14.0747V16.5747C18.3342 16.8068 18.2867 17.0365 18.1937 17.2491C18.1007 17.4618 17.9643 17.6527 17.7933 17.8096C17.6223 17.9665 17.4204 18.0859 17.2005 18.1603C16.9807 18.2346 16.7477 18.2622 16.5166 18.2413C13.9523 17.9627 11.4891 17.0865 9.32492 15.683C8.32098 15.0456 7.39036 14.2994 6.54992 13.458M4.32492 10.6747C2.92146 8.51051 2.04522 6.04731 1.76659 3.48301C1.74576 3.25256 1.77315 3.02031 1.847 2.80103C1.92086 2.58175 2.03956 2.38025 2.19556 2.20936C2.35155 2.03847 2.54142 1.90193 2.75308 1.80844C2.96473 1.71495 3.19354 1.66656 3.42492 1.66634H5.92492C6.32934 1.66236 6.72141 1.80557 7.02805 2.06929C7.33469 2.333 7.53498 2.69921 7.59158 3.09967C7.6971 3.89973 7.89279 4.68528 8.17492 5.44134C8.28704 5.73961 8.3113 6.06377 8.24484 6.37541C8.17838 6.68705 8.02397 6.9731 7.79992 7.19967L6.74159 8.25801M19.1666 0.833008L0.833252 19.1663" stroke="white" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/></g><defs><clipPath id="clip0_573_3672"><rect width="20" height="20" fill="white"/></clipPath></defs></svg>{{ $t("buttons.endCall") }}</button>'
});

window.registerVoiceComponent('start-consult-button', {
	emits: ['start'],
	computed: {
		disabled: function() {
			return isMasterVoiceButtonsDisabled();
		}
	},
	methods: {
		handleClick: function() {
			if (this.disabled) {
				return;
			}

			this.$emit('start');
		}
	},
	template: '<button type="button" :disabled="disabled" @click="handleClick">{{ $t("buttons.startConsult") }}</button>'
});

window.registerVoiceComponent('complete-consult-button', {
	emits: ['complete'],
	computed: {
		disabled: function() {
			return isMasterVoiceButtonsDisabled();
		}
	},
	methods: {
		handleClick: function() {
			if (this.disabled) {
				return;
			}

			this.$emit('complete');
		}
	},
	template: '<button type="button" :disabled="disabled" @click="handleClick">{{ $t("buttons.completeConsult") }}</button>'
});

window.registerVoiceComponent('cancel-consult-button', {
	emits: ['cancel'],
	computed: {
		disabled: function() {
			return isMasterVoiceButtonsDisabled();
		}
	},
	methods: {
		handleClick: function() {
			if (this.disabled) {
				return;
			}

			this.$emit('cancel');
		}
	},
	template: '<button type="button" :disabled="disabled" @click="handleClick">{{ $t("buttons.cancel") }}</button>'
});

window.registerVoiceComponent('cancel-button', {
	emits: ['cancel'],
	computed: {
		disabled: function() {
			return isMasterVoiceButtonsDisabled();
		}
	},
	methods: {
		handleClick: function() {
			if (this.disabled) {
				return;
			}

			var dialNewCall = window.masterVoiceApp && window.masterVoiceApp.$refs
				? window.masterVoiceApp.$refs.dialNewCall
				: null;

			if (dialNewCall && typeof dialNewCall.hideDialNewCall === 'function') {
				dialNewCall.hideDialNewCall();
			}

			if (window.console && typeof window.console.log === 'function') {
				window.console.log('New call canceled');
			}

			this.$emit('cancel');
		}
	},
	template: '<button type="button" :disabled="disabled" @click="handleClick">{{ $t("buttons.cancel") }}</button>'
});

window.registerVoiceComponent('dial-button', {
	emits: ['dial'],
	props: {
		enabled: {
			type: Boolean,
			default: false
		},
		isLoading: {
			type: Boolean,
			default: false
		},
		hideIcon: {
			type: Boolean,
			default: false
		},
		label: {
			type: String,
			default: ''
		}
	},
	computed: {
		disabled: function() {
			return isMasterVoiceButtonsDisabled() || !this.enabled;
		},
		shouldAnimateIcon: function() {
			if (this.isLoading) {
				return true;
			}

			var labelText = String(this.label || '').toLowerCase();
			return labelText.indexOf('calling') !== -1 || labelText.indexOf('initiating') !== -1;
		}
	},
	methods: {
		handleClick: function() {
			if (this.disabled) {
				return;
			}

			if (window.console && typeof window.console.log === 'function') {
				window.console.log('Dial action requested');
			}

			this.$emit('dial');
		}
	},
	template: '<button type="button" class="dial-primary" :disabled="disabled" @click="handleClick" style="display:inline-flex;align-items:center;justify-content:center;gap:6px;"><svg v-if="!hideIcon && shouldAnimateIcon" class="dial-primary-icon is-rotating" width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg"><circle cx="3" cy="3" r="3" fill="white"/><circle opacity="0.25" cx="13" cy="3" r="3" fill="white"/><circle opacity="0.75" cx="3" cy="13" r="3" fill="white"/><circle opacity="0.5" cx="13" cy="13" r="3" fill="white"/></svg><svg v-else-if="!hideIcon" class="dial-primary-icon" width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg"><g clip-path="url(#clip0_513_1788)"><path d="M18.3333 14.0999V16.5999C18.3343 16.832 18.2867 17.0617 18.1937 17.2744C18.1008 17.487 17.9644 17.6779 17.7934 17.8348C17.6224 17.9917 17.4205 18.1112 17.2006 18.1855C16.9808 18.2599 16.7478 18.2875 16.5167 18.2666C13.9523 17.988 11.4892 17.1117 9.32498 15.7083C7.31151 14.4288 5.60443 12.7217 4.32499 10.7083C2.91663 8.53426 2.04019 6.05908 1.76665 3.48325C1.74583 3.25281 1.77321 3.02055 1.84707 2.80127C1.92092 2.58199 2.03963 2.38049 2.19562 2.2096C2.35162 2.03871 2.54149 1.90218 2.75314 1.80869C2.9648 1.7152 3.1936 1.6668 3.42499 1.66658H5.92499C6.32941 1.6626 6.72148 1.80582 7.02812 2.06953C7.33476 2.33324 7.53505 2.69946 7.59165 3.09992C7.69717 3.89997 7.89286 4.68552 8.17499 5.44158C8.2871 5.73985 8.31137 6.06401 8.24491 6.37565C8.17844 6.68729 8.02404 6.97334 7.79998 7.19992L6.74165 8.25825C7.92795 10.3445 9.65536 12.072 11.7417 13.2583L12.8 12.1999C13.0266 11.9759 13.3126 11.8215 13.6243 11.755C13.9359 11.6885 14.26 11.7128 14.5583 11.8249C15.3144 12.107 16.0999 12.3027 16.9 12.4083C17.3048 12.4654 17.6745 12.6693 17.9388 12.9812C18.203 13.2931 18.3435 13.6912 18.3333 14.0999Z" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/></g><defs><clipPath id="clip0_513_1788"><rect width="20" height="20" fill="white"/></clipPath></defs></svg>{{ label || $t("buttons.dial") }}</button>'
});
