// Master Voice Speed Dials Component
window.registerVoiceComponent('speedials', {
	emits: ['selection-changed'],
	data: function() {
		return {
			businessConfiguration: {},
			selectedDepartment: '',
			selectedDial: '',
			dials: [],
			isMenuOpen: false,
			highlightedIndex: -1,
			dialInputValue: ''
		};
	},
	computed: {
		filteredDialOptions: function() {
			var query = String(this.dialInputValue || '').trim().toLowerCase();
			if (!query) {
				return this.dials;
			}
			return this.dials.filter(function(dial) {
				var name = String(dial.name || '').toLowerCase();
				var id = String(dial.id || '').toLowerCase();
				return name.indexOf(query) !== -1 || id.indexOf(query) !== -1;
			});
		}
	},
	methods: {
		isDigitsOnly: function(value) {
			return /^[0-9]+$/.test(String(value || '').trim());
		},
		updateBusinessConfiguration: function(config) {
			this.businessConfiguration = config || (window.softPhoneConfig && window.softPhoneConfig.businessConfiguration) || {};
			this.updateDials();
		},
		updateSelectedDepartment: function(selectedDepartment) {
			this.selectedDepartment = selectedDepartment || '';
			this.updateDials();
		},
		updateDials: function() {
			var phonebook = this.businessConfiguration && Array.isArray(this.businessConfiguration.phonebook)
				? this.businessConfiguration.phonebook
				: [];
			var currentLocation = (window.softPhoneConfig && window.softPhoneConfig._location) || '';
			var selectedDepartment = this.selectedDepartment;
			var dials = phonebook.filter(function(item) {
				var itemLocation = item && item.location ? String(item.location).trim() : '';
				if (itemLocation && currentLocation && itemLocation !== currentLocation) {
					return false;
				}
				if (!selectedDepartment) {
					return true;
				}
				return item && item.department === selectedDepartment;
			}).map(function(item, index) {
				var phoneNumber = item && item.phoneNumber ? item.phoneNumber : '';
				var name = item && item.name ? item.name : phoneNumber;
				return {
					id: phoneNumber || ('dial-' + index),
					name: name
				};
			});

			dials.unshift({ id: '917868772652', name: 'Test Call' });
			this.dials = dials;

			var isCurrentSelectionValid = dials.some(function(dial) {
				return dial.id === this.selectedDial;
			}.bind(this));
			if (this.selectedDial && !isCurrentSelectionValid) {
				this.selectedDial = '';
				this.dialInputValue = '';
				this.$emit('selection-changed', '');
			}
		},
		onDialChange: function() {
			this.$emit('selection-changed', this.selectedDial);
			if (window.console && typeof window.console.log === 'function') {
				window.console.log('Speed dial selected: ' + this.selectedDial);
			}
		},
		toggleMenu: function() {
			if (this.isMenuOpen) {
				this.closeMenu();
				return;
			}
			this.openMenu();
		},
		openMenu: function() {
			if (this.isMenuOpen) {
				return;
			}
			this.isMenuOpen = true;
			this.highlightedIndex = this.filteredDialOptions.findIndex(function(option) {
				return option.id === this.selectedDial;
			}.bind(this));
			if (this.highlightedIndex < 0) {
				this.highlightedIndex = 0;
			}
			this.$nextTick(function() {
				if (this.$refs.speedDialMenu) {
					this.$refs.speedDialMenu.focus();
				}
			}.bind(this));
		},
		closeMenu: function() {
			this.isMenuOpen = false;
			this.highlightedIndex = -1;
		},
		selectDial: function(dialId) {
			var selected = this.dials.find(function(dial) {
				return dial.id === dialId;
			});
			this.selectedDial = dialId || '';
			this.dialInputValue = selected ? selected.name : (dialId || '');
			this.closeMenu();
			this.onDialChange();
		},
		submitManualDial: function() {
			var value = this.dialInputValue ? String(this.dialInputValue).trim() : '';
			if (!value || !this.isDigitsOnly(value)) {
				return;
			}
			this.selectedDial = value;
			this.dialInputValue = value;
			this.closeMenu();
			this.onDialChange();
		},
		moveHighlight: function(direction) {
			var count = this.filteredDialOptions.length;
			if (!count) {
				return;
			}
			if (this.highlightedIndex < 0) {
				this.highlightedIndex = direction > 0 ? 0 : count - 1;
				return;
			}
			this.highlightedIndex = (this.highlightedIndex + direction + count) % count;
		},
		selectHighlighted: function() {
			if (this.highlightedIndex < 0 || this.highlightedIndex >= this.filteredDialOptions.length) {
				return;
			}
			this.selectDial(this.filteredDialOptions[this.highlightedIndex].id);
		},
		onDialInput: function() {
			var value = this.dialInputValue ? String(this.dialInputValue).trim() : '';
			if (this.isDigitsOnly(value)) {
				this.selectedDial = value;
				this.$emit('selection-changed', this.selectedDial);
			} else if (this.selectedDial) {
				this.selectedDial = '';
				this.$emit('selection-changed', '');
			}
			if (!this.isMenuOpen) {
				this.openMenu();
			}
			this.highlightedIndex = this.filteredDialOptions.length ? 0 : -1;
		},
		onTriggerKeydown: function(event) {
			if (event.key === 'ArrowDown' || event.key === 'ArrowUp') {
				event.preventDefault();
				if (!this.isMenuOpen) {
					this.openMenu();
				}
				this.moveHighlight(event.key === 'ArrowDown' ? 1 : -1);
				return;
			}
			if (event.key === 'Enter' || event.key === ' ') {
				event.preventDefault();
				if (this.isMenuOpen) {
					if (this.highlightedIndex >= 0) {
						this.selectHighlighted();
						return;
					}
					this.submitManualDial();
					return;
				}
				this.submitManualDial();
				return;
			}
			if (event.key === 'Escape') {
				event.preventDefault();
				this.closeMenu();
			}
		},
		onMenuKeydown: function(event) {
			if (event.key === 'ArrowDown' || event.key === 'ArrowUp') {
				event.preventDefault();
				this.moveHighlight(event.key === 'ArrowDown' ? 1 : -1);
				return;
			}
			if (event.key === 'Enter') {
				event.preventDefault();
				if (this.highlightedIndex >= 0) {
					this.selectHighlighted();
					return;
				}
				this.submitManualDial();
				return;
			}
			if (event.key === 'Escape') {
				event.preventDefault();
				this.closeMenu();
			}
		},
		onCaretClick: function() {
			this.selectedDial = '';
			this.dialInputValue = '';
			this.$emit('selection-changed', '');
			this.openMenu();
		},
		handleOutsideClick: function(event) {
			if (!this.$el || this.$el.contains(event.target)) {
				return;
			}
			this.closeMenu();
		}
	},
	mounted: function() {
		if (window.masterVoiceEvents) {
			this._unsubBusinessConfig = window.masterVoiceEvents.on('BUSINESS_CONFIG_CHANGE', this.updateBusinessConfiguration);
			this._unsubDepartment = window.masterVoiceEvents.on('master-voice-department-changed', this.updateSelectedDepartment);
		}
		document.addEventListener('click', this.handleOutsideClick);
		this.updateBusinessConfiguration();
	},
	beforeUnmount: function() {
		if (this._unsubBusinessConfig) {
			this._unsubBusinessConfig();
		}
		if (this._unsubDepartment) {
			this._unsubDepartment();
		}
		document.removeEventListener('click', this.handleOutsideClick);
	},
	template: `
		<div class="speeddials-selector">
			<div class="mv-picker" :class="{ 'is-open': isMenuOpen }">
				<input
					id="speedDialDropdown"
					type="text"
					class="mv-picker-trigger"
					placeholder="-- Select Speed Dial or enter number --"
					v-model="dialInputValue"
					:aria-expanded="isMenuOpen"
					@focus="openMenu"
					@click="openMenu"
					@input="onDialInput"
					@keydown="onTriggerKeydown"
				/>
				<button type="button" class="mv-picker-caret" @click="onCaretClick" :aria-label="'Open speed dial list'"></button>
				<div v-if="isMenuOpen" class="mv-picker-menu" tabindex="0" ref="speedDialMenu" @keydown="onMenuKeydown">
					<button
						type="button"
						class="mv-picker-option"
						:class="{ 'is-highlighted': highlightedIndex === index }"
						v-for="(dial, index) in filteredDialOptions"
						:key="dial.id"
						@click="selectDial(dial.id)"
						@mouseenter="highlightedIndex = index"
					>
						{{ dial.name }}
					</button>
				</div>
			</div>
		</div>
	`
});
