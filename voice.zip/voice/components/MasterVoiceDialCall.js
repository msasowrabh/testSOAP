// Master Voice Dial Call Component
window.registerVoiceComponent('dial-new-call', {
	data: function() {
		return {
			isVisible: true,
			state: 'dial',
			isDialInitiating: false,
			isAgentReadyState: false
		};
	},
		computed: {
			isDialDisabled: function() {
				return this.isAgentReadyState;
			},
			translate: function() {
				var i18n = window.masterVoiceI18n;
				if (i18n && i18n.global && typeof i18n.global.t === 'function') {
					return i18n.global.t;
				}
				return function() { return ''; };
			},
			title: function() {
				var titles = {
					'dial': this.translate('dial.noIncomingCalls'),
					'conference': this.translate('dial.conferenceWith'),
					'transfer': this.translate('dial.transferTo')
				};
				return titles[this.state] || titles['dial'];
			},
			dialButtonLabel: function() {
				if (this.isDialInitiating) {
					return this.translate('dial.initiating');
				}
				var labels = {
					'dial': this.translate('dial.startCall'),
					'transfer': this.translate('dial.initiateTransfer'),
					'conference': this.translate('dial.initiateConference')
				};
				return labels[this.state] || this.translate('buttons.dial');
			}
		},
	methods: {
		notifyVisibilityCompleted: function(action, source) {
			var self = this;
			this.$nextTick(function() {
				var finalize = function() {
					if (window.masterVoiceEvents) {
						window.masterVoiceEvents.emit('master-voice-dial-new-call-visibility-completed', {
							visible: !!self.isVisible,
							state: self.state,
							action: action || 'unknown',
							source: source || 'unknown'
						});
					}

					if (typeof gadgets !== 'undefined' && gadgets.window && typeof gadgets.window.adjustHeight === 'function') {
						gadgets.window.adjustHeight();
					}
				};

				if (typeof window.requestAnimationFrame === 'function') {
					window.requestAnimationFrame(finalize);
					return;
				}

				finalize();
			});
		},
		handleConsultCallChange: function() {
			var consultState = (window.softPhoneConfig && window.softPhoneConfig.consultCallState && window.softPhoneConfig.consultCallState.state) || '';
			var normalizedState = String(consultState).toUpperCase();
			this.isDialInitiating = normalizedState === 'INITIATING' || normalizedState === 'INITIATED';
			if (normalizedState === 'ACTIVE') {
				this.hideDialNewCall('consult-active');
			}
		},
		handleAgentStatusChange: function() {
			var agentState = (window.softPhoneConfig && window.softPhoneConfig.agentState && window.softPhoneConfig.agentState.state) || '';
			this.isAgentReadyState = String(agentState).toUpperCase() === 'READY';
		},
		hideDialNewCall: function(source) {
			this.isVisible = false;
			this.notifyVisibilityCompleted('hide', source);
		},
		showDialNewCall: function(source) {
			this.isVisible = true;
			this.notifyVisibilityCompleted('show', source);
		},
		setState: function(newState) {
			this.state = newState || 'dial';
			if (this.state === 'dial') {
				this.isDialInitiating = false;
			}
		}
	},
	mounted: function() {
		if (window.masterVoiceEvents) {
			var eventName = (window.PROXYCONST && window.PROXYCONST.EVENT_TYPE_CONSULT_CALL_CHANGE) || 'CONSULT_CALL_CHANGE';
			var agentStatusEventName = (window.PROXYCONST && window.PROXYCONST.EVENT_TYPE_AGENT_STATUS_CHANGE) || 'AGENT_STATUS_CHANGE';
			this._unsubConsultCallChange = window.masterVoiceEvents.on(eventName, this.handleConsultCallChange);
			this._unsubAgentStatusChange = window.masterVoiceEvents.on(agentStatusEventName, this.handleAgentStatusChange);
		}
		this.handleAgentStatusChange();
	},
	beforeUnmount: function() {
		if (this._unsubConsultCallChange) {
			this._unsubConsultCallChange();
		}
		if (this._unsubAgentStatusChange) {
			this._unsubAgentStatusChange();
		}
	},
	template: `
		<div class="master-voice-speedials sp-frame" :class="{ 'is-disabled': isDialDisabled }" :inert="isDialDisabled ? '' : null" :aria-disabled="isDialDisabled ? 'true' : 'false'" v-show="isVisible" :data-state="state">
			<div class="speedials-layout">
				<div class="dial-type-title" v-if="state !== 'dial'">
					{{ title }}
				</div>
				<div class="dial-new-call-controls-row" v-if="state === 'dial'">
					<div class="dial-type-title dial-type-title-inline dial-type-title-inline-dial">
						<span class="dial-state-icon-bubble" aria-hidden="true">
							<svg width="12" height="12" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
								<path d="M14.6667 11.2797V13.2797C14.6675 13.4654 14.6294 13.6492 14.555 13.8193C14.4807 13.9894 14.3716 14.1421 14.2348 14.2676C14.0979 14.3932 13.9364 14.4887 13.7605 14.5482C13.5847 14.6077 13.3983 14.6298 13.2134 14.6131C11.1619 14.3902 9.19137 13.6892 7.46004 12.5664C5.84926 11.5428 4.48359 10.1772 3.46004 8.56641C2.33336 6.82721 1.6322 4.84707 1.41337 2.78641C1.39671 2.60205 1.41862 2.41625 1.4777 2.24082C1.53679 2.0654 1.63175 1.9042 1.75655 1.76749C1.88134 1.63077 2.03324 1.52155 2.20256 1.44675C2.37189 1.37196 2.55493 1.33325 2.74004 1.33307H4.74004C5.06357 1.32989 5.37723 1.44446 5.62254 1.65543C5.86786 1.8664 6.02809 2.15937 6.07337 2.47974C6.15779 3.11978 6.31434 3.74822 6.54004 4.35307C6.62973 4.59169 6.64915 4.85102 6.59597 5.10033C6.5428 5.34964 6.41928 5.57848 6.24004 5.75974L5.39337 6.60641C6.34241 8.27544 7.72434 9.65737 9.39337 10.6064L10.24 9.75974C10.4213 9.5805 10.6501 9.45697 10.8994 9.4038C11.1488 9.35063 11.4081 9.37004 11.6467 9.45974C12.2516 9.68544 12.88 9.84199 13.52 9.92641C13.8439 9.97209 14.1396 10.1352 14.3511 10.3847C14.5625 10.6343 14.6748 10.9528 14.6667 11.2797Z" fill="white"/>
							</svg>
						</span>
						<span class="dial-state-icon-separator" aria-hidden="true"></span>
						<span>{{ title }}</span>
					</div>
					<div class="dial-inline-right">
						<div class="dial-lists-row speedials-lists">
							<slot name="lists"></slot>
						</div>
						<span class="dial-inline-separator" aria-hidden="true"></span>
						<div class="call-controls main-call-actions speedials-actions dial-new-call-actions">
							<slot name="actions" :isDialState="true" :isDialInitiating="isDialInitiating" :dialButtonLabel="dialButtonLabel" :hideDialNewCall="hideDialNewCall" :showDialNewCall="showDialNewCall"></slot>
						</div>
					</div>
				</div>
				<div class="dial-new-call-controls-row" v-else>
					<div class="dial-lists-row speedials-lists">
						<slot name="lists"></slot>
					</div>
					<div class="call-controls main-call-actions speedials-actions dial-new-call-actions">
						<slot name="actions" :isDialState="false" :isDialInitiating="isDialInitiating" :dialButtonLabel="dialButtonLabel" :hideDialNewCall="hideDialNewCall" :showDialNewCall="showDialNewCall"></slot>
					</div>
				</div>
			</div>
		</div>
	`
});