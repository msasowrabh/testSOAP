// Master Voice Department Component
window.registerVoiceComponent('department', {
	emits: ['selection-changed'],
	data: function() {
		return {
			selectedDepartment: '',
			businessConfiguration: {},
			departments: [],
			isMenuOpen: false,
			highlightedIndex: -1
		};
	},
	computed: {
		isDepartmentVisible: function() {
			var config = window.softPhoneConfig || {};
			return config.deptDisabled !== true;
		},
		departmentOptions: function() {
			return [{ id: '', name: '-- Select Department --' }].concat(this.departments);
		},
		selectedDepartmentLabel: function() {
			if (!this.selectedDepartment) {
				return '-- Select Department --';
			}

			var selected = this.departments.find(function(dept) {
				return dept.id === this.selectedDepartment;
			}.bind(this));

			return selected ? selected.name : this.selectedDepartment;
		}
	},
	methods: {
		emitDepartmentSelectionChanged: function() {
			this.$emit('selection-changed', this.selectedDepartment);
			if (window.masterVoiceEvents) {
				window.masterVoiceEvents.emit('master-voice-department-changed', this.selectedDepartment);
				var uiConst = window.UICONST || {};
				if (uiConst.EVENT_TYPE_DEPARTMENT_SELECT_CHANGE) {
					window.masterVoiceEvents.emit(uiConst.EVENT_TYPE_DEPARTMENT_SELECT_CHANGE, {
						department: this.selectedDepartment
					});
				}
			}
		},
		updateBusinessConfiguration: function(config) {
			var phonebook;
			var seen = {};
			var hasAssurant = false;
			var currentLocation = (window.softPhoneConfig && window.softPhoneConfig._location) || '';
			this.businessConfiguration = config || (window.softPhoneConfig && window.softPhoneConfig.businessConfiguration) || {};
			phonebook = Array.isArray(this.businessConfiguration.phonebook) ? this.businessConfiguration.phonebook : [];
			this.departments = phonebook.reduce(function(result, item) {
				var itemLocation = item && item.location ? String(item.location).trim() : '';
				var name = item && item.department ? item.department : '';
				if (itemLocation && currentLocation && itemLocation !== currentLocation) {
					return result;
				}
				if (!name || seen[name]) {
					return result;
				}
				seen[name] = true;
				if (name === 'Assurant') {
					hasAssurant = true;
				}
				result.push({
					id: name,
					name: name
				});
				return result;
			}, []);

			if (this.selectedDepartment && !seen[this.selectedDepartment]) {
				this.selectedDepartment = '';
				this.emitDepartmentSelectionChanged();
			}

			if (!this.selectedDepartment && hasAssurant) {
				this.selectedDepartment = 'Assurant';
				this.emitDepartmentSelectionChanged();
			}
		},
		handleCallDataChange: function() {
			var config = window.softPhoneConfig || {};
			if (config.deptManual !== false || typeof config.departmentHook !== 'function') {
				return;
			}

			var nextDepartment = config.departmentHook(config.callData || {}, this.businessConfiguration || {});
			nextDepartment = nextDepartment == null ? '' : String(nextDepartment);
			if (nextDepartment === this.selectedDepartment) {
				return;
			}

			this.selectedDepartment = nextDepartment;
			this.emitDepartmentSelectionChanged();
		},
		onDepartmentChange: function() {
			this.emitDepartmentSelectionChanged();

			if (window.console && typeof window.console.log === 'function') {
				window.console.log('Department selected: ' + this.selectedDepartment);
			}
		},
		openMenu: function() {
			if (this.isMenuOpen) {
				return;
			}
			this.isMenuOpen = true;
			this.highlightedIndex = this.departmentOptions.findIndex(function(option) {
				return option.id === this.selectedDepartment;
			}.bind(this));
			if (this.highlightedIndex < 0) {
				this.highlightedIndex = 0;
			}
			this.$nextTick(function() {
				if (this.$refs.departmentMenu) {
					this.$refs.departmentMenu.focus();
				}
			}.bind(this));
		},
		closeMenu: function() {
			this.isMenuOpen = false;
			this.highlightedIndex = -1;
		},
		toggleMenu: function() {
			if (this.isMenuOpen) {
				this.closeMenu();
				return;
			}
			this.openMenu();
		},
		selectDepartment: function(departmentId) {
			this.selectedDepartment = departmentId || '';
			this.closeMenu();
			this.onDepartmentChange();
		},
		moveHighlight: function(direction) {
			var count = this.departmentOptions.length;
			if (!count) {
				return;
			}
			if (this.highlightedIndex < 0) {
				this.highlightedIndex = direction > 0 ? 0 : count - 1;
				return;
			}
			this.highlightedIndex = (this.highlightedIndex + direction + count) % count;
		},
		selectHighlighted: function() {
			if (this.highlightedIndex < 0 || this.highlightedIndex >= this.departmentOptions.length) {
				return;
			}
			this.selectDepartment(this.departmentOptions[this.highlightedIndex].id);
		},
		onTriggerKeydown: function(event) {
			if (event.key === 'ArrowDown' || event.key === 'ArrowUp') {
				event.preventDefault();
				if (!this.isMenuOpen) {
					this.openMenu();
				}
				this.moveHighlight(event.key === 'ArrowDown' ? 1 : -1);
				return;
			}
			if (event.key === 'Enter' || event.key === ' ') {
				event.preventDefault();
				if (this.isMenuOpen) {
					this.selectHighlighted();
					return;
				}
				this.openMenu();
				return;
			}
			if (event.key === 'Escape') {
				event.preventDefault();
				this.closeMenu();
			}
		},
		onMenuKeydown: function(event) {
			if (event.key === 'ArrowDown' || event.key === 'ArrowUp') {
				event.preventDefault();
				this.moveHighlight(event.key === 'ArrowDown' ? 1 : -1);
				return;
			}
			if (event.key === 'Enter') {
				event.preventDefault();
				this.selectHighlighted();
				return;
			}
			if (event.key === 'Escape') {
				event.preventDefault();
				this.closeMenu();
			}
		},
		handleOutsideClick: function(event) {
			if (!this.$el || this.$el.contains(event.target)) {
				return;
			}
			this.closeMenu();
		}
	},
	mounted: function() {
		if (window.masterVoiceEvents) {
			this._unsubBusinessConfig = window.masterVoiceEvents.on('BUSINESS_CONFIG_CHANGE', this.updateBusinessConfiguration);
			var callDataEvent = (window.PROXYCONST && window.PROXYCONST.EVENT_TYPE_CALL_DATA_CHANGE) || 'CALL_DATA_CHANGE';
			this._unsubCallDataChange = window.masterVoiceEvents.on(callDataEvent, this.handleCallDataChange);
		}
		document.addEventListener('click', this.handleOutsideClick);
		this.updateBusinessConfiguration();
	},
	beforeUnmount: function() {
		if (this._unsubBusinessConfig) {
			this._unsubBusinessConfig();
		}
		if (this._unsubCallDataChange) {
			this._unsubCallDataChange();
		}
		document.removeEventListener('click', this.handleOutsideClick);
	},
	template: `
		<div v-if="isDepartmentVisible" class="department-selector">
			<div class="mv-picker" :class="{ 'is-open': isMenuOpen }">
				<button id="departmentDropdown" type="button" class="mv-picker-trigger" @click="toggleMenu" @keydown="onTriggerKeydown" :aria-expanded="isMenuOpen">
					{{ selectedDepartmentLabel }}
				</button>
				<div v-if="isMenuOpen" class="mv-picker-menu" tabindex="0" ref="departmentMenu" @keydown="onMenuKeydown">
					<button
						type="button"
						class="mv-picker-option"
						:class="{ 'is-highlighted': highlightedIndex === index }"
						v-for="(dept, index) in departmentOptions"
						:key="dept.id"
						@click="selectDepartment(dept.id)"
						@mouseenter="highlightedIndex = index"
					>
						{{ dept.name }}
					</button>
				</div>
			</div>
		</div>
	`
});
