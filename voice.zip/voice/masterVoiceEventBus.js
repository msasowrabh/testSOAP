// Master Voice Event Bus
// Standalone pub/sub emitter used as a decoupled bridge between the
// AngularJS service layer and Vue components.
// Available globally as window.masterVoiceEvents.
(function() {
	var BOOT_RETRY_DELAY_MS = 50;
	var BOOT_MAX_RETRIES = 120;

	function isPiniaReady() {
		return !!(window.Pinia && typeof window.Pinia.createPinia === 'function' && typeof window.Pinia.defineStore === 'function');
	}

	function isVueReady() {
		return !!(window.Vue && typeof window.Vue.createApp === 'function');
	}

	function startWhenDependenciesReady(startFn) {
		var retries = 0;
		(function waitForDeps() {
			if (isPiniaReady() && isVueReady()) {
				startFn();
				return;
			}

			retries += 1;
			if (retries >= BOOT_MAX_RETRIES) {
				if (window.console && typeof window.console.error === 'function') {
					window.console.error('Pinia is required for Master Voice event state. Ensure pinia.iife.prod.js and vue.global.js are loaded before masterVoiceEventBus.js');
				}
				return;
			}

			window.setTimeout(waitForDeps, BOOT_RETRY_DELAY_MS);
		})();
	}

	function startMasterVoiceEventBus() {
		if (window.masterVoiceEventBusBootstrapStarted) {
			return;
		}
		window.masterVoiceEventBusBootstrapStarted = true;

	// Ensure VueDemi is available for Pinia's IIFE initialization
	if (typeof window.VueDemi === 'undefined' && typeof window.Vue !== 'undefined') {
		window.VueDemi = window.Vue;
	}

	window.masterVoicePinia = window.masterVoicePinia || window.Pinia.createPinia();

	if (!window.useMasterVoiceEventStore) {
		window.useMasterVoiceEventStore = window.Pinia.defineStore('masterVoiceEvents', {
			state: function() {
				return {
					listeners: {}
				};
			},
			actions: {
				on: function(event, handler) {
					if (typeof handler !== 'function') {
						return function() {};
					}
					if (!this.listeners[event]) {
						this.listeners[event] = [];
					}
					this.listeners[event].push(handler);
					var self = this;
					return function() {
						self.off(event, handler);
					};
				},
				off: function(event, handler) {
					var handlers = this.listeners[event];
					if (!handlers) {
						return;
					}
					var idx = handlers.indexOf(handler);
					if (idx > -1) {
						handlers.splice(idx, 1);
					}
				},
				emit: function(event, payload) {
					var handlers = this.listeners[event];
					if (!handlers || handlers.length === 0) {
						return;
					}
					handlers.slice().forEach(function(handler) {
						try {
							handler(payload);
						} catch (e) {
							if (window.console && typeof window.console.error === 'function') {
								window.console.error('masterVoiceEvents handler error for event "' + event + '":', e);
							}
						}
					});
				}
			}
		});
	}

	var eventStore = window.useMasterVoiceEventStore(window.masterVoicePinia);

	window.masterVoiceEvents = {
		on: function(event, handler) {
			return eventStore.on(event, handler);
		},
		off: function(event, handler) {
			return eventStore.off(event, handler);
		},
		emit: function(event, payload) {
			return eventStore.emit(event, payload);
		}
	};

	// Exposed globally for components/services to publish and subscribe.
	}

	startWhenDependenciesReady(startMasterVoiceEventBus);
})();
